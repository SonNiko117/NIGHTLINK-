package com.nightlink.app.update

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class UpdateLogicTest {
    private fun v(s: String) = AppVersion.parse(s)!!

    @Test fun versionOrdering() {
        assertTrue(v("1.0.1") > v("1.0.0"))
        assertTrue(v("v1.10.0") > v("1.9.9"))
        assertTrue(v("1.0.0") > v("1.0.0-rc1"))
        assertTrue(v("1.0.0-rc2") > v("1.0.0-rc1"))
        assertTrue(v("1.0.0-debug.2") > v("1.0.0-debug.1"))
        assertEquals(0, v("1.0").compareTo(v("1.0.0")))
        assertTrue(v("1.0.0+build5").compareTo(v("1.0.0")) == 0)
    }

    @Test fun invalidVersions() {
        assertNull(AppVersion.parse(""))
        assertNull(AppVersion.parse(null))
        assertNull(AppVersion.parse("latest"))
        assertNull(AppVersion.parse("1.x"))
    }

    private val sha = "a".repeat(64)
    private val releaseJson = """
        {"tag_name":"v1.1.0","name":"NIGHTLINK 1.1","body":"Neu: Dinge","html_url":"https://github.com/o/r/releases/tag/v1.1.0",
         "published_at":"2026-12-01T10:00:00Z","draft":false,"prerelease":false,
         "assets":[
          {"name":"NIGHTLINK-1.1.0-release.apk","browser_download_url":"https://github.com/o/r/releases/download/v1.1.0/NIGHTLINK-1.1.0-release.apk","size":1234,"digest":"sha256:$sha"},
          {"name":"NIGHTLINK-1.1.0-debug.apk","browser_download_url":"https://github.com/o/r/releases/download/v1.1.0/NIGHTLINK-1.1.0-debug.apk","size":2000}
         ]}
    """.trimIndent()

    @Test fun parseRelease() {
        val r = ReleaseParser.parseRelease(releaseJson)
        assertEquals("v1.1.0", r.tag)
        assertEquals(v("1.1.0"), r.version)
        assertEquals(2, r.assets.size)
        assertEquals(sha, r.assets[0].sha256)
        assertNull(r.assets[1].sha256)
    }

    @Test(expected = ReleaseParseException::class) fun draftRejected() {
        ReleaseParser.parseRelease("""{"tag_name":"v2.0.0","draft":true,"assets":[]}""")
    }

    @Test fun listSkipsBrokenEntries() {
        val list = ReleaseParser.parseReleaseList("""[{"tag_name":"nightly"},{"tag_name":"v1.2.0","assets":[]},{"tag_name":"v1.3.0","draft":true}]""")
        assertEquals(listOf("v1.2.0"), list.map { it.tag })
    }

    @Test fun apkSelectionSeparatesDebugAndRelease() {
        val assets = ReleaseParser.parseRelease(releaseJson).assets
        assertEquals("NIGHTLINK-1.1.0-release.apk", ApkSelector.select(assets, false, listOf("arm64-v8a"))?.name)
        assertEquals("NIGHTLINK-1.1.0-debug.apk", ApkSelector.select(assets, true, listOf("arm64-v8a"))?.name)
        assertNull(ApkSelector.select(assets.filter { it.name.contains("debug") }, false, emptyList()))
    }

    @Test fun apkSelectionPrefersDeviceAbi() {
        fun a(n: String) = ReleaseAsset(n, "https://github.com/o/r/releases/download/v/$n", 1, null)
        val assets = listOf(a("n-x86_64.apk"), a("n-arm64-v8a.apk"))
        assertEquals("n-arm64-v8a.apk", ApkSelector.select(assets, false, listOf("arm64-v8a", "armeabi-v7a"))?.name)
        assertNull(ApkSelector.select(assets, false, listOf("armeabi-v7a")))
    }

    @Test fun urlAllowlist() {
        assertTrue(UpdateSecurity.isAllowedUrl("https://api.github.com/repos/o/r/releases/latest"))
        assertTrue(UpdateSecurity.isAllowedUrl("https://objects.githubusercontent.com/x"))
        assertFalse(UpdateSecurity.isAllowedUrl("http://github.com/o/r"))
        assertFalse(UpdateSecurity.isAllowedUrl("https://evil.com/github.com"))
        assertFalse(UpdateSecurity.isAllowedUrl("https://github.com.evil.com/x"))
        assertFalse(UpdateSecurity.isAllowedUrl("https://user:pw@github.com/x"))
        assertFalse(UpdateSecurity.isAllowedUrl("https://githubusercontent.com/x"))
        assertTrue(UpdateSecurity.isRepoDownloadUrl("https://github.com/o/r/releases/download/v1/a.apk", "o/r"))
        assertFalse(UpdateSecurity.isRepoDownloadUrl("https://github.com/other/r/releases/download/v1/a.apk", "o/r"))
        assertTrue(UpdateSecurity.isValidRepo("o/r"))
        assertFalse(UpdateSecurity.isValidRepo(""))
        assertFalse(UpdateSecurity.isValidRepo("o/r/extra"))
    }

    @Test fun sha256AndChecksumFile() {
        val f = File.createTempFile("nl", ".bin")
        try {
            f.writeText("abc")
            assertEquals("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad", UpdateSecurity.sha256Hex(f))
        } finally { f.delete() }
        assertEquals(sha, UpdateSecurity.parseChecksumFile("${sha.uppercase()}  NIGHTLINK.apk\n"))
        assertNull(UpdateSecurity.parseChecksumFile("nothex"))
        assertNotNull(UpdateSecurity.parseChecksumFile(sha))
    }
}
