package com.nightlink.app.security

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.net.InetAddress

class SecurityTest {
    @Test fun proofsMatchForSameCodeAndDifferOtherwise() {
        val cn = Handshake.newNonce(); val sn = Handshake.newNonce()
        val k1 = Handshake.deriveKey("123456"); val k2 = Handshake.deriveKey("654321")
        assertTrue(Handshake.verify(Handshake.serverProof(k1, cn, sn), Handshake.serverProof(Handshake.deriveKey("123456"), cn, sn)))
        assertFalse(Handshake.verify(Handshake.serverProof(k1, cn, sn), Handshake.serverProof(k2, cn, sn)))
    }

    @Test fun clientAndServerProofsAreNotInterchangeable() {
        val cn = Handshake.newNonce(); val sn = Handshake.newNonce(); val k = Handshake.deriveKey("123456")
        assertFalse(Handshake.verify(Handshake.serverProof(k, cn, sn), Handshake.clientProof(k, cn, sn)))
    }

    @Test fun verifyRejectsNull() = assertFalse(Handshake.verify(ByteArray(32), null))

    @Test fun secureChannelRoundTripAndTamper() {
        val key = ByteArray(32) { it.toByte() }
        val server = SecureChannel(key, true); val client = SecureChannel(key, false)
        val line = client.encrypt("hello".toByteArray())
        assertArrayEquals("hello".toByteArray(), server.decrypt(line))
        val reply = server.encrypt("world".toByteArray())
        assertArrayEquals("world".toByteArray(), client.decrypt(reply))

        val bad = client.encrypt("x".toByteArray())
        val flipped = bad.replaceFirstChar { if (it == 'A') 'B' else 'A' }
        try { server.decrypt(flipped); fail() } catch (ignored: SecureChannelException) { }
    }

    @Test fun secureChannelRejectsReplay() {
        val key = ByteArray(32) { 7 }
        val server = SecureChannel(key, true); val client = SecureChannel(key, false)
        val line = client.encrypt("a".toByteArray())
        server.decrypt(line)
        try { server.decrypt(line); fail() } catch (ignored: SecureChannelException) { }
    }

    @Test fun authGuardLocksAfterFailuresAndExpires() {
        var now = 0L
        val g = AuthGuard(maxFailures = 3, lockoutMillis = 1000, clock = { now })
        repeat(2) { g.recordFailure("a"); assertFalse(g.isBlocked("a")) }
        g.recordFailure("a")
        assertTrue(g.isBlocked("a"))
        assertFalse(g.isBlocked("b"))
        now = 1001
        assertFalse(g.isBlocked("a"))
    }

    @Test fun authGuardSuccessResetsCounter() {
        val g = AuthGuard(maxFailures = 2)
        g.recordFailure("a"); g.recordSuccess("a"); g.recordFailure("a")
        assertFalse(g.isBlocked("a"))
    }

    @Test fun localNetworkGuard() {
        fun ip(s: String) = InetAddress.getByName(s)
        assertTrue(LocalNetworkGuard.isLocal(ip("192.168.1.20")))
        assertTrue(LocalNetworkGuard.isLocal(ip("10.0.0.5")))
        assertTrue(LocalNetworkGuard.isLocal(ip("172.16.4.1")))
        assertTrue(LocalNetworkGuard.isLocal(ip("fd12:3456:789a::1")))
        assertFalse(LocalNetworkGuard.isLocal(ip("8.8.8.8")))
        assertFalse(LocalNetworkGuard.isLocal(ip("127.0.0.1")))
        assertTrue(LocalNetworkGuard.isLocal(ip("127.0.0.1"), allowLoopback = true))
        assertFalse(LocalNetworkGuard.isLocal(null))
    }

    @Test fun accessCodeFormat() {
        repeat(50) { assertTrue(AccessCode.isWellFormed(AccessCode.generate())) }
        assertEquals("123456", AccessCode.normalize("12 34-56"))
        assertFalse(AccessCode.isWellFormed("12345"))
    }
}
