package com.nightlink.app.transport

import com.nightlink.app.security.AuthGuard
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class SignalingTest {
    private class Recorder : SignalingServerListener {
        val connected = CountDownLatch(1)
        val received = CopyOnWriteArrayList<SignalingMessage>()
        val gotMessage = CountDownLatch(1)
        @Volatile var link: PeerLink? = null
        override fun onPeerConnected(link: PeerLink) { this.link = link; connected.countDown() }
        override fun onPeerMessage(link: PeerLink, message: SignalingMessage) { received.add(message); gotMessage.countDown() }
        override fun onPeerDisconnected(link: PeerLink) {}
    }

    private var server: SignalingServer? = null

    @After fun tearDown() { server?.stop() }

    private fun startServer(code: String, rec: Recorder, guard: AuthGuard = AuthGuard()): Int {
        val s = SignalingServer(0, { code }, rec, guard, allowLoopback = true)
        s.start(); server = s
        return s.boundPort
    }

    private fun client(port: Int, code: String) = SignalingClient("127.0.0.1", port, code, "test-device", allowLoopback = true)

    private val noop = object : SignalingClientListener {
        override fun onMessage(message: SignalingMessage) {}
        override fun onClosed() {}
    }

    @Test fun codecRoundTrip() {
        val msgs = listOf(
            SignalingMessage.Offer("v=0"), SignalingMessage.Answer("v=0 a"),
            SignalingMessage.IceCandidate("0", 0, "candidate:1 1 udp 1 192.168.0.2 5000 typ host"),
            SignalingMessage.IceCandidate(null, 1, "c"), SignalingMessage.Bye("x"), SignalingMessage.Ping,
        )
        msgs.forEach { assertEquals(it, SignalingCodec.decode(SignalingCodec.encode(it))) }
    }

    @Test fun codecRejectsGarbage() {
        assertNull(SignalingCodec.decode("not json"))
        assertNull(SignalingCodec.decode("{\"t\":\"unknown\"}"))
        assertNull(SignalingCodec.decode("{\"t\":\"offer\"}"))
    }

    @Test fun correctCodeAuthenticatesAndMessagesFlowBothWays() {
        val rec = Recorder()
        val port = startServer("123456", rec)
        val got = CopyOnWriteArrayList<SignalingMessage>()
        val latch = CountDownLatch(1)
        val c = client(port, "123456")
        c.connect(object : SignalingClientListener {
            override fun onMessage(message: SignalingMessage) { got.add(message); latch.countDown() }
            override fun onClosed() {}
        })
        assertTrue(rec.connected.await(3, TimeUnit.SECONDS))
        c.send(SignalingMessage.Offer("sdp-offer"))
        assertTrue(rec.gotMessage.await(3, TimeUnit.SECONDS))
        assertEquals(SignalingMessage.Offer("sdp-offer"), rec.received[0])
        rec.link!!.send(SignalingMessage.Answer("sdp-answer"))
        assertTrue(latch.await(3, TimeUnit.SECONDS))
        assertEquals(SignalingMessage.Answer("sdp-answer"), got[0])
        c.close()
    }

    @Test fun wrongCodeIsRejected() {
        val rec = Recorder()
        val port = startServer("123456", rec)
        try { client(port, "000000").connect(noop); fail("expected failure") }
        catch (e: SignalingException) { assertEquals(ConnectError.WRONG_CODE, e.error) }
        assertEquals(1L, rec.connected.count)
    }

    @Test fun repeatedWrongCodesLockTheClientOut() {
        val rec = Recorder()
        val port = startServer("123456", rec, AuthGuard(maxFailures = 3, lockoutMillis = 60_000))
        repeat(3) { try { client(port, "000000").connect(noop) } catch (ignored: SignalingException) {} }
        // Auch der richtige Code wird jetzt abgelehnt.
        try { client(port, "123456").connect(noop); fail("expected lockout") }
        catch (e: SignalingException) { assertEquals(ConnectError.LOCKED, e.error) }
    }

    @Test fun unreachablePortIsReported() {
        try { client(1, "123456").connect(noop, 500); fail() }
        catch (e: SignalingException) { assertEquals(ConnectError.UNREACHABLE, e.error) }
    }

    @Test fun nonLocalHostIsRefusedWithoutConnecting() {
        try { SignalingClient("8.8.8.8", 48200, "123456", "d").connect(noop, 500); fail() }
        catch (e: SignalingException) { assertEquals(ConnectError.NOT_LOCAL, e.error) }
    }

    @Test fun statsQualityRules() {
        assertEquals(StreamQuality.GOOD, StreamStats(fps = 24, lossPercent = 0.1).quality)
        assertEquals(StreamQuality.MEDIUM, StreamStats(fps = 12, lossPercent = 1.0).quality)
        assertEquals(StreamQuality.POOR, StreamStats(fps = 3).quality)
        assertEquals(StreamQuality.POOR, StreamStats(fps = 30, lossPercent = 12.0).quality)
    }
}
