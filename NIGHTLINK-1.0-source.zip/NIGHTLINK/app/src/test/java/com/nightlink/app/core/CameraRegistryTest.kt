package com.nightlink.app.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class CameraRegistryTest {
    private fun cam(id: String, custom: String? = null) = SavedCamera(id, "Pixel", custom, "192.168.0.5", 48200)

    @Test fun encodeDecodeRoundTrip() {
        val list = listOf(cam("a", "Flur"), cam("b"))
        assertEquals(list, CameraRegistry.decode(CameraRegistry.encode(list)))
    }

    @Test fun decodeGarbageGivesEmptyList() {
        assertEquals(emptyList<SavedCamera>(), CameraRegistry.decode("not json"))
        assertEquals(emptyList<SavedCamera>(), CameraRegistry.decode(null))
    }

    @Test fun upsertNeverDuplicatesAndMovesToEnd() {
        val r = CameraRegistry.upsert(listOf(cam("a"), cam("b")), cam("a", "Neu"))
        assertEquals(listOf("b", "a"), r.map { it.id })
        assertEquals("Neu", r.last().customName)
    }

    @Test fun upsertCapsListSize() {
        var l = emptyList<SavedCamera>()
        repeat(CameraRegistry.MAX_SAVED + 5) { l = CameraRegistry.upsert(l, cam("id$it")) }
        assertEquals(CameraRegistry.MAX_SAVED, l.size)
    }

    @Test fun displayNameFallsBackToDeviceName() {
        assertEquals("Pixel", cam("a").displayName)
        assertEquals("Pixel", cam("a", "  ").displayName)
        assertEquals("Flur", cam("a", "Flur").displayName)
    }

    @Test fun sanitizeName() {
        assertNull(CameraRegistry.sanitizeName("   "))
        assertEquals("Flur", CameraRegistry.sanitizeName(" Flur\n"))
        assertEquals(32, CameraRegistry.sanitizeName("x".repeat(80))!!.length)
    }

    @Test fun uniqueLabels() {
        assertEquals(listOf("Pixel (1)", "Flur", "Pixel (2)"), CameraRegistry.uniqueLabels(listOf("Pixel", "Flur", "Pixel")))
        assertEquals(listOf("A", "B"), CameraRegistry.uniqueLabels(listOf("A", "B")))
    }
}
