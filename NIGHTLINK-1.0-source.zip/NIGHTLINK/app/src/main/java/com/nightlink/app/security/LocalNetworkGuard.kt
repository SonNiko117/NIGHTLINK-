package com.nightlink.app.security

import java.net.Inet6Address
import java.net.InetAddress
import java.security.SecureRandom

/** Verhindert, dass Adressen außerhalb des lokalen Netzwerks akzeptiert werden. */
object LocalNetworkGuard {
    /**
     * Erlaubt: private IPv4 (10/8, 172.16/12, 192.168/16), Link-Local (169.254/16, fe80::/10)
     * und IPv6 Unique-Local (fc00::/7). Loopback nur, wenn [allowLoopback] gesetzt ist (Tests).
     */
    fun isLocal(address: InetAddress?, allowLoopback: Boolean = false): Boolean {
        if (address == null) return false
        if (address.isAnyLocalAddress || address.isMulticastAddress) return false
        if (address.isLoopbackAddress) return allowLoopback
        if (address.isSiteLocalAddress || address.isLinkLocalAddress) return true
        if (address is Inet6Address) {
            val first = address.address[0].toInt() and 0xFE
            return first == 0xFC
        }
        return false
    }
}

object AccessCode {
    private val random = SecureRandom()

    /** 6-stelliger zufälliger Code. */
    fun generate(): String = "%06d".format(random.nextInt(1_000_000))

    /** Eingabe säubern: nur Ziffern, Leerzeichen/Trennzeichen entfernen. */
    fun normalize(input: String): String = input.filter { it in '0'..'9' }

    fun isWellFormed(code: String): Boolean =
        code.length == com.nightlink.app.core.NightlinkProtocol.ACCESS_CODE_LENGTH && code.all { it in '0'..'9' }
}
