package com.nightlink.app.core

enum class AppMode { CAMERA, CONTROL }

enum class CameraLens { FRONT, BACK }

enum class DeviceStatus { ONLINE, OFFLINE }

enum class WifiStatus { CONNECTED, DISCONNECTED }

/** Eine im Netzwerk erkannte Kamera (Sicht des Kontrollgeräts). */
data class RemoteCamera(
    val id: String,
    val name: String,
    val host: String,
    val port: Int,
    val status: DeviceStatus,
    val lastSeenMillis: Long,
)

/** Persistierte Einstellungen dieses Geräts. */
data class AppSettings(
    val deviceId: String,
    val cameraName: String,
    val lens: CameraLens,
    val mode: AppMode?,
    val accessCode: String,
) {
    /** Name, wie er im Netzwerk angekündigt wird (nie leer). */
    val advertisedName: String get() = cameraName.trim().ifBlank { DEFAULT_NAME }

    companion object {
        const val DEFAULT_NAME = "Camera"
        const val MAX_NAME_LENGTH = 32
        val EMPTY = AppSettings("", "", CameraLens.BACK, null, "")
    }
}
