package com.nightlink.app.transport

import androidx.camera.core.ImageProxy
import org.webrtc.JavaI420Buffer
import org.webrtc.VideoFrame
import java.nio.ByteBuffer

/** Wandelt CameraX-Frames (YUV_420_888) in WebRTC-I420-Frames um. */
object I420FrameConverter {
    fun convert(image: ImageProxy): VideoFrame {
        val w = image.width
        val h = image.height
        val cw = (w + 1) / 2
        val ch = (h + 1) / 2
        val buffer = JavaI420Buffer.allocate(w, h)
        val planes = image.planes
        copyPlane(planes[0].buffer, planes[0].rowStride, planes[0].pixelStride, buffer.dataY, buffer.strideY, w, h)
        copyPlane(planes[1].buffer, planes[1].rowStride, planes[1].pixelStride, buffer.dataU, buffer.strideU, cw, ch)
        copyPlane(planes[2].buffer, planes[2].rowStride, planes[2].pixelStride, buffer.dataV, buffer.strideV, cw, ch)
        return VideoFrame(buffer, image.imageInfo.rotationDegrees, System.nanoTime())
    }

    private fun copyPlane(src: ByteBuffer, rowStride: Int, pixelStride: Int, dst: ByteBuffer, dstStride: Int, w: Int, h: Int) {
        val s = src.duplicate()
        val row = ByteArray(w)
        for (r in 0 until h) {
            val base = r * rowStride
            if (pixelStride == 1) {
                s.position(base)
                s.get(row, 0, w)
            } else {
                for (c in 0 until w) row[c] = s.get(base + c * pixelStride)
            }
            dst.position(r * dstStride)
            dst.put(row, 0, w)
        }
    }
}
