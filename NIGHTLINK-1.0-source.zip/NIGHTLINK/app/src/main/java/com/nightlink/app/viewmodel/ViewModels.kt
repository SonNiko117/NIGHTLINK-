package com.nightlink.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.nightlink.app.core.AppMode
import com.nightlink.app.core.AppSettings
import com.nightlink.app.core.CameraRegistry
import com.nightlink.app.core.SavedCamera
import com.nightlink.app.core.CameraLens
import com.nightlink.app.core.RemoteCamera
import com.nightlink.app.core.WifiStatus
import com.nightlink.app.di.AppContainer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.Job
import com.nightlink.app.core.DeviceStatus
import com.nightlink.app.core.NightlinkProtocol
import com.nightlink.app.security.AccessCode
import com.nightlink.app.transport.ConnectError
import com.nightlink.app.transport.StreamStats
import com.nightlink.app.transport.ViewerSession
import com.nightlink.app.transport.ViewerState
import org.webrtc.VideoTrack

private const val STOP_TIMEOUT_MS = 5_000L

/** Geteilt von Startbildschirm und Einstellungen. */
class AppViewModel(private val c: AppContainer) : ViewModel() {
    val settings: StateFlow<AppSettings> = c.settings.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), AppSettings.EMPTY)
    val wifi: StateFlow<WifiStatus> = c.networkMonitor.wifiStatus
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), c.networkMonitor.currentStatus())

    fun setMode(mode: AppMode?) { viewModelScope.launch { c.settings.setMode(mode) } }
    fun setCameraName(name: String) { viewModelScope.launch { c.settings.setCameraName(name) } }
    fun setLens(lens: CameraLens) { viewModelScope.launch { c.settings.setLens(lens) } }
    fun regenerateAccessCode() { viewModelScope.launch { c.settings.regenerateAccessCode() } }

    // Update-System (GitHub Releases)
    val updateState = c.updateManager.state
    fun checkForUpdates() = c.updateManager.check()
    fun downloadUpdate() = c.updateManager.download()
    fun cancelUpdateDownload() = c.updateManager.cancelDownload()
    fun installUpdate() = c.updateManager.install()
    fun dismissUpdate() = c.updateManager.dismiss()
}

class CameraViewModel(private val c: AppContainer) : ViewModel() {
    val settings: StateFlow<AppSettings> = c.settings.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), AppSettings.EMPTY)
    val wifi: StateFlow<WifiStatus> = c.networkMonitor.wifiStatus
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), c.networkMonitor.currentStatus())
    val advertiseState = c.advertiser.state
    val runtime = c.cameraRuntime

    /** Läuft der Foreground Service? Wird nie persistiert: Aktivierung ist immer ausdrücklich. */
    val active: StateFlow<Boolean> = runtime.running
    val clients = runtime.clients
    val torchAvailable = runtime.torchAvailable
    val torchWanted = runtime.torchWanted
    val error = runtime.error

    fun start() = c.startCameraService()
    fun stop() = c.stopCameraService()
    fun setTorch(on: Boolean) = runtime.setTorchWanted(on)
    fun setCameraName(name: String) { viewModelScope.launch { c.settings.setCameraName(name) } }
    fun setLens(lens: CameraLens) { viewModelScope.launch { c.settings.setLens(lens) } }
    fun clearError() = runtime.setError(null)
}

/** Zusammengefasster Zustand der Videoverbindung der aktuell angezeigten Kamera. */
data class ViewerUi(
    val state: ViewerState = ViewerState.IDLE,
    val error: ConnectError? = null,
    val stats: StreamStats? = null,
    val video: VideoTrack? = null,
    val cameraName: String = "",
)

/** Ein Eintrag der unteren Kameraleiste. */
data class CameraTab(
    val id: String,
    val label: String,
    val state: ViewerState,
    val error: ConnectError?,
    val selected: Boolean,
)

/** Eine laufende Verbindung zu einer Kamera. Der Zugangscode bleibt nur im Speicher. */
private class ControlConn(
    val camera: RemoteCamera,
    val code: String,
    val session: ViewerSession,
    val watcher: Job,
)

@OptIn(ExperimentalCoroutinesApi::class)
class ControlViewModel(private val c: AppContainer) : ViewModel() {
    val wifi: StateFlow<WifiStatus> = c.networkMonitor.wifiStatus
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), c.networkMonitor.currentStatus())
    val cameras = c.browser.cameras
    val isScanning = c.browser.isScanning
    val errorCode = c.browser.errorCode
    val eglBase get() = c.videoTransport.eglBase

    /** Auswahl in der Kameraliste (vor dem Verbinden). Beim Start die zuletzt gewählte Kamera. */
    private val selectedId = MutableStateFlow<String?>(null)
    val selectedCamera: StateFlow<RemoteCamera?> = combine(cameras, selectedId) { list, id ->
        list.firstOrNull { it.id == id }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), null)

    private val savedCameras: StateFlow<List<SavedCamera>> = c.settings.savedCameras
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    /** Vom Nutzer vergebene Namen (ID -> Name). Ohne Eintrag gilt der echte Gerätename. */
    val names: StateFlow<Map<String, String>> = savedCameras
        .map { list -> list.mapNotNull { s -> s.customName?.takeIf { it.isNotBlank() }?.let { s.id to it } }.toMap() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyMap())

    /** Alle Verbindungen in Reihenfolge der unteren Leiste. */
    private val conns = MutableStateFlow<List<ControlConn>>(emptyList())
    /** ID der Kamera, deren Bild gerade angezeigt wird. Es gibt immer höchstens eine. */
    private val activeId = MutableStateFlow<String?>(null)
    /** Zuletzt gespeicherte Kamera aus der letzten App-Sitzung; wird beim erneuten Verbinden wieder angezeigt. */
    private var restoredId: String? = null

    private val _manualError = MutableStateFlow(false)
    val manualError: StateFlow<Boolean> = _manualError.asStateFlow()

    private fun labelFor(camera: RemoteCamera, saved: List<SavedCamera>): String =
        saved.firstOrNull { it.id == camera.id }?.customName?.trim()?.takeIf { it.isNotEmpty() } ?: camera.name

    /** Einträge der Kameraleiste inklusive Verbindungszustand jeder einzelnen Kamera. */
    val tabs: StateFlow<List<CameraTab>> = combine(conns, savedCameras) { list, saved -> list to saved }
        .flatMapLatest { (list, saved) ->
            if (list.isEmpty()) flowOf(emptyList<CameraTab>()) else {
                val labels = CameraRegistry.uniqueLabels(list.map { labelFor(it.camera, saved) })
                combine(
                    list.mapIndexed { i, conn ->
                        combine(conn.session.state, conn.session.error) { st, er ->
                            CameraTab(conn.camera.id, labels[i], st, er, false)
                        }
                    }
                ) { it.toList() }
            }
        }
        .combine(activeId) { list, active -> list.map { it.copy(selected = it.id == active) } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    /** Zustand der aktuell angezeigten Kamera (leer, wenn keine verbunden ist). */
    val viewer: StateFlow<ViewerUi> = combine(conns, activeId, savedCameras) { list, id, saved ->
        list.firstOrNull { it.camera.id == id }?.let { it to labelFor(it.camera, saved) }
    }.flatMapLatest { pair ->
        if (pair == null) flowOf(ViewerUi()) else {
            val s = pair.first.session
            combine(s.state, s.error, s.stats, s.remoteVideo) { st, e, stats, v -> ViewerUi(st, e, stats, v, pair.second) }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), ViewerUi())

    init {
        viewModelScope.launch {
            wifi.collect { if (it == WifiStatus.CONNECTED) c.browser.start() else c.browser.stop() }
        }
        viewModelScope.launch {
            val saved = c.settings.selectedCameraId.first()
            restoredId = saved
            if (selectedId.value == null) selectedId.value = saved
        }
    }

    fun select(camera: RemoteCamera) { selectedId.value = camera.id }

    fun rescan() {
        c.browser.stop()
        if (wifi.value == WifiStatus.CONNECTED) c.browser.start()
    }

    /** Verbindet mit einer gefundenen Kamera. Gibt false zurück, wenn der Code formal ungültig ist. */
    fun connect(camera: RemoteCamera, rawCode: String): Boolean {
        val code = AccessCode.normalize(rawCode)
        if (!AccessCode.isWellFormed(code)) return false
        return addConnection(camera, code)
    }

    /** Manuelle Verbindung per IP/Hostname. Ist die Adresse eine gefundene Kamera, wird deren echter Name/ID übernommen. */
    fun connectManual(host: String, rawCode: String): Boolean {
        val code = AccessCode.normalize(rawCode)
        val clean = host.trim()
        val valid = clean.isNotEmpty() && clean.length <= 253 && clean.all { it.isLetterOrDigit() || it in ".-:" }
        _manualError.value = !valid || !AccessCode.isWellFormed(code)
        if (_manualError.value) return false
        val known = c.browser.cameras.value.firstOrNull {
            it.host.equals(clean, ignoreCase = true) && it.port == NightlinkProtocol.SIGNALING_PORT
        }
        val cam = known ?: RemoteCamera(
            "manual:${clean.lowercase()}", clean, clean, NightlinkProtocol.SIGNALING_PORT,
            DeviceStatus.ONLINE, System.currentTimeMillis(),
        )
        return addConnection(cam, code)
    }

    /** Wechselt die angezeigte Kamera. Alle anderen Verbindungen bleiben bestehen. */
    fun switchTo(id: String) {
        if (activeId.value == id || conns.value.none { it.camera.id == id }) return
        restoredId = null
        applyActive(id)
    }

    /** Startet die angezeigte Kamera mit dem gemerkten Code neu. */
    fun reconnect() {
        val conn = conns.value.firstOrNull { it.camera.id == activeId.value } ?: return
        addConnection(conn.camera, conn.code)
    }

    /** Trennt NUR die angezeigte Kamera; die nächste verbundene wird angezeigt. */
    fun disconnect() {
        val id = activeId.value ?: return
        val list = conns.value
        val idx = list.indexOfFirst { it.camera.id == id }
        if (idx < 0) return
        val conn = list[idx]
        conn.watcher.cancel()
        conn.session.stop()
        val rest = list.filterNot { it === conn }
        conns.value = rest
        restoredId = null
        applyActive(rest.getOrNull(idx.coerceAtMost(rest.lastIndex))?.camera?.id)
    }

    /** Vergibt einen eigenen Namen für die angezeigte Kamera (leer = wieder Gerätename). */
    fun renameActive(name: String) {
        val conn = conns.value.firstOrNull { it.camera.id == activeId.value } ?: return
        viewModelScope.launch { c.settings.renameCamera(conn.camera, name) }
    }

    /** Name, der im Umbenennen-Dialog vorbelegt wird. */
    fun activeLabel(): String {
        val conn = conns.value.firstOrNull { it.camera.id == activeId.value } ?: return ""
        return labelFor(conn.camera, savedCameras.value)
    }

    fun activeDeviceName(): String =
        conns.value.firstOrNull { it.camera.id == activeId.value }?.camera?.name.orEmpty()

    private fun addConnection(camera: RemoteCamera, code: String): Boolean {
        // Duplikate: gleiche ID oder gleiche Adresse ersetzt den vorhandenen Eintrag statt einen zweiten anzulegen.
        val existing = conns.value.firstOrNull {
            it.camera.id == camera.id || (it.camera.host.equals(camera.host, true) && it.camera.port == camera.port)
        }
        if (existing == null && conns.value.size >= CameraRegistry.MAX_CONNECTED) return false

        // Bei gefundenen Kameras immer die aktuellste mDNS-Adresse verwenden.
        val fresh = c.browser.cameras.value.firstOrNull { it.id == camera.id && it.status == DeviceStatus.ONLINE } ?: camera

        existing?.let { it.watcher.cancel(); it.session.stop() }
        val session = c.videoTransport.createViewerSession(fresh, code, c.browser.ownDeviceId)
        // Erst nach erfolgreichem Videoaufbau merken (ein falscher Code landet nicht in der Liste).
        val watcher = viewModelScope.launch {
            session.state.first { it == ViewerState.STREAMING }
            c.settings.rememberCamera(fresh)
        }
        val conn = ControlConn(fresh, code, session, watcher)
        conns.value = if (existing == null) conns.value + conn else conns.value.map { if (it === existing) conn else it }

        // Die neu verbundene Kamera wird angezeigt – außer die aus der letzten Sitzung gemerkte ist schon aktiv.
        val keepRestored = restoredId != null && activeId.value == restoredId && fresh.id != restoredId
        if (!keepRestored) applyActive(fresh.id) else session.setActive(false)
        session.start()
        return true
    }

    /** Setzt die angezeigte Kamera; alle anderen laufen weiter, liefern aber keine Bilder an die UI. */
    private fun applyActive(id: String?) {
        activeId.value = id
        conns.value.forEach { it.session.setActive(it.camera.id == id) }
        if (id != null) {
            selectedId.value = id
            viewModelScope.launch { c.settings.setSelectedCamera(id) }
        }
    }

    override fun onCleared() {
        conns.value.forEach { it.watcher.cancel(); it.session.stop() }
        conns.value = emptyList()
        c.browser.stop()
    }
}

class NightlinkViewModelFactory(private val container: AppContainer) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = when {
        modelClass.isAssignableFrom(AppViewModel::class.java) -> AppViewModel(container)
        modelClass.isAssignableFrom(CameraViewModel::class.java) -> CameraViewModel(container)
        modelClass.isAssignableFrom(ControlViewModel::class.java) -> ControlViewModel(container)
        else -> throw IllegalArgumentException("Unknown ViewModel: ${modelClass.name}")
    } as T
}
