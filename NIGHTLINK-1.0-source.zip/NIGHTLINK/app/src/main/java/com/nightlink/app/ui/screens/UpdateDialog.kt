package com.nightlink.app.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.nightlink.app.R
import com.nightlink.app.ui.theme.NL
import com.nightlink.app.update.UpdateError
import com.nightlink.app.update.UpdateInfo
import com.nightlink.app.update.UpdateState
import com.nightlink.app.viewmodel.AppViewModel

/** Zeigt Ergebnis und Fortschritt der Update-Suche. Nichts zu zeigen (Idle) = kein Dialog. */
@Composable
fun UpdateDialog(state: UpdateState, vm: AppViewModel) {
    if (state is UpdateState.Idle) return

    val title: String
    var confirm: Pair<String, () -> Unit>? = null
    var dismissLabel = stringResource(R.string.close)
    var onDismissClick: () -> Unit = vm::dismissUpdate
    val body: @Composable () -> Unit

    when (state) {
        UpdateState.Idle -> return
        UpdateState.Checking -> {
            title = stringResource(R.string.update_checking)
            body = { CircularProgressIndicator(color = NL.Green) }
            dismissLabel = stringResource(R.string.cancel)
        }
        is UpdateState.UpToDate -> {
            title = stringResource(R.string.update_none_title)
            body = { BodyText(stringResource(R.string.update_none_text, state.currentVersion)) }
        }
        UpdateState.NoRelease -> {
            title = stringResource(R.string.update_none_title)
            body = { BodyText(stringResource(R.string.update_no_release)) }
        }
        is UpdateState.Available -> {
            title = stringResource(R.string.update_available_title)
            if (state.info.expectedSha256 != null) confirm = stringResource(R.string.update_download) to vm::downloadUpdate
            dismissLabel = stringResource(R.string.update_later)
            body = { ReleaseDetails(state.info) }
        }
        is UpdateState.Downloading -> {
            title = stringResource(R.string.update_downloading)
            dismissLabel = stringResource(R.string.cancel)
            onDismissClick = vm::cancelUpdateDownload
            body = {
                val frac = if (state.total > 0) (state.downloaded.toFloat() / state.total).coerceIn(0f, 1f) else null
                if (frac != null) LinearProgressIndicator(progress = { frac }, modifier = Modifier.fillMaxWidth(), color = NL.Green)
                else LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = NL.Green)
                Spacer(Modifier.height(8.dp))
                BodyText(
                    if (state.total > 0) stringResource(R.string.update_progress, mb(state.downloaded), mb(state.total), (frac!! * 100).toInt())
                    else stringResource(R.string.update_progress_unknown, mb(state.downloaded))
                )
            }
        }
        is UpdateState.Verifying -> {
            title = stringResource(R.string.update_verifying)
            body = { CircularProgressIndicator(color = NL.Green) }
            dismissLabel = stringResource(R.string.cancel)
            onDismissClick = vm::cancelUpdateDownload
        }
        is UpdateState.ReadyToInstall -> {
            title = stringResource(R.string.update_ready_title)
            confirm = stringResource(R.string.update_install) to vm::installUpdate
            body = {
                BodyText(stringResource(R.string.update_ready_text, state.info.release.version.toString()))
                if (state.permissionNeeded) {
                    Spacer(Modifier.height(10.dp))
                    Text(stringResource(R.string.update_permission_needed), style = MaterialTheme.typography.bodySmall, color = NL.Amber)
                }
            }
        }
        is UpdateState.Failed -> {
            title = stringResource(R.string.update_failed_title)
            if (state.info != null && state.error != UpdateError.INSTALL_FAILED) confirm = stringResource(R.string.update_retry) to vm::downloadUpdate
            else if (state.info == null) confirm = stringResource(R.string.update_retry) to vm::checkForUpdates
            body = {
                Text(stringResource(errorText(state.error)), style = MaterialTheme.typography.bodyMedium, color = NL.Red)
                state.detail?.takeIf { it.isNotBlank() }?.let {
                    Spacer(Modifier.height(6.dp))
                    BodyText(it)
                }
            }
        }
    }

    AlertDialog(
        onDismissRequest = { if (state !is UpdateState.Checking && state !is UpdateState.Downloading && state !is UpdateState.Verifying) vm.dismissUpdate() },
        containerColor = NL.Surface,
        title = { Text(title, color = NL.Green, style = MaterialTheme.typography.titleMedium) },
        text = { Column(Modifier.verticalScroll(rememberScrollState())) { body() } },
        confirmButton = { confirm?.let { (label, action) -> TextButton(onClick = action) { Text(label, color = NL.Green) } } },
        dismissButton = { TextButton(onClick = onDismissClick) { Text(dismissLabel, color = NL.TextDim) } },
    )
}

@Composable
private fun ReleaseDetails(info: UpdateInfo) {
    BodyText(stringResource(R.string.update_new_version, info.release.version.toString()))
    if (info.release.title.isNotBlank() && info.release.title != info.release.tag) {
        Spacer(Modifier.height(4.dp))
        Text(info.release.title, style = MaterialTheme.typography.labelLarge, color = NL.Text)
    }
    Spacer(Modifier.height(4.dp))
    BodyText(stringResource(R.string.update_size, mb(info.apk.size)))
    if (info.expectedSha256 == null) {
        Spacer(Modifier.height(6.dp))
        Text(stringResource(R.string.update_no_checksum_warning), style = MaterialTheme.typography.bodySmall, color = NL.Amber)
    }
    if (info.release.notes.isNotBlank()) {
        Spacer(Modifier.height(10.dp))
        Text(stringResource(R.string.update_notes), style = MaterialTheme.typography.labelMedium, color = NL.GreenDim)
        Spacer(Modifier.height(4.dp))
        Column(Modifier.heightIn(max = 220.dp).verticalScroll(rememberScrollState())) {
            BodyText(info.release.notes)
        }
    }
}

@Composable
private fun BodyText(text: String) =
    Text(text, style = MaterialTheme.typography.bodyMedium, color = NL.TextDim)

private fun mb(bytes: Long): String = "%.1f".format(bytes / 1_048_576.0)

private fun errorText(e: UpdateError): Int = when (e) {
    UpdateError.NOT_CONFIGURED -> R.string.uerr_not_configured
    UpdateError.NO_NETWORK -> R.string.uerr_no_network
    UpdateError.NETWORK -> R.string.uerr_network
    UpdateError.SERVER -> R.string.uerr_server
    UpdateError.RATE_LIMITED -> R.string.uerr_rate_limited
    UpdateError.PARSE -> R.string.uerr_parse
    UpdateError.NO_COMPATIBLE_APK -> R.string.uerr_no_apk
    UpdateError.INSECURE_SOURCE -> R.string.uerr_insecure
    UpdateError.STORAGE -> R.string.uerr_storage
    UpdateError.SIZE_MISMATCH -> R.string.uerr_size
    UpdateError.NO_CHECKSUM -> R.string.uerr_no_checksum
    UpdateError.CHECKSUM_MISMATCH -> R.string.uerr_checksum
    UpdateError.INVALID_APK -> R.string.uerr_invalid_apk
    UpdateError.WRONG_PACKAGE -> R.string.uerr_package
    UpdateError.NOT_NEWER -> R.string.uerr_not_newer
    UpdateError.SIGNATURE_MISMATCH -> R.string.uerr_signature
    UpdateError.INSTALL_FAILED -> R.string.uerr_install
}
