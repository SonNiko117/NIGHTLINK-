package com.nightlink.app.update

import java.io.File

/** Alles, was der Dialog über ein verfügbares Update wissen muss. */
data class UpdateInfo(
    val release: ReleaseInfo,
    val apk: ReleaseAsset,
    /** Erwartete SHA-256-Prüfsumme (aus GitHub-Digest oder .sha256-Datei), null = nicht vorhanden. */
    val expectedSha256: String?,
)

enum class UpdateError {
    NOT_CONFIGURED, NO_NETWORK, NETWORK, SERVER, RATE_LIMITED, PARSE, NO_COMPATIBLE_APK, INSECURE_SOURCE,
    STORAGE, SIZE_MISMATCH, NO_CHECKSUM, CHECKSUM_MISMATCH, INVALID_APK, WRONG_PACKAGE, NOT_NEWER, SIGNATURE_MISMATCH,
    INSTALL_FAILED,
}

sealed interface UpdateState {
    data object Idle : UpdateState
    data object Checking : UpdateState
    data class UpToDate(val currentVersion: String) : UpdateState
    data object NoRelease : UpdateState
    data class Available(val info: UpdateInfo) : UpdateState
    data class Downloading(val info: UpdateInfo, val downloaded: Long, val total: Long) : UpdateState
    data class Verifying(val info: UpdateInfo) : UpdateState
    data class ReadyToInstall(val info: UpdateInfo, val file: File, val permissionNeeded: Boolean = false) : UpdateState
    data class Failed(val error: UpdateError, val detail: String? = null, val info: UpdateInfo? = null) : UpdateState
}

class UpdateException(val error: UpdateError, val detail: String? = null, cause: Throwable? = null) : Exception(detail ?: error.name, cause)
