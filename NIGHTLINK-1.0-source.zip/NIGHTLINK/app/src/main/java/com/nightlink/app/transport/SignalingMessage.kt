package com.nightlink.app.transport

import org.json.JSONException
import org.json.JSONObject

/** Nachrichten des lokalen Signaling-Kanals (nach der Authentifizierung AES-GCM-verschlüsselt). */
sealed interface SignalingMessage {
    data class Offer(val sdp: String) : SignalingMessage
    data class Answer(val sdp: String) : SignalingMessage
    data class IceCandidate(val sdpMid: String?, val sdpMLineIndex: Int, val candidate: String) : SignalingMessage
    data class Bye(val reason: String = "") : SignalingMessage
    data object Ping : SignalingMessage
}

object SignalingCodec {
    fun encode(m: SignalingMessage): String {
        val o = JSONObject()
        when (m) {
            is SignalingMessage.Offer -> o.put("t", "offer").put("sdp", m.sdp)
            is SignalingMessage.Answer -> o.put("t", "answer").put("sdp", m.sdp)
            is SignalingMessage.IceCandidate -> {
                o.put("t", "ice").put("idx", m.sdpMLineIndex).put("c", m.candidate)
                if (m.sdpMid != null) o.put("mid", m.sdpMid)
            }
            is SignalingMessage.Bye -> o.put("t", "bye").put("r", m.reason)
            SignalingMessage.Ping -> o.put("t", "ping")
        }
        return o.toString()
    }

    /** Liefert null bei ungültigen/unbekannten Nachrichten – wirft nie. */
    fun decode(json: String): SignalingMessage? = try {
        val o = JSONObject(json)
        when (o.optString("t")) {
            "offer" -> o.optString("sdp").takeIf { it.isNotEmpty() }?.let { SignalingMessage.Offer(it) }
            "answer" -> o.optString("sdp").takeIf { it.isNotEmpty() }?.let { SignalingMessage.Answer(it) }
            "ice" -> o.optString("c").takeIf { it.isNotEmpty() }?.let {
                SignalingMessage.IceCandidate(if (o.has("mid")) o.optString("mid") else null, o.optInt("idx", 0), it)
            }
            "bye" -> SignalingMessage.Bye(o.optString("r"))
            "ping" -> SignalingMessage.Ping
            else -> null
        }
    } catch (ignored: JSONException) {
        null
    }
}
