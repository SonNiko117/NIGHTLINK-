package com.nightlink.app.core

import org.json.JSONArray
import org.json.JSONObject

/**
 * Eine Kamera, die dieses Kontrollgerät schon einmal erfolgreich verbunden hat.
 * Gespeichert werden nur Name und Adresse – NIE der Zugangscode.
 */
data class SavedCamera(
    val id: String,
    /** Tatsächlicher Gerätename, wie ihn die Kamera angekündigt hat. */
    val deviceName: String,
    /** Vom Nutzer vergebener Name (null = Gerätename verwenden). */
    val customName: String?,
    val host: String,
    val port: Int,
) {
    val displayName: String get() = customName?.trim()?.takeIf { it.isNotEmpty() } ?: deviceName
}

/** Reine Logik rund um die Kameraliste (ohne Android-Abhängigkeiten, daher unit-testbar). */
object CameraRegistry {
    /** Obergrenze gleichzeitig verbundener Kameras (jede hält einen eigenen WebRTC-Decoder-Pfad). */
    const val MAX_CONNECTED = 8
    const val MAX_SAVED = 16

    fun encode(list: List<SavedCamera>): String {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id)
                    .put("name", it.deviceName)
                    .put("custom", it.customName ?: JSONObject.NULL)
                    .put("host", it.host)
                    .put("port", it.port)
            )
        }
        return arr.toString()
    }

    fun decode(raw: String?): List<SavedCamera> {
        if (raw.isNullOrBlank()) return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull { i ->
                val o = arr.getJSONObject(i)
                val id = o.getString("id")
                if (id.isBlank()) return@mapNotNull null
                SavedCamera(
                    id = id,
                    deviceName = o.optString("name", ""),
                    customName = if (o.isNull("custom")) null else o.getString("custom"),
                    host = o.optString("host", ""),
                    port = o.optInt("port", NightlinkProtocol.SIGNALING_PORT),
                )
            }
        }.getOrDefault(emptyList())
    }

    /** Fügt hinzu oder ersetzt (gleiche ID = kein Duplikat). Das Ergebnis ist nach "zuletzt benutzt" sortiert. */
    fun upsert(list: List<SavedCamera>, item: SavedCamera): List<SavedCamera> =
        (list.filterNot { it.id == item.id } + item).takeLast(MAX_SAVED)

    /** Entfernt Steuerzeichen, kürzt und liefert null für leere Namen (= zurück zum Gerätenamen). */
    fun sanitizeName(raw: String): String? =
        raw.filter { !it.isISOControl() }.trim().take(AppSettings.MAX_NAME_LENGTH).ifBlank { null }

    /** Macht gleiche Anzeigenamen eindeutig: "Pixel", "Pixel" -> "Pixel (1)", "Pixel (2)". */
    fun uniqueLabels(names: List<String>): List<String> {
        val total = names.groupingBy { it }.eachCount()
        val seen = HashMap<String, Int>()
        return names.map { n ->
            if ((total[n] ?: 0) <= 1) n else {
                val k = (seen[n] ?: 0) + 1
                seen[n] = k
                "$n ($k)"
            }
        }
    }
}
