package com.nightlink.app.core

/**
 * Gemeinsame Protokollkonstanten. Eine spätere PC-Version muss dieselben
 * mDNS-Service-Typen, TXT-Felder und Signaling-Nachrichten verwenden.
 */
object NightlinkProtocol {
    /** mDNS/DNS-SD-Dienst (nur lokales Netzwerk). */
    const val SERVICE_TYPE = "_nightlink._tcp."
    const val SERVICE_NAME_PREFIX = "NIGHTLINK-"

    /** TXT-Felder des Dienstes. Der Zugangscode wird bewusst NIE angekündigt. */
    const val TXT_DEVICE_ID = "id"
    const val TXT_CAMERA_NAME = "name"
    const val TXT_PROTOCOL = "v"

    const val PROTOCOL_VERSION = 1

    /** TCP-Port des lokalen Signaling-Kanals (Kamera lauscht, Kontrollgerät verbindet). */
    const val SIGNALING_PORT = 48200

    /** Maximale Länge einer Signaling-Zeile (Schutz vor Speicher-Angriffen). SDP bleibt weit darunter. */
    const val MAX_LINE_CHARS = 64 * 1024

    const val ACCESS_CODE_LENGTH = 6
}
