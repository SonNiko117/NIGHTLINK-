package com.nightlink.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

object NL {
    val Black = Color(0xFF050605)
    val Surface = Color(0xFF0D0F0D)
    val SurfaceHigh = Color(0xFF151815)
    val Border = Color(0xFF1F3A26)
    val Green = Color(0xFF39FF6A)
    val GreenDim = Color(0xFF1F8A3C)
    val Amber = Color(0xFFFFB000)
    val Red = Color(0xFFFF3B30)
    val Text = Color(0xFFE3EAE3)
    val TextDim = Color(0xFF8A958A)
}

private val scheme = darkColorScheme(
    primary = NL.Green, onPrimary = NL.Black,
    secondary = NL.GreenDim, onSecondary = NL.Text,
    background = NL.Black, onBackground = NL.Text,
    surface = NL.Surface, onSurface = NL.Text,
    surfaceVariant = NL.SurfaceHigh, onSurfaceVariant = NL.TextDim,
    outline = NL.Border, error = NL.Red,
)

private val mono = FontFamily.Monospace
private val typography = Typography(
    headlineLarge = TextStyle(fontFamily = mono, fontWeight = FontWeight.Bold, fontSize = 34.sp, letterSpacing = 6.sp),
    titleLarge = TextStyle(fontFamily = mono, fontWeight = FontWeight.Bold, fontSize = 20.sp, letterSpacing = 3.sp),
    titleMedium = TextStyle(fontFamily = mono, fontWeight = FontWeight.Bold, fontSize = 16.sp, letterSpacing = 2.sp),
    labelLarge = TextStyle(fontFamily = mono, fontWeight = FontWeight.Bold, fontSize = 14.sp, letterSpacing = 2.sp),
    labelMedium = TextStyle(fontFamily = mono, fontWeight = FontWeight.Medium, fontSize = 12.sp, letterSpacing = 2.sp),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 22.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontSize = 12.sp, lineHeight = 17.sp),
)

@Composable
fun NightlinkTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, typography = typography, content = content)
}
