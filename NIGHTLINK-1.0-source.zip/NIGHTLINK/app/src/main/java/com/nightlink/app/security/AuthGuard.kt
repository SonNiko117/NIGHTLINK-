package com.nightlink.app.security

/**
 * Bremst das Erraten des Zugangscodes: nach [maxFailures] Fehlversuchen einer Adresse
 * wird diese für [lockoutMillis] gesperrt. Zusätzlich gibt es eine globale Grenze,
 * falls ein Angreifer mehrere Adressen nutzt.
 */
class AuthGuard(
    private val maxFailures: Int = 5,
    private val lockoutMillis: Long = 30_000,
    private val globalMaxFailures: Int = 20,
    private val clock: () -> Long = System::currentTimeMillis,
) {
    private class Entry(var failures: Int = 0, var lockedUntil: Long = 0)

    private val entries = HashMap<String, Entry>()
    private val global = Entry()

    @Synchronized
    fun isBlocked(key: String): Boolean {
        val now = clock()
        return (entries[key]?.lockedUntil ?: 0L) > now || global.lockedUntil > now
    }

    @Synchronized
    fun recordFailure(key: String) {
        val now = clock()
        bump(entries.getOrPut(key) { Entry() }, maxFailures, now)
        bump(global, globalMaxFailures, now)
    }

    @Synchronized
    fun recordSuccess(key: String) {
        entries.remove(key)
    }

    private fun bump(e: Entry, limit: Int, now: Long) {
        if (e.lockedUntil in 1..now) { e.failures = 0; e.lockedUntil = 0 }
        e.failures++
        if (e.failures >= limit) { e.lockedUntil = now + lockoutMillis; e.failures = 0 }
    }
}
