package com.nightlink.app.transport

import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.MediaStream
import org.webrtc.PeerConnection
import org.webrtc.DataChannel
import org.webrtc.RtpReceiver
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.suspendCancellableCoroutine

class SdpException(message: String) : Exception(message)

private open class SdpCallback : SdpObserver {
    override fun onCreateSuccess(sdp: SessionDescription?) {}
    override fun onSetSuccess() {}
    override fun onCreateFailure(error: String?) {}
    override fun onSetFailure(error: String?) {}
}

internal suspend fun PeerConnection.awaitCreateOffer(): SessionDescription =
    suspendCancellableCoroutine { c ->
        createOffer(object : SdpCallback() {
            override fun onCreateSuccess(sdp: SessionDescription?) {
                if (sdp != null) c.resume(sdp) else c.resumeWithException(SdpException("offer"))
            }
            override fun onCreateFailure(error: String?) { c.resumeWithException(SdpException("offer")) }
        }, MediaConstraints())
    }

internal suspend fun PeerConnection.awaitCreateAnswer(): SessionDescription =
    suspendCancellableCoroutine { c ->
        createAnswer(object : SdpCallback() {
            override fun onCreateSuccess(sdp: SessionDescription?) {
                if (sdp != null) c.resume(sdp) else c.resumeWithException(SdpException("answer"))
            }
            override fun onCreateFailure(error: String?) { c.resumeWithException(SdpException("answer")) }
        }, MediaConstraints())
    }

internal suspend fun PeerConnection.awaitSetLocal(sdp: SessionDescription) =
    suspendCancellableCoroutine<Unit> { c ->
        setLocalDescription(object : SdpCallback() {
            override fun onSetSuccess() { c.resume(Unit) }
            override fun onSetFailure(error: String?) { c.resumeWithException(SdpException("setLocal")) }
        }, sdp)
    }

internal suspend fun PeerConnection.awaitSetRemote(sdp: SessionDescription) =
    suspendCancellableCoroutine<Unit> { c ->
        setRemoteDescription(object : SdpCallback() {
            override fun onSetSuccess() { c.resume(Unit) }
            override fun onSetFailure(error: String?) { c.resumeWithException(SdpException("setRemote")) }
        }, sdp)
    }

/** Observer mit leeren Standardimplementierungen; Unterklassen überschreiben nur, was sie brauchen. */
internal open class SimplePcObserver : PeerConnection.Observer {
    override fun onSignalingChange(p0: PeerConnection.SignalingState?) {}
    override fun onIceConnectionChange(p0: PeerConnection.IceConnectionState?) {}
    override fun onIceConnectionReceivingChange(p0: Boolean) {}
    override fun onIceGatheringChange(p0: PeerConnection.IceGatheringState?) {}
    override fun onIceCandidate(p0: IceCandidate?) {}
    override fun onIceCandidatesRemoved(p0: Array<out IceCandidate>?) {}
    override fun onAddStream(p0: MediaStream?) {}
    override fun onRemoveStream(p0: MediaStream?) {}
    override fun onDataChannel(p0: DataChannel?) {}
    override fun onRenegotiationNeeded() {}
    override fun onAddTrack(p0: RtpReceiver?, p1: Array<out MediaStream>?) {}
}
