package com.nightlink.app.transport

import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.webrtc.IceCandidate
import org.webrtc.PeerConnection
import org.webrtc.SessionDescription
import org.webrtc.VideoFrame
import org.webrtc.VideoSource
import org.webrtc.VideoTrack
import java.util.concurrent.ConcurrentHashMap

/**
 * Kamera-Seite: ein gemeinsamer Video-Track, pro verbundenem Kontrollgerät eine PeerConnection.
 * Frames kommen von CameraX ([pushFrame]); Signaling-Ereignisse vom [SignalingServer].
 */
class CameraPublisher(
    private val env: WebRtcEnv,
    private val onClients: (List<ConnectedClient>) -> Unit,
) : SignalingServerListener {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val videoSource: VideoSource = env.factory.createVideoSource(false)
    private val track: VideoTrack = env.factory.createVideoTrack("nl-video", videoSource)
    private val peers = ConcurrentHashMap<String, Peer>()
    @Volatile private var released = false

    init { videoSource.capturerObserver.onCapturerStarted(true) }

    fun pushFrame(frame: VideoFrame) {
        if (!released) videoSource.capturerObserver.onFrameCaptured(frame)
    }

    override fun onPeerConnected(link: PeerLink) {
        peers[link.id]?.close()
        peers[link.id] = Peer(link)
        publish()
    }

    override fun onPeerMessage(link: PeerLink, message: SignalingMessage) {
        val peer = peers[link.id] ?: return
        scope.launch { runCatching { peer.handle(message) }.onFailure { Log.w(TAG, "peer message failed: ${it.javaClass.simpleName}"); link.close() } }
    }

    override fun onPeerDisconnected(link: PeerLink) {
        peers.remove(link.id)?.close()
        publish()
    }

    private fun publish() {
        onClients(peers.values.map { ConnectedClient(it.link.id.substringBefore('@'), it.link.remoteAddress, it.connected) })
    }

    fun release() {
        released = true
        peers.values.toList().forEach { it.close() }
        peers.clear()
        scope.cancel()
        videoSource.capturerObserver.onCapturerStopped()
        track.dispose()
        videoSource.dispose()
        onClients(emptyList())
    }

    private inner class Peer(val link: PeerLink) {
        private val mutex = Mutex()
        private var pc: PeerConnection? = null
        private var remoteSet = false
        private val pending = ArrayList<IceCandidate>()
        @Volatile var connected = false

        suspend fun handle(m: SignalingMessage) = mutex.withLock {
            when (m) {
                is SignalingMessage.Offer -> {
                    pc?.let { it.close(); it.dispose() }
                    remoteSet = false
                    val conn = env.factory.createPeerConnection(env.rtcConfig(), object : SimplePcObserver() {
                        override fun onIceCandidate(p0: IceCandidate?) {
                            p0 ?: return
                            link.send(SignalingMessage.IceCandidate(p0.sdpMid, p0.sdpMLineIndex, p0.sdp))
                        }
                        override fun onConnectionChange(p0: PeerConnection.PeerConnectionState?) {
                            connected = p0 == PeerConnection.PeerConnectionState.CONNECTED
                            if (p0 == PeerConnection.PeerConnectionState.FAILED) link.close()
                            publish()
                        }
                    }) ?: throw SdpException("pc")
                    pc = conn
                    conn.addTrack(track, listOf("nl-stream"))
                    conn.awaitSetRemote(SessionDescription(SessionDescription.Type.OFFER, m.sdp))
                    remoteSet = true
                    pending.forEach { conn.addIceCandidate(it) }
                    pending.clear()
                    val answer = conn.awaitCreateAnswer()
                    conn.awaitSetLocal(answer)
                    conn.setBitrate(300_000, 1_500_000, 3_000_000)
                    link.send(SignalingMessage.Answer(answer.description))
                }
                is SignalingMessage.IceCandidate -> {
                    val c = IceCandidate(m.sdpMid, m.sdpMLineIndex, m.candidate)
                    val conn = pc
                    if (conn != null && remoteSet) conn.addIceCandidate(c) else pending.add(c)
                }
                else -> Unit
            }
        }

        fun close() {
            link.close()
            runCatching { pc?.let { it.close(); it.dispose() } }
            pc = null
        }
    }

    private companion object { const val TAG = "NightlinkPublisher" }
}
