package com.nightlink.app.transport

import com.nightlink.app.core.RemoteCamera
import com.nightlink.app.core.WifiStatus
import kotlinx.coroutines.flow.Flow
import org.webrtc.EglBase

class WebRtcTransportFactory(
    private val env: WebRtcEnv,
    private val wifi: Flow<WifiStatus>,
) : VideoTransportFactory {
    override val eglBase: EglBase get() = env.eglBase

    override fun createViewerSession(camera: RemoteCamera, accessCode: String, ownDeviceId: String): ViewerSession =
        WebRtcViewerSession(env, camera, accessCode, ownDeviceId, wifi)

    override fun createPublisher(onClients: (List<ConnectedClient>) -> Unit): CameraPublisher =
        CameraPublisher(env, onClients)
}
