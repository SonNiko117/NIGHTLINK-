package com.nightlink.app.discovery

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import com.nightlink.app.core.NightlinkProtocol
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * mDNS-Ankündigung über den Android-NsdManager. Der Dienstname bleibt pro Gerät
 * stabil, der Kameraname steht im TXT-Feld "name". Bei Namensänderung wird der
 * Dienst neu registriert; Kontrollgeräte sehen ihn dann automatisch mit neuem Namen.
 */
class NsdCameraAdvertiser(context: Context) : CameraAdvertiser {
    private val nsd = context.getSystemService(NsdManager::class.java)
    private val lock = Any()
    private var listener: NsdManager.RegistrationListener? = null
    private var wanted: Pair<String, String>? = null

    private val _state = MutableStateFlow<AdvertiseState>(AdvertiseState.Idle)
    override val state: StateFlow<AdvertiseState> = _state.asStateFlow()

    override fun start(deviceId: String, cameraName: String) {
        synchronized(lock) {
        wanted = deviceId to cameraName
        val current = listener
        if (current != null) {
            // Erst abmelden; die Neuanmeldung folgt im onServiceUnregistered-Callback.
            _state.value = AdvertiseState.Registering
            runCatching { nsd?.unregisterService(current) }.onFailure { listener = null; register() }
        } else {
            register()
        }
        }
    }

    override fun stop() {
        synchronized(lock) {
        wanted = null
        val current = listener
        if (current != null) {
            runCatching { nsd?.unregisterService(current) }.onFailure { listener = null }
        }
        if (listener == null) _state.value = AdvertiseState.Idle
        }
    }

    private fun register() {
        val manager = nsd
        val (id, name) = wanted ?: return
        if (manager == null) {
            _state.value = AdvertiseState.Failed(-1)
            return
        }
        val info = NsdServiceInfo().apply {
            serviceName = NightlinkProtocol.SERVICE_NAME_PREFIX + id.take(8)
            serviceType = NightlinkProtocol.SERVICE_TYPE
            port = NightlinkProtocol.SIGNALING_PORT
            setAttribute(NightlinkProtocol.TXT_DEVICE_ID, id)
            setAttribute(NightlinkProtocol.TXT_CAMERA_NAME, name)
            setAttribute(NightlinkProtocol.TXT_PROTOCOL, NightlinkProtocol.PROTOCOL_VERSION.toString())
        }
        val l = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(serviceInfo: NsdServiceInfo) {
                synchronized(lock) { if (listener === this) _state.value = AdvertiseState.Active }
            }

            override fun onRegistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {
                synchronized(lock) {
                    if (listener === this) {
                        listener = null
                        _state.value = AdvertiseState.Failed(errorCode)
                    }
                }
            }

            override fun onServiceUnregistered(serviceInfo: NsdServiceInfo) {
                synchronized(lock) {
                    if (listener === this) listener = null
                    if (wanted != null) register() else _state.value = AdvertiseState.Idle
                }
            }

            override fun onUnregistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {
                synchronized(lock) {
                    if (listener === this) listener = null
                    _state.value = AdvertiseState.Failed(errorCode)
                }
            }
        }
        listener = l
        _state.value = AdvertiseState.Registering
        try {
            manager.registerService(info, NsdManager.PROTOCOL_DNS_SD, l)
        } catch (e: Exception) {
            listener = null
            _state.value = AdvertiseState.Failed(-2)
        }
    }
}
