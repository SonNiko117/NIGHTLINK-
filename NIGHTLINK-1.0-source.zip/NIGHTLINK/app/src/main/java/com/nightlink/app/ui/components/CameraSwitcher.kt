package com.nightlink.app.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.nightlink.app.R
import com.nightlink.app.transport.ViewerState
import com.nightlink.app.ui.theme.NL
import com.nightlink.app.viewmodel.CameraTab

private val TabShape = CutCornerShape(topEnd = 8.dp, bottomStart = 8.dp)

/** Farbe des Statuspunkts einer Kamera in der Leiste. */
fun tabStateColor(state: ViewerState) = when (state) {
    ViewerState.STREAMING -> NL.Green
    ViewerState.CONNECTING, ViewerState.RECONNECTING -> NL.Amber
    ViewerState.FAILED -> NL.Red
    ViewerState.IDLE -> NL.TextDim
}

/**
 * Untere Kameraleiste im Stil des FNAF-Kamerawechsels: ein Eintrag pro verbundener Kamera,
 * Antippen zeigt GENAU diese Kamera. Horizontal scrollbar, damit sie auch mit vielen Kameras
 * und auf kleinen Displays lesbar bleibt.
 */
@Composable
fun CameraSwitchBar(tabs: List<CameraTab>, onSelect: (String) -> Unit, modifier: Modifier = Modifier) {
    val listState = rememberLazyListState()
    val selectedIndex = tabs.indexOfFirst { it.selected }

    // Die gewählte Kamera immer sichtbar halten (ohne Animation).
    LaunchedEffect(selectedIndex, tabs.size) {
        if (selectedIndex >= 0 && listState.layoutInfo.visibleItemsInfo.none { it.index == selectedIndex }) {
            listState.scrollToItem(selectedIndex)
        }
    }

    Column(modifier.fillMaxWidth().background(NL.Surface)) {
        Box(Modifier.fillMaxWidth().height(1.dp).background(NL.Border))
        LazyRow(
            state = listState,
            modifier = Modifier.fillMaxWidth(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            itemsIndexed(tabs, key = { _, t -> t.id }) { index, tab ->
                CameraTabItem(index + 1, tab, onClick = { onSelect(tab.id) })
            }
        }
    }
}

@Composable
private fun CameraTabItem(number: Int, tab: CameraTab, onClick: () -> Unit) {
    val borderColor = if (tab.selected) NL.Green else NL.Border
    val textColor = if (tab.selected) NL.Green else NL.TextDim
    Row(
        Modifier
            .widthIn(min = 96.dp, max = 160.dp)
            .height(52.dp)
            .clip(TabShape)
            .background(if (tab.selected) NL.Green.copy(alpha = 0.14f) else NL.SurfaceHigh)
            .border(BorderStroke(if (tab.selected) 1.5.dp else 1.dp, borderColor), TabShape)
            .semantics { selected = tab.selected }
            .clickable(role = Role.Tab, onClick = onClick)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        StatusDot(tabStateColor(tab.state), pulsing = false, size = 8)
        Spacer(Modifier.size(10.dp))
        Column {
            Text("CAM %02d".format(number), style = MaterialTheme.typography.bodySmall, color = NL.TextDim, maxLines = 1)
            Text(
                tab.label, style = MaterialTheme.typography.labelMedium, color = textColor,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

/**
 * Kleines, unauffälliges Zahnrad oben rechts. Öffnet ein kurzes Menü – die bisherigen
 * Einstellungen bleiben darüber weiterhin erreichbar.
 */
@Composable
fun CameraGearMenu(onAddCameras: () -> Unit, onRename: () -> Unit, onSettings: () -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        IconButton(onClick = { open = true }, modifier = Modifier.size(40.dp)) {
            Icon(Icons.Filled.Settings, stringResource(R.string.camera_menu), tint = NL.TextDim, modifier = Modifier.size(20.dp))
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }, modifier = Modifier.background(NL.Surface)) {
            DropdownMenuItem(
                text = { Text(stringResource(R.string.menu_multi_connect), color = NL.Text, style = MaterialTheme.typography.bodyMedium) },
                onClick = { open = false; onAddCameras() },
            )
            DropdownMenuItem(
                text = { Text(stringResource(R.string.menu_rename), color = NL.Text, style = MaterialTheme.typography.bodyMedium) },
                onClick = { open = false; onRename() },
            )
            DropdownMenuItem(
                text = { Text(stringResource(R.string.menu_settings), color = NL.TextDim, style = MaterialTheme.typography.bodyMedium) },
                onClick = { open = false; onSettings() },
            )
        }
    }
}
