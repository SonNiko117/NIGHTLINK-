package com.nightlink.app.ui.components

import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.nightlink.app.R
import com.nightlink.app.core.AppSettings
import com.nightlink.app.core.CameraLens
import com.nightlink.app.service.CameraRuntime
import com.nightlink.app.ui.theme.NL

/** Kameraname + Front/Rück-Auswahl. Wird im Camera Setup und in den Einstellungen verwendet. */
@Composable
fun CameraSettingsFields(
    savedName: String,
    lens: CameraLens,
    onNameChange: (String) -> Unit,
    onLensChange: (CameraLens) -> Unit,
) {
    // Lokaler Entwurf verhindert Cursor-Springen durch asynchrones Speichern.
    var draft by rememberSaveable { mutableStateOf<String?>(null) }
    SectionLabel(stringResource(R.string.camera_name), Modifier)
    OutlinedTextField(
        value = draft ?: savedName,
        onValueChange = {
            val clean = it.filter { c -> !c.isISOControl() }.take(AppSettings.MAX_NAME_LENGTH)
            draft = clean
            onNameChange(clean)
        },
        singleLine = true,
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
        supportingText = { Text(stringResource(R.string.camera_name_hint)) },
        modifier = Modifier.fillMaxWidth(),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = NL.Green, unfocusedBorderColor = NL.Border,
            cursorColor = NL.Green, focusedTextColor = NL.Text, unfocusedTextColor = NL.Text,
            focusedSupportingTextColor = NL.TextDim, unfocusedSupportingTextColor = NL.TextDim,
        ),
    )
    SectionLabel(stringResource(R.string.lens), Modifier)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        LensButton(stringResource(R.string.lens_front), lens == CameraLens.FRONT, Modifier.weight(1f)) {
            onLensChange(CameraLens.FRONT)
        }
        LensButton(stringResource(R.string.lens_back), lens == CameraLens.BACK, Modifier.weight(1f)) {
            onLensChange(CameraLens.BACK)
        }
    }
}

@Composable
private fun LensButton(text: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    NightButton(
        text = text, onClick = onClick, modifier = modifier,
        kind = if (selected) ButtonKind.PRIMARY else ButtonKind.OUTLINE,
    )
}

/**
 * Vorschau der vom CameraService betriebenen Kamera. Die Kamera selbst gehört dem Service;
 * dieser Composable hängt nur seine Anzeige-Fläche an und löst sie beim Verlassen wieder.
 */
@Composable
fun CameraPreview(runtime: CameraRuntime, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val previewView = remember {
        PreviewView(context).apply { scaleType = PreviewView.ScaleType.FILL_CENTER }
    }
    DisposableEffect(previewView) {
        runtime.previewProvider.value = previewView.surfaceProvider
        onDispose { runtime.previewProvider.value = null }
    }
    AndroidView(factory = { previewView }, modifier = modifier)
}

/**
 * Meldet die aktuelle Display-Drehung (Hoch/Quer, auch 180° gedreht) an den Kamera-Service.
 * Die Activity wird bei Drehung nicht neu erstellt (configChanges), daher reagieren wir selbst per DisplayListener.
 */
@Composable
fun DisplayRotationEffect(runtime: CameraRuntime) {
    val context = LocalContext.current
    DisposableEffect(context, runtime) {
        val dm = context.getSystemService(android.hardware.display.DisplayManager::class.java)
        fun publish() {
            val rotation = dm?.getDisplay(android.view.Display.DEFAULT_DISPLAY)?.rotation
            if (rotation != null) runtime.displayRotation.value = rotation
        }
        val listener = object : android.hardware.display.DisplayManager.DisplayListener {
            override fun onDisplayAdded(displayId: Int) = Unit
            override fun onDisplayRemoved(displayId: Int) = Unit
            override fun onDisplayChanged(displayId: Int) { if (displayId == android.view.Display.DEFAULT_DISPLAY) publish() }
        }
        publish()
        dm?.registerDisplayListener(listener, android.os.Handler(android.os.Looper.getMainLooper()))
        onDispose { dm?.unregisterDisplayListener(listener) }
    }
}
