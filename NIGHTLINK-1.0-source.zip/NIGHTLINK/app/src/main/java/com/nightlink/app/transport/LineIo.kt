package com.nightlink.app.transport

import java.io.BufferedReader
import java.io.IOException

/** Liest eine Zeile mit Längenlimit. Gibt null bei Verbindungsende zurück. */
internal fun BufferedReader.readBoundedLine(maxChars: Int): String? {
    val sb = StringBuilder()
    while (true) {
        val c = read()
        if (c == -1) return if (sb.isEmpty()) null else sb.toString()
        if (c == '\n'.code) return sb.toString()
        if (c != '\r'.code) sb.append(c.toChar())
        if (sb.length > maxChars) throw IOException("line too long")
    }
}
