package com.nightlink.app.discovery

import com.nightlink.app.core.RemoteCamera
import kotlinx.coroutines.flow.StateFlow

sealed interface AdvertiseState {
    data object Idle : AdvertiseState
    data object Registering : AdvertiseState
    data object Active : AdvertiseState
    data class Failed(val code: Int) : AdvertiseState
}

/** Kamera-Seite: kündigt dieses Gerät im lokalen Netzwerk an. */
interface CameraAdvertiser {
    val state: StateFlow<AdvertiseState>

    /** Startet die Ankündigung oder aktualisiert sie (z. B. bei geändertem Kameranamen). */
    fun start(deviceId: String, cameraName: String)
    fun stop()
}

/** Kontroll-Seite: sucht Kameras im lokalen Netzwerk. */
interface CameraBrowser {
    val cameras: StateFlow<List<RemoteCamera>>
    val isScanning: StateFlow<Boolean>
    val errorCode: StateFlow<Int?>

    /** Eigene Geräte-ID, damit sich das Gerät nicht selbst listet. */
    var ownDeviceId: String

    fun start()
    fun stop()
}
