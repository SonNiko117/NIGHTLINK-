package com.nightlink.app.update

import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

/** Eine Datei eines GitHub-Releases. [sha256] stammt aus dem "digest"-Feld der API ("sha256:<hex>"), falls vorhanden. */
data class ReleaseAsset(
    val name: String,
    val downloadUrl: String,
    val size: Long,
    val sha256: String?,
)

data class ReleaseInfo(
    val tag: String,
    val version: AppVersion,
    val title: String,
    val notes: String,
    val pageUrl: String,
    val publishedAt: String,
    val preRelease: Boolean,
    val assets: List<ReleaseAsset>,
)

/** Fehler beim Lesen der GitHub-Antwort. */
class ReleaseParseException(message: String) : Exception(message)

object ReleaseParser {
    private val SHA256_HEX = Regex("^[0-9a-fA-F]{64}$")

    /** Einzelnes Release-Objekt. Drafts werden abgelehnt. */
    fun parseRelease(json: String): ReleaseInfo = parseObject(JSONObject(json))

    /** Liste von Releases (Endpunkt /releases): ungültige und Draft-Einträge werden übersprungen. */
    fun parseReleaseList(json: String): List<ReleaseInfo> {
        val arr = JSONArray(json)
        val out = ArrayList<ReleaseInfo>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            try { out += parseObject(o) } catch (ignored: ReleaseParseException) { } catch (ignored: JSONException) { }
        }
        return out
    }

    private fun parseObject(o: JSONObject): ReleaseInfo {
        if (o.optBoolean("draft", false)) throw ReleaseParseException("draft")
        val tag = o.optString("tag_name", "")
        val version = AppVersion.parse(tag) ?: throw ReleaseParseException("tag '$tag' ist keine Version")
        val assetsJson = o.optJSONArray("assets") ?: JSONArray()
        val assets = ArrayList<ReleaseAsset>()
        for (i in 0 until assetsJson.length()) {
            val a = assetsJson.optJSONObject(i) ?: continue
            val name = a.optString("name", "")
            val url = a.optString("browser_download_url", "")
            if (name.isEmpty() || url.isEmpty()) continue
            val digest = a.optString("digest", "")
            val sha = digest.removePrefix("sha256:").takeIf { digest.startsWith("sha256:") && SHA256_HEX.matches(it) }?.lowercase()
            assets += ReleaseAsset(name, url, a.optLong("size", -1L), sha)
        }
        return ReleaseInfo(
            tag = tag,
            version = version,
            title = o.optString("name", "").ifBlank { tag },
            notes = o.optString("body", "").trim(),
            pageUrl = o.optString("html_url", ""),
            publishedAt = o.optString("published_at", ""),
            preRelease = o.optBoolean("prerelease", false),
            assets = assets,
        )
    }
}

/** Auswahl der passenden APK eines Releases. Reine Logik, ohne Android-Abhängigkeit (testbar). */
object ApkSelector {
    /**
     * @param debugBuild true: nur "*debug*.apk"; false: nur APKs OHNE "debug" im Namen
     *                   (so wird nie eine Debug-APK an eine Release-App ausgeliefert und umgekehrt).
     * @param supportedAbis Reihenfolge der bevorzugten ABIs des Geräts (Build.SUPPORTED_ABIS).
     */
    fun select(assets: List<ReleaseAsset>, debugBuild: Boolean, supportedAbis: List<String>): ReleaseAsset? {
        val apks = assets.filter { it.name.endsWith(".apk", ignoreCase = true) }
            .filter { it.name.contains("debug", ignoreCase = true) == debugBuild }
        if (apks.isEmpty()) return null
        val abiSpecific = apks.filter { a -> ALL_ABIS.any { hasAbi(a.name, it) } }
        for (abi in supportedAbis) {
            abiSpecific.firstOrNull { hasAbi(it.name, abi) }?.let { return it }
        }
        // Universal-APK (ohne ABI-Angabe) bevorzugen; ABI-spezifische APKs, die nicht zum Gerät passen, nie wählen.
        return apks.firstOrNull { it !in abiSpecific }
    }

    /** ABI als abgegrenztes Token ("x86" passt nicht auf "x86_64"). */
    private fun hasAbi(name: String, abi: String): Boolean =
        Regex("(?<![A-Za-z0-9])" + Regex.escape(abi) + "(?![A-Za-z0-9_])", RegexOption.IGNORE_CASE).containsMatchIn(name)

    private val ALL_ABIS = listOf("arm64-v8a", "armeabi-v7a", "x86_64", "x86")

    /** Name der optionalen Prüfsummen-Datei zu einer APK: "<apk>.sha256". */
    fun checksumAssetFor(apk: ReleaseAsset, assets: List<ReleaseAsset>): ReleaseAsset? =
        assets.firstOrNull { it.name.equals(apk.name + ".sha256", ignoreCase = true) }
}
