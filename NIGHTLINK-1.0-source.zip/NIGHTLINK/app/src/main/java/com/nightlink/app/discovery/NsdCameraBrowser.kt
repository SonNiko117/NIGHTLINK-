package com.nightlink.app.discovery

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import com.nightlink.app.core.DeviceStatus
import com.nightlink.app.core.NightlinkProtocol
import com.nightlink.app.core.RemoteCamera
import com.nightlink.app.security.LocalNetworkGuard
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Sucht NIGHTLINK-Kameras per mDNS. Gefundene Dienste werden nacheinander
 * aufgelöst (NsdManager erlaubt auf älteren Android-Versionen nur ein
 * gleichzeitiges resolve). Verschwundene Kameras bleiben als OFFLINE sichtbar.
 */
@Suppress("DEPRECATION")
class NsdCameraBrowser(context: Context) : CameraBrowser {
    private val nsd = context.getSystemService(NsdManager::class.java)
    private val lock = Any()

    private val known = LinkedHashMap<String, RemoteCamera>()   // deviceId -> Kamera
    private val serviceToId = HashMap<String, String>()          // serviceName -> deviceId
    private val resolveQueue = ArrayDeque<NsdServiceInfo>()
    private var resolving = false
    private var listener: NsdManager.DiscoveryListener? = null

    private val _cameras = MutableStateFlow<List<RemoteCamera>>(emptyList())
    override val cameras: StateFlow<List<RemoteCamera>> = _cameras.asStateFlow()
    private val _scanning = MutableStateFlow(false)
    override val isScanning: StateFlow<Boolean> = _scanning.asStateFlow()
    private val _error = MutableStateFlow<Int?>(null)
    override val errorCode: StateFlow<Int?> = _error.asStateFlow()

    @Volatile
    override var ownDeviceId: String = ""

    override fun start() {
        synchronized(lock) { startLocked() }
    }

    private fun startLocked() {
        val manager = nsd
        if (listener != null) return
        if (manager == null) { _error.value = -1; return }
        _error.value = null
        markAllOffline()
        val l = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(serviceType: String) {
                synchronized(lock) { if (listener === this) _scanning.value = true }
            }

            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {
                synchronized(lock) {
                    if (listener === this) { listener = null; _scanning.value = false }
                    _error.value = errorCode
                }
            }

            override fun onServiceFound(serviceInfo: NsdServiceInfo) {
                if (!serviceInfo.serviceType.contains("_nightlink._tcp")) return
                synchronized(lock) { resolveQueue.addLast(serviceInfo) }
                resolveNext()
            }

            override fun onServiceLost(serviceInfo: NsdServiceInfo) {
                synchronized(lock) {
                    val id = serviceToId[serviceInfo.serviceName] ?: return
                    known[id]?.let { known[id] = it.copy(status = DeviceStatus.OFFLINE) }
                    publish()
                }
            }

            override fun onDiscoveryStopped(serviceType: String) {
                synchronized(lock) { if (listener == null || listener === this) _scanning.value = false }
            }

            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {
                synchronized(lock) { if (listener === this) listener = null; _scanning.value = false }
            }
        }
        listener = l
        try {
            manager.discoverServices(NightlinkProtocol.SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, l)
        } catch (e: Exception) {
            listener = null
            _error.value = -2
        }
    }

    override fun stop() {
        synchronized(lock) { stopLocked() }
    }

    private fun stopLocked() {
        val current = listener
        listener = null
        resolveQueue.clear()
        _scanning.value = false
        markAllOffline()
        if (current != null) runCatching { nsd?.stopServiceDiscovery(current) }
    }

    private fun resolveNext() {
        val manager = nsd ?: return
        val next = synchronized(lock) {
            if (resolving) return
            val item = resolveQueue.removeFirstOrNull() ?: return
            resolving = true
            item
        }
        val resolveListener = object : NsdManager.ResolveListener {
            override fun onResolveFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {
                synchronized(lock) { resolving = false }
                resolveNext()
            }

            override fun onServiceResolved(serviceInfo: NsdServiceInfo) {
                handleResolved(serviceInfo)
                synchronized(lock) { resolving = false }
                resolveNext()
            }
        }
        try {
            manager.resolveService(next, resolveListener)
        } catch (e: Exception) {
            synchronized(lock) { resolving = false }
        }
    }

    private fun handleResolved(info: NsdServiceInfo) {
        val host = info.host
        if (!LocalNetworkGuard.isLocal(host)) return   // nur lokale Adressen akzeptieren
        val attrs = info.attributes
        val id = attrs[NightlinkProtocol.TXT_DEVICE_ID]?.toString(Charsets.UTF_8)?.takeIf { it.isNotBlank() } ?: return
        if (id == ownDeviceId) return
        val name = attrs[NightlinkProtocol.TXT_CAMERA_NAME]?.toString(Charsets.UTF_8)?.takeIf { it.isNotBlank() }
            ?: info.serviceName
        synchronized(lock) {
            if (listener == null) return
            serviceToId[info.serviceName] = id
            known[id] = RemoteCamera(
                id = id,
                name = name.take(64),
                host = host.hostAddress.orEmpty(),
                port = info.port,
                status = DeviceStatus.ONLINE,
                lastSeenMillis = System.currentTimeMillis(),
            )
            publish()
        }
    }

    private fun markAllOffline() {
        known.keys.toList().forEach { id -> known[id] = known.getValue(id).copy(status = DeviceStatus.OFFLINE) }
        publish()
    }

    private fun publish() {
        _cameras.value = known.values.sortedWith(
            compareBy<RemoteCamera> { it.status != DeviceStatus.ONLINE }.thenBy { it.name.lowercase() }
        )
    }
}
