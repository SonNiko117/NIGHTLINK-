package com.nightlink.app.update

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import com.nightlink.app.BuildConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.ensureActive
import kotlin.coroutines.coroutineContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException

/**
 * GitHub-Update: prüft das neueste Release, lädt die passende APK, verifiziert sie und startet den
 * offiziellen Android-Paketinstaller (der Nutzer bestätigt die Installation). Keine Tokens, nur HTTPS,
 * nur GitHub-Hosts. Läuft im App-Scope, damit ein Download das Verlassen der Einstellungen übersteht.
 */
class UpdateManager(
    context: Context,
    private val repo: String = BuildConfig.UPDATE_REPO,
    private val debugBuild: Boolean = BuildConfig.DEBUG,
    private val baseVersionName: String = BuildConfig.BASE_VERSION_NAME,
) {
    private val appContext = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val _state = MutableStateFlow<UpdateState>(UpdateState.Idle)
    val state: StateFlow<UpdateState> = _state.asStateFlow()
    private var job: Job? = null

    private val updateDir get() = File(appContext.cacheDir, "updates")

    // Jede Aktion bekommt eine Generation; Schreibzugriffe auf den Zustand von veralteten (abgebrochenen) Jobs werden verworfen.
    private var generation = 0
    private fun nextGeneration(): Int = synchronized(this) { ++generation }
    private fun put(gen: Int, s: UpdateState) = synchronized(this) { if (gen == generation) _state.value = s }

    fun check() {
        if (job?.isActive == true) return
        val gen = nextGeneration()
        _state.value = UpdateState.Checking
        job = scope.launch {
            try {
                cleanup()
                put(gen, doCheck())
            } catch (e: CancellationException) { throw e
            } catch (e: UpdateException) { put(gen, UpdateState.Failed(e.error, e.detail))
            } catch (e: Exception) { put(gen, UpdateState.Failed(map(e), null)) }
        }
    }

    fun download() {
        val info = (_state.value as? UpdateState.Available)?.info ?: (_state.value as? UpdateState.Failed)?.info ?: return
        if (job?.isActive == true) return
        val gen = nextGeneration()
        if (info.expectedSha256 == null) {
            _state.value = UpdateState.Failed(UpdateError.NO_CHECKSUM, null, info)
            return
        }
        _state.value = UpdateState.Downloading(info, 0, info.apk.size)
        job = scope.launch {
            try {
                val file = downloadApk(info, gen)
                put(gen, UpdateState.Verifying(info))
                verify(file, info)
                put(gen, UpdateState.ReadyToInstall(info, file))
            } catch (e: CancellationException) {
                runCatching { cleanup() }
                throw e
            } catch (e: UpdateException) {
                runCatching { cleanup() }
                put(gen, UpdateState.Failed(e.error, e.detail, info))
            } catch (e: Exception) {
                runCatching { cleanup() }
                put(gen, UpdateState.Failed(map(e), null, info))
            }
        }
    }

    /** Bricht Download/Prüfung ab und geht zurück zur Update-Anzeige. */
    fun cancelDownload() {
        val info = when (val st = _state.value) {
            is UpdateState.Downloading -> st.info
            is UpdateState.Verifying -> st.info
            else -> return
        }
        nextGeneration()
        job?.cancel()
        _state.value = UpdateState.Available(info)
    }

    /** Schließt den Dialog; laufende Aktionen werden abgebrochen, geladene APKs gelöscht. */
    fun dismiss() {
        nextGeneration()
        job?.cancel()
        _state.value = UpdateState.Idle
        scope.launch { runCatching { cleanup() } }
    }

    /** Startet den Android-Installer. Fehlt die Erlaubnis "Unbekannte Apps installieren", wird stattdessen die passende Systemseite geöffnet. */
    fun install() {
        val ready = _state.value as? UpdateState.ReadyToInstall ?: return
        try {
            if (!appContext.packageManager.canRequestPackageInstalls()) {
                _state.value = ready.copy(permissionNeeded = true)
                appContext.startActivity(
                    Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${appContext.packageName}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                return
            }
            val uri = FileProvider.getUriForFile(appContext, "${appContext.packageName}.fileprovider", ready.file)
            val intent = Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            appContext.startActivity(intent)
            _state.value = ready.copy(permissionNeeded = false)
        } catch (e: Exception) {
            _state.value = UpdateState.Failed(UpdateError.INSTALL_FAILED, e.javaClass.simpleName, ready.info)
        }
    }

    // ---------------------------------------------------------------- Prüfen

    private fun doCheck(): UpdateState {
        if (!UpdateSecurity.isValidRepo(repo)) throw UpdateException(UpdateError.NOT_CONFIGURED)
        val current = AppVersion.parse(baseVersionName) ?: throw UpdateException(UpdateError.PARSE, "Eigene Version ungültig")
        val abis = Build.SUPPORTED_ABIS.toList()

        // Release-App: nur das als "latest" markierte, veröffentlichte Release (keine Pre-Releases, keine Drafts).
        // Debug-App: neueste Releases inkl. Pre-Releases, aber nur solche mit Debug-APK (zum Testen des Update-Wegs).
        val candidates: List<ReleaseInfo> = if (!debugBuild) {
            val (code, body) = httpGetText("https://api.github.com/repos/$repo/releases/latest")
            if (code == 404) return UpdateState.NoRelease
            listOf(parseOrThrow { ReleaseParser.parseRelease(body) })
        } else {
            val (code, body) = httpGetText("https://api.github.com/repos/$repo/releases?per_page=20")
            if (code == 404) return UpdateState.NoRelease
            parseOrThrow { ReleaseParser.parseReleaseList(body) }.sortedByDescending { it.version }
        }
        val usable = candidates.firstOrNull { r -> ApkSelector.select(r.assets, debugBuild, abis) != null }
        if (usable == null) {
            // Neueres Release ohne passende APK ist ein Fehler, ein nicht neueres ist "aktuell".
            val newest = candidates.maxByOrNull { it.version }
            if (newest != null && newest.version > current) throw UpdateException(UpdateError.NO_COMPATIBLE_APK)
            return if (candidates.isEmpty()) UpdateState.NoRelease else UpdateState.UpToDate(baseVersionName)
        }
        if (usable.version <= current) return UpdateState.UpToDate(baseVersionName)

        val apk = ApkSelector.select(usable.assets, debugBuild, abis)!!
        if (!UpdateSecurity.isRepoDownloadUrl(apk.downloadUrl, repo)) throw UpdateException(UpdateError.INSECURE_SOURCE)
        var sha = apk.sha256
        if (sha == null) {
            ApkSelector.checksumAssetFor(apk, usable.assets)?.let { sum ->
                if (!UpdateSecurity.isRepoDownloadUrl(sum.downloadUrl, repo)) throw UpdateException(UpdateError.INSECURE_SOURCE)
                val (c, text) = httpGetText(sum.downloadUrl, maxBytes = 4096)
                if (c == 200) sha = UpdateSecurity.parseChecksumFile(text)
            }
        }
        return UpdateState.Available(UpdateInfo(usable, apk, sha))
    }

    private inline fun <T> parseOrThrow(block: () -> T): T = try { block() } catch (e: Exception) {
        if (e is CancellationException) throw e
        throw UpdateException(UpdateError.PARSE, e.javaClass.simpleName)
    }

    // ---------------------------------------------------------------- HTTP

    /** GET mit manuell geprüften Weiterleitungen (nur HTTPS + erlaubte Hosts). Liefert (Statuscode, Text); 404 wird zurückgegeben, andere Fehler werfen. */
    private fun httpGetText(url: String, maxBytes: Int = 2 * 1024 * 1024): Pair<Int, String> {
        val conn = open(url)
        try {
            val code = conn.responseCode
            if (code == 404) return 404 to ""
            checkStatus(conn, code)
            val bos = java.io.ByteArrayOutputStream()
            conn.inputStream.use { input ->
                val buf = ByteArray(8 * 1024)
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    bos.write(buf, 0, n)
                    if (bos.size() > maxBytes) throw UpdateException(UpdateError.PARSE, "Antwort zu groß")
                }
            }
            return code to bos.toString("UTF-8")
        } finally { conn.disconnect() }
    }

    private fun checkStatus(conn: HttpURLConnection, code: Int) {
        when {
            code == 200 -> Unit
            code == 403 || code == 429 -> {
                if (conn.getHeaderField("X-RateLimit-Remaining") == "0" || code == 429) throw UpdateException(UpdateError.RATE_LIMITED)
                throw UpdateException(UpdateError.SERVER, "HTTP $code")
            }
            else -> throw UpdateException(UpdateError.SERVER, "HTTP $code")
        }
    }

    /** Öffnet die Verbindung und folgt höchstens 5 Weiterleitungen; jede Ziel-URL wird gegen die Allowlist geprüft. */
    private fun open(startUrl: String): HttpURLConnection {
        var url = startUrl
        repeat(6) {
            if (!UpdateSecurity.isAllowedUrl(url)) throw UpdateException(UpdateError.INSECURE_SOURCE)
            val conn = URL(url).openConnection() as HttpURLConnection
            conn.instanceFollowRedirects = false
            conn.connectTimeout = 15_000
            conn.readTimeout = 30_000
            conn.setRequestProperty("Accept", if (url.startsWith("https://api.github.com/")) "application/vnd.github+json" else "application/octet-stream")
            conn.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
            conn.setRequestProperty("User-Agent", "NIGHTLINK-Android/${BuildConfig.VERSION_NAME}")
            val code = conn.responseCode
            if (code in 300..399 && code != 304) {
                val loc = conn.getHeaderField("Location")
                conn.disconnect()
                if (loc.isNullOrEmpty()) throw UpdateException(UpdateError.SERVER, "Weiterleitung ohne Ziel")
                url = URL(URL(url), loc).toString()
            } else return conn
        }
        throw UpdateException(UpdateError.SERVER, "Zu viele Weiterleitungen")
    }

    // ---------------------------------------------------------------- Download

    private suspend fun downloadApk(info: UpdateInfo, gen: Int): File = withContext(Dispatchers.IO) {
        if (!UpdateSecurity.isRepoDownloadUrl(info.apk.downloadUrl, repo)) throw UpdateException(UpdateError.INSECURE_SOURCE)
        val dir = updateDir.also { it.mkdirs() }
        val part = File(dir, "nightlink-update.apk.part")
        val target = File(dir, "nightlink-update.apk")
        part.delete(); target.delete()
        val conn = open(info.apk.downloadUrl)
        // Abbruch unterbricht ein blockierendes read() sofort, statt bis zum Timeout zu warten.
        val cancelHook = coroutineContext[Job]?.invokeOnCompletion { if (it is CancellationException) conn.disconnect() }
        try {
            checkStatus(conn, conn.responseCode)
            val total = conn.contentLengthLong.takeIf { it > 0 } ?: info.apk.size
            var done = 0L
            var lastEmit = 0L
            val buf = ByteArray(64 * 1024)
            conn.inputStream.use { input ->
                FileOutputStream(part).use { out ->
                    while (true) {
                        ensureActive()
                        val n = try { input.read(buf) } catch (e: IOException) { throw UpdateException(UpdateError.NETWORK, null, e) }
                        if (n < 0) break
                        try { out.write(buf, 0, n) } catch (e: IOException) { throw UpdateException(UpdateError.STORAGE, null, e) }
                        done += n
                        val now = System.nanoTime()
                        if (now - lastEmit > 100_000_000L) {
                            lastEmit = now
                            put(gen, UpdateState.Downloading(info, done, total))
                        }
                    }
                    try { out.fd.sync() } catch (e: IOException) { throw UpdateException(UpdateError.STORAGE, null, e) }
                }
            }
            put(gen, UpdateState.Downloading(info, done, total))
            if (info.apk.size > 0 && part.length() != info.apk.size) throw UpdateException(UpdateError.SIZE_MISMATCH)
            if (!part.renameTo(target)) throw UpdateException(UpdateError.STORAGE)
            target
        } finally { cancelHook?.dispose(); conn.disconnect() }
    }

    // ---------------------------------------------------------------- Verifikation

    private suspend fun verify(file: File, info: UpdateInfo) = withContext(Dispatchers.IO) {
        // 1) Prüfsumme (zwingend): schützt vor beschädigtem/manipuliertem Download.
        val expected = info.expectedSha256 ?: throw UpdateException(UpdateError.NO_CHECKSUM)
        if (!UpdateSecurity.sha256Hex(file).equals(expected, ignoreCase = true)) throw UpdateException(UpdateError.CHECKSUM_MISMATCH)

        // 2) APK lesbar, gleiche Paketkennung, höherer versionCode, gleiche Signatur wie die installierte App.
        val pm = appContext.packageManager
        val flags = PackageManager.GET_SIGNING_CERTIFICATES
        val archive = pm.getPackageArchiveInfo(file.absolutePath, flags) ?: throw UpdateException(UpdateError.INVALID_APK)
        if (archive.packageName != appContext.packageName) throw UpdateException(UpdateError.WRONG_PACKAGE, archive.packageName)
        val installed = pm.getPackageInfo(appContext.packageName, flags)
        if (archive.longVersionCode <= installed.longVersionCode) throw UpdateException(UpdateError.NOT_NEWER)

        val newInfo = archive.signingInfo ?: throw UpdateException(UpdateError.SIGNATURE_MISMATCH)
        val oldInfo = installed.signingInfo ?: throw UpdateException(UpdateError.SIGNATURE_MISMATCH)
        val oldSigners = oldInfo.apkContentsSigners.map { sha256(it.toByteArray()) }.toSet()
        val newSigners = (if (newInfo.hasMultipleSigners()) newInfo.apkContentsSigners else newInfo.signingCertificateHistory)
            .map { sha256(it.toByteArray()) }.toSet()
        if (oldSigners.isEmpty() || !newSigners.containsAll(oldSigners)) throw UpdateException(UpdateError.SIGNATURE_MISMATCH)
    }

    private fun sha256(b: ByteArray) = java.security.MessageDigest.getInstance("SHA-256").digest(b).toList()

    // ---------------------------------------------------------------- Hilfen

    private fun cleanup() { updateDir.listFiles()?.forEach { it.delete() } }

    private fun map(e: Exception): UpdateError = when (e) {
        is UnknownHostException -> UpdateError.NO_NETWORK
        is SocketTimeoutException -> UpdateError.NETWORK
        is IOException -> UpdateError.NETWORK
        else -> UpdateError.NETWORK
    }
}
