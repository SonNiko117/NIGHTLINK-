package com.nightlink.app.transport

import com.nightlink.app.core.RemoteCamera
import com.nightlink.app.core.WifiStatus
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.NonCancellable
import org.webrtc.IceCandidate
import org.webrtc.MediaStreamTrack
import org.webrtc.PeerConnection
import org.webrtc.RtpTransceiver
import org.webrtc.SessionDescription
import org.webrtc.VideoTrack

/**
 * Kontrollgerät: verbindet (authentifiziert) per Signaling, baut WebRTC auf und empfängt Video.
 * Bei Verbindungsverlust wird mit Backoff neu verbunden, sobald WLAN verfügbar ist.
 * Falscher Code / Sperre beenden den Versuch sofort (kein automatisches Wiederholen).
 */
class WebRtcViewerSession(
    private val env: WebRtcEnv,
    private val camera: RemoteCamera,
    private val accessCode: String,
    private val ownDeviceId: String,
    private val wifi: Flow<WifiStatus>,
) : ViewerSession {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null

    private val _state = MutableStateFlow(ViewerState.IDLE)
    override val state: StateFlow<ViewerState> = _state.asStateFlow()
    private val _error = MutableStateFlow<ConnectError?>(null)
    override val error: StateFlow<ConnectError?> = _error.asStateFlow()
    private val _stats = MutableStateFlow<StreamStats?>(null)
    override val stats: StateFlow<StreamStats?> = _stats.asStateFlow()
    private val _video = MutableStateFlow<VideoTrack?>(null)
    override val remoteVideo: StateFlow<VideoTrack?> = _video.asStateFlow()

    private sealed interface Outcome {
        data class Fatal(val error: ConnectError) : Outcome
        data class Retry(val wasStreaming: Boolean, val error: ConnectError?) : Outcome
    }

    @Volatile private var active = true

    override fun setActive(active: Boolean) {
        this.active = active
        // Deaktivierte Tracks liefern keine Frames an Renderer; die Verbindung selbst bleibt bestehen.
        _video.value?.let { runCatching { it.setEnabled(active) } }
    }

    override fun start() {
        if (job != null) return
        job = scope.launch { runLoop() }
    }

    override fun stop() {
        job?.cancel()
        job = null
        scope.cancel()
        _video.value = null
        _stats.value = null
        _state.value = ViewerState.IDLE
    }

    private suspend fun runLoop() {
        var everStreamed = false
        var failures = 0
        while (scope.isActive) {
            _state.value = if (everStreamed) ViewerState.RECONNECTING else ViewerState.CONNECTING
            when (val o = runOnce()) {
                is Outcome.Fatal -> { _error.value = o.error; _state.value = ViewerState.FAILED; return }
                is Outcome.Retry -> {
                    if (o.wasStreaming) { everStreamed = true; failures = 0 } else failures++
                    if (!everStreamed && failures >= MAX_INITIAL_FAILURES) {
                        _error.value = o.error ?: ConnectError.UNREACHABLE
                        _state.value = ViewerState.FAILED
                        return
                    }
                }
            }
            _state.value = ViewerState.RECONNECTING
            delay((1_000L shl failures.coerceIn(0, 3)).coerceAtMost(8_000L))
            wifi.first { it == WifiStatus.CONNECTED }
        }
    }

    private suspend fun runOnce(): Outcome {
        val closed = CompletableDeferred<Unit>()
        val ice = Mutex()
        val pendingIce = ArrayList<IceCandidate>()
        var remoteSet = false
        var streaming = false
        var pc: PeerConnection? = null
        val client = SignalingClient(camera.host, camera.port, accessCode, ownDeviceId)
        var statsJob: Job? = null
        try {
            val answerSignal = CompletableDeferred<SessionDescription>()
            try {
                client.connect(object : SignalingClientListener {
                    override fun onMessage(message: SignalingMessage) {
                        when (message) {
                            is SignalingMessage.Answer -> answerSignal.complete(SessionDescription(SessionDescription.Type.ANSWER, message.sdp))
                            is SignalingMessage.IceCandidate -> scope.launch {
                                ice.withLock {
                                    val c = IceCandidate(message.sdpMid, message.sdpMLineIndex, message.candidate)
                                    val conn = pc
                                    if (conn != null && remoteSet) conn.addIceCandidate(c) else pendingIce.add(c)
                                }
                            }
                            else -> Unit
                        }
                    }
                    override fun onClosed() { closed.complete(Unit) }
                })
            } catch (e: SignalingException) {
                return when (e.error) {
                    ConnectError.WRONG_CODE, ConnectError.LOCKED, ConnectError.NOT_LOCAL, ConnectError.BUSY -> Outcome.Fatal(e.error)
                    else -> Outcome.Retry(false, e.error)
                }
            }

            val conn = env.factory.createPeerConnection(env.rtcConfig(), object : SimplePcObserver() {
                override fun onIceCandidate(p0: IceCandidate?) {
                    p0 ?: return
                    client.send(SignalingMessage.IceCandidate(p0.sdpMid, p0.sdpMLineIndex, p0.sdp))
                }
                override fun onTrack(transceiver: RtpTransceiver?) {
                    (transceiver?.receiver?.track() as? VideoTrack)?.let {
                        runCatching { it.setEnabled(active) }
                        _video.value = it
                    }
                }
                override fun onConnectionChange(p0: PeerConnection.PeerConnectionState?) {
                    when (p0) {
                        PeerConnection.PeerConnectionState.CONNECTED -> { streaming = true; _state.value = ViewerState.STREAMING }
                        PeerConnection.PeerConnectionState.FAILED, PeerConnection.PeerConnectionState.CLOSED -> closed.complete(Unit)
                        PeerConnection.PeerConnectionState.DISCONNECTED -> scope.launch {
                            delay(DISCONNECT_GRACE_MS)
                            if (_state.value != ViewerState.STREAMING) closed.complete(Unit)
                        }
                        else -> Unit
                    }
                    if (p0 == PeerConnection.PeerConnectionState.DISCONNECTED) _state.value = ViewerState.RECONNECTING
                }
            }) ?: return Outcome.Retry(false, ConnectError.PROTOCOL)
            pc = conn

            conn.addTransceiver(
                MediaStreamTrack.MediaType.MEDIA_TYPE_VIDEO,
                RtpTransceiver.RtpTransceiverInit(RtpTransceiver.RtpTransceiverDirection.RECV_ONLY),
            )
            val offer = conn.awaitCreateOffer()
            conn.awaitSetLocal(offer)
            client.send(SignalingMessage.Offer(offer.description))

            val answer = kotlinx.coroutines.withTimeoutOrNull(ANSWER_TIMEOUT_MS) {
                // Auf Antwort ODER Verbindungsende warten.
                val winner = CompletableDeferred<SessionDescription?>()
                val a = scope.launch { winner.complete(answerSignal.await()) }
                val c = scope.launch { closed.await(); winner.complete(null) }
                try { winner.await() } finally { a.cancel(); c.cancel() }
            } ?: return Outcome.Retry(false, ConnectError.UNREACHABLE)
            conn.awaitSetRemote(answer)
            ice.withLock {
                remoteSet = true
                pendingIce.forEach { conn.addIceCandidate(it) }
                pendingIce.clear()
            }
            statsJob = scope.launch { pollStats(conn) }

            closed.await()
            return Outcome.Retry(streaming, ConnectError.UNREACHABLE)
        } catch (e: SdpException) {
            return Outcome.Retry(streaming, ConnectError.PROTOCOL)
        } finally {
            withContext(NonCancellable) {
                statsJob?.cancel()
                _video.value = null
                _stats.value = null
                client.close()
                runCatching { pc?.let { it.close(); it.dispose() } }
            }
        }
    }

    private suspend fun pollStats(pc: PeerConnection) {
        var lastBytes = -1.0
        var lastTime = 0L
        var lastLost = 0.0
        var lastPackets = 0.0
        while (scope.isActive) {
            delay(1_000)
            if (!active) { lastBytes = -1.0; continue }   // Hintergrund-Kamera: keine Statistik-Abfragen
            val report = suspendReport(pc) ?: continue
            var w = 0; var h = 0; var fps = 0; var bytes = -1.0; var lost = 0.0; var packets = 0.0
            var rtt: Int? = null
            for (s in report.statsMap.values) {
                val m = s.members
                if (s.type == "inbound-rtp" && m["kind"] == "video") {
                    w = (m["frameWidth"] as? Number)?.toInt() ?: 0
                    h = (m["frameHeight"] as? Number)?.toInt() ?: 0
                    fps = (m["framesPerSecond"] as? Number)?.toDouble()?.toInt() ?: 0
                    bytes = (m["bytesReceived"] as? Number)?.toDouble() ?: -1.0
                    lost = (m["packetsLost"] as? Number)?.toDouble() ?: 0.0
                    packets = (m["packetsReceived"] as? Number)?.toDouble() ?: 0.0
                } else if (s.type == "candidate-pair" && m["state"] == "succeeded" && m["nominated"] == true) {
                    rtt = (m["currentRoundTripTime"] as? Number)?.toDouble()?.let { (it * 1000).toInt() }
                }
            }
            val now = System.nanoTime()
            val kbps = if (lastBytes >= 0 && bytes >= lastBytes && now > lastTime)
                ((bytes - lastBytes) * 8 / 1000.0 / ((now - lastTime) / 1e9)).toInt() else 0
            val dLost = (lost - lastLost).coerceAtLeast(0.0)
            val dPk = (packets - lastPackets).coerceAtLeast(0.0)
            val loss = if (dLost + dPk > 0) dLost / (dLost + dPk) * 100 else 0.0
            lastBytes = bytes; lastTime = now; lastLost = lost; lastPackets = packets
            _stats.value = StreamStats(w, h, fps, kbps, rtt, loss)
        }
    }

    private suspend fun suspendReport(pc: PeerConnection): org.webrtc.RTCStatsReport? =
        kotlinx.coroutines.suspendCancellableCoroutine { c ->
            try {
                pc.getStats { r -> if (c.isActive) c.resumeWith(Result.success(r)) }
            } catch (ignored: Exception) {
                if (c.isActive) c.resumeWith(Result.success(null))
            }
        }

    private companion object {
        const val MAX_INITIAL_FAILURES = 3
        const val ANSWER_TIMEOUT_MS = 10_000L
        const val DISCONNECT_GRACE_MS = 5_000L
    }
}
