package com.nightlink.app.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.nightlink.app.NightlinkApplication
import com.nightlink.app.core.AppMode
import com.nightlink.app.ui.screens.CameraScreen
import com.nightlink.app.ui.screens.ControlScreen
import com.nightlink.app.ui.screens.SettingsScreen
import com.nightlink.app.ui.screens.StartScreen
import com.nightlink.app.viewmodel.AppViewModel
import com.nightlink.app.viewmodel.CameraViewModel
import com.nightlink.app.viewmodel.ControlViewModel
import com.nightlink.app.viewmodel.NightlinkViewModelFactory

object Routes {
    const val START = "start"
    const val CAMERA = "camera"
    const val CONTROL = "control"
    const val SETTINGS = "settings"
}

@Composable
fun NightlinkNavHost() {
    val app = LocalContext.current.applicationContext as NightlinkApplication
    val factory = remember { NightlinkViewModelFactory(app.container) }
    val nav = rememberNavController()

    NavHost(navController = nav, startDestination = Routes.START) {
        composable(Routes.START) {
            val vm: AppViewModel = viewModel(factory = factory)
            // Auf dem Startbildschirm ist kein Modus aktiv: Kamera-Service sicher beenden.
            LaunchedEffect(Unit) { app.container.stopCameraService() }
            StartScreen(
                vm = vm,
                onCamera = { vm.setMode(AppMode.CAMERA); nav.navigate(Routes.CAMERA) },
                onControl = { vm.setMode(AppMode.CONTROL); nav.navigate(Routes.CONTROL) },
                onSettings = { nav.navigate(Routes.SETTINGS) },
            )
        }
        composable(Routes.CAMERA) {
            val vm: CameraViewModel = viewModel(factory = factory)
            CameraScreen(vm, onBack = { nav.popBackStack() }, onSettings = { nav.navigate(Routes.SETTINGS) })
        }
        composable(Routes.CONTROL) {
            val vm: ControlViewModel = viewModel(factory = factory)
            ControlScreen(vm, onBack = { nav.popBackStack() }, onSettings = { nav.navigate(Routes.SETTINGS) })
        }
        composable(Routes.SETTINGS) {
            val vm: AppViewModel = viewModel(factory = factory)
            SettingsScreen(
                vm = vm,
                onBack = { nav.popBackStack() },
                onChangeMode = {
                    vm.setMode(null)
                    nav.popBackStack(Routes.START, inclusive = false)
                },
            )
        }
    }
}
