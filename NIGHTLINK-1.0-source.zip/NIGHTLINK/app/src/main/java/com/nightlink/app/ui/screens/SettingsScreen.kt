package com.nightlink.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nightlink.app.BuildConfig
import com.nightlink.app.R
import com.nightlink.app.core.AppMode
import com.nightlink.app.core.WifiStatus
import com.nightlink.app.ui.components.ButtonKind
import com.nightlink.app.ui.components.CameraSettingsFields
import com.nightlink.app.ui.components.NightButton
import com.nightlink.app.ui.components.NightTopBar
import com.nightlink.app.ui.components.PanelCard
import com.nightlink.app.ui.components.ScreenContainer
import com.nightlink.app.ui.components.SectionLabel
import com.nightlink.app.ui.components.StatusRow
import com.nightlink.app.ui.theme.NL
import com.nightlink.app.update.UpdateState
import com.nightlink.app.util.hasCameraPermission
import com.nightlink.app.util.openAppSettings
import com.nightlink.app.viewmodel.AppViewModel

@Composable
fun SettingsScreen(vm: AppViewModel, onBack: () -> Unit, onChangeMode: () -> Unit) {
    val context = LocalContext.current
    val settings by vm.settings.collectAsStateWithLifecycle()
    val wifi by vm.wifi.collectAsStateWithLifecycle()
    val updateState by vm.updateState.collectAsStateWithLifecycle()
    var cameraGranted by remember { mutableStateOf(context.hasCameraPermission()) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { cameraGranted = context.hasCameraPermission() }

    UpdateDialog(updateState, vm)

    ScreenContainer {
        NightTopBar(stringResource(R.string.settings), onBack = onBack)

        SectionLabel(stringResource(R.string.settings_app))
        PanelCard {
            InfoRow(stringResource(R.string.settings_version), BuildConfig.VERSION_NAME)
            Spacer(Modifier.height(10.dp))
            InfoRow(
                stringResource(R.string.settings_mode),
                when (settings.mode) {
                    AppMode.CAMERA -> stringResource(R.string.camera_mode)
                    AppMode.CONTROL -> stringResource(R.string.control_mode)
                    null -> stringResource(R.string.settings_mode_none)
                },
            )
            Spacer(Modifier.height(14.dp))
            NightButton(stringResource(R.string.settings_change_mode), onChangeMode, kind = ButtonKind.OUTLINE)
        }

        SectionLabel(stringResource(R.string.settings_network))
        PanelCard {
            val connected = wifi == WifiStatus.CONNECTED
            StatusRow(
                color = if (connected) NL.Green else NL.Red,
                text = stringResource(if (connected) R.string.wifi_connected else R.string.wifi_disconnected),
                pulsing = connected,
            )
        }

        SectionLabel(stringResource(R.string.settings_camera))
        PanelCard {
            CameraSettingsFields(
                savedName = settings.cameraName,
                lens = settings.lens,
                onNameChange = vm::setCameraName,
                onLensChange = vm::setLens,
            )
            Spacer(Modifier.height(16.dp))
            InfoRow(stringResource(R.string.access_code), settings.accessCode.chunked(3).joinToString(" "))
            Spacer(Modifier.height(10.dp))
            NightButton(stringResource(R.string.regen_code), vm::regenerateAccessCode, kind = ButtonKind.OUTLINE)
        }

        SectionLabel(stringResource(R.string.settings_permissions))
        PanelCard {
            InfoRow(
                stringResource(R.string.perm_camera),
                stringResource(if (cameraGranted) R.string.perm_granted else R.string.perm_denied),
                valueColor = if (cameraGranted) NL.Green else NL.Amber,
            )
            Spacer(Modifier.height(10.dp))
            InfoRow(stringResource(R.string.perm_mic), stringResource(R.string.perm_mic_unused))
            Spacer(Modifier.height(14.dp))
            NightButton(stringResource(R.string.permission_system_settings), { context.openAppSettings() }, kind = ButtonKind.OUTLINE)
        }

        SectionLabel(stringResource(R.string.settings_privacy))
        PanelCard {
            Text(stringResource(R.string.privacy_text), style = MaterialTheme.typography.bodyMedium, color = NL.TextDim)
        }

        // Ganz am Ende der Hauptseite, direkt unterhalb des Datenschutz-Bereichs (nicht darin).
        Spacer(Modifier.height(20.dp))
        NightButton(
            stringResource(R.string.check_updates),
            vm::checkForUpdates,
            kind = ButtonKind.OUTLINE,
            enabled = updateState !is UpdateState.Checking,
        )
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun InfoRow(label: String, value: String, valueColor: Color = NL.Text) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = NL.TextDim)
        Text(value, style = MaterialTheme.typography.labelLarge, color = valueColor)
    }
}
