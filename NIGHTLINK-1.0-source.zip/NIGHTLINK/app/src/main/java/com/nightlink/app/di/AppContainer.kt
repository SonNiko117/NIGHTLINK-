package com.nightlink.app.di

import android.content.Context
import com.nightlink.app.data.SettingsRepository
import com.nightlink.app.discovery.CameraAdvertiser
import com.nightlink.app.discovery.CameraBrowser
import com.nightlink.app.discovery.NsdCameraAdvertiser
import com.nightlink.app.discovery.NsdCameraBrowser
import com.nightlink.app.network.NetworkMonitor
import com.nightlink.app.service.CameraRuntime
import com.nightlink.app.service.CameraService
import com.nightlink.app.transport.VideoTransportFactory
import com.nightlink.app.update.UpdateManager
import com.nightlink.app.transport.WebRtcEnv
import com.nightlink.app.transport.WebRtcTransportFactory
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/** Einfacher manueller Dependency-Container (ersetzt bei Bedarf später Hilt). */
class AppContainer(context: Context) {
    val appContext: Context = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val settings = SettingsRepository(appContext)
    val networkMonitor = NetworkMonitor(appContext)
    val advertiser: CameraAdvertiser = NsdCameraAdvertiser(appContext)
    val browser: CameraBrowser = NsdCameraBrowser(appContext)
    val cameraRuntime = CameraRuntime()
    val updateManager = UpdateManager(appContext)
    val videoTransport: VideoTransportFactory = WebRtcTransportFactory(WebRtcEnv(appContext), networkMonitor.wifiStatus)

    init {
        scope.launch { settings.ensureIdentity() }
        scope.launch { settings.settings.collect { browser.ownDeviceId = it.deviceId } }
    }

    fun startCameraService() = CameraService.start(appContext)
    fun stopCameraService() = CameraService.stop(appContext)
}
