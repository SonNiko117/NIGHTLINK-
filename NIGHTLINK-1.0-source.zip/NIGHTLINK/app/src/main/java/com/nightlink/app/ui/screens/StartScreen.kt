package com.nightlink.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nightlink.app.BuildConfig
import com.nightlink.app.R
import com.nightlink.app.core.WifiStatus
import com.nightlink.app.ui.components.ModeCard
import com.nightlink.app.ui.components.ModeIcon
import com.nightlink.app.ui.components.NightTopBar
import com.nightlink.app.ui.components.NightlinkLogo
import com.nightlink.app.ui.components.ScreenContainer
import com.nightlink.app.ui.components.StatusRow
import com.nightlink.app.ui.theme.NL
import com.nightlink.app.viewmodel.AppViewModel

@Composable
fun StartScreen(vm: AppViewModel, onCamera: () -> Unit, onControl: () -> Unit, onSettings: () -> Unit) {
    val wifi by vm.wifi.collectAsStateWithLifecycle()
    ScreenContainer {
        NightTopBar(title = "", onSettings = onSettings)
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            NightlinkLogo(Modifier.size(120.dp))
            Spacer(Modifier.height(16.dp))
            Text(stringResource(R.string.app_name), style = MaterialTheme.typography.headlineLarge, color = NL.Green)
            Text(stringResource(R.string.start_tagline), style = MaterialTheme.typography.labelMedium, color = NL.TextDim)
            Spacer(Modifier.height(6.dp))
            Text(
                stringResource(R.string.version_format, BuildConfig.VERSION_NAME),
                style = MaterialTheme.typography.labelMedium, color = NL.GreenDim,
            )
            Spacer(Modifier.height(16.dp))
            val connected = wifi == WifiStatus.CONNECTED
            StatusRow(
                color = if (connected) NL.Green else NL.Red,
                text = stringResource(if (connected) R.string.wifi_connected else R.string.wifi_disconnected),
                pulsing = connected,
            )
        }
        Spacer(Modifier.height(28.dp))
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            ModeCard(stringResource(R.string.camera_mode), stringResource(R.string.camera_mode_desc), ModeIcon.CAMERA, onCamera)
            ModeCard(stringResource(R.string.control_mode), stringResource(R.string.control_mode_desc), ModeIcon.CONTROL, onControl)
        }
        Spacer(Modifier.height(20.dp))
        Text(
            stringResource(R.string.start_hint),
            style = MaterialTheme.typography.bodySmall, color = NL.TextDim,
            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(),
        )
    }
}
