package com.nightlink.app.update

/**
 * Semantische Version (major.minor.patch[-prerelease]). Ein führendes "v" und Build-Metadaten (+...) werden ignoriert.
 * Regeln nach SemVer: 1.0.0-rc1 < 1.0.0; Pre-Release-Bezeichner werden numerisch bzw. lexikalisch verglichen.
 */
data class AppVersion(
    val numbers: List<Int>,
    val preRelease: List<String>,
) : Comparable<AppVersion> {

    override fun compareTo(other: AppVersion): Int {
        val n = maxOf(numbers.size, other.numbers.size)
        for (i in 0 until n) {
            val a = numbers.getOrElse(i) { 0 }
            val b = other.numbers.getOrElse(i) { 0 }
            if (a != b) return a.compareTo(b)
        }
        // Eine Version ohne Pre-Release ist größer als dieselbe mit Pre-Release.
        if (preRelease.isEmpty() && other.preRelease.isEmpty()) return 0
        if (preRelease.isEmpty()) return 1
        if (other.preRelease.isEmpty()) return -1
        val m = maxOf(preRelease.size, other.preRelease.size)
        for (i in 0 until m) {
            if (i >= preRelease.size) return -1
            if (i >= other.preRelease.size) return 1
            val a = preRelease[i]
            val b = other.preRelease[i]
            val an = a.toIntOrNull()
            val bn = b.toIntOrNull()
            val c = when {
                an != null && bn != null -> an.compareTo(bn)
                an != null -> -1          // numerische Bezeichner sind kleiner als alphanumerische
                bn != null -> 1
                else -> a.compareTo(b)
            }
            if (c != 0) return c
        }
        return 0
    }

    override fun toString(): String =
        numbers.joinToString(".") + if (preRelease.isEmpty()) "" else "-" + preRelease.joinToString(".")

    companion object {
        private val PATTERN = Regex("""^[vV]?(\d{1,6}(?:\.\d{1,6}){0,3})(?:-([0-9A-Za-z.-]+))?(?:\+[0-9A-Za-z.-]+)?$""")

        /** Liefert null, wenn der Text keine gültige Version ist (dann wird nie ein Update angeboten). */
        fun parse(text: String?): AppVersion? {
            val m = PATTERN.matchEntire(text?.trim().orEmpty()) ?: return null
            val nums = m.groupValues[1].split('.').map { it.toIntOrNull() ?: return null }
            val pre = m.groupValues[2].takeIf { it.isNotEmpty() }?.split('.')?.filter { it.isNotEmpty() }.orEmpty()
            return AppVersion(nums, pre)
        }
    }
}
