package com.nightlink.app.update

import java.io.File
import java.net.URI
import java.security.MessageDigest

/** Reine Sicherheitslogik (ohne Android-Klassen, damit unit-testbar). */
object UpdateSecurity {
    /** Nur diese Hosts dürfen kontaktiert werden – auch nach Weiterleitungen. */
    fun isAllowedHost(host: String?): Boolean {
        val h = host?.lowercase() ?: return false
        return h == "api.github.com" || h == "github.com" ||
            h.endsWith(".githubusercontent.com") && h.length > ".githubusercontent.com".length
    }

    /** Nur HTTPS, nur erlaubte Hosts, keine Zugangsdaten in der URL, nur Standard-Port. */
    fun isAllowedUrl(url: String): Boolean = try {
        val u = URI(url)
        u.scheme.equals("https", ignoreCase = true) && u.userInfo == null &&
            (u.port == -1 || u.port == 443) && isAllowedHost(u.host)
    } catch (ignored: Exception) { false }

    /** Der Download-Link der APK muss zum konfigurierten Repository gehören. */
    fun isRepoDownloadUrl(url: String, repo: String): Boolean =
        isAllowedUrl(url) && url.startsWith("https://github.com/$repo/releases/download/", ignoreCase = true)

    fun isValidRepo(repo: String): Boolean = Regex("^[A-Za-z0-9._-]{1,100}/[A-Za-z0-9._-]{1,100}$").matches(repo)

    fun sha256Hex(file: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    /** Erstes 64-stelliges Hex-Token einer .sha256-Datei ("<hash>  <name>" oder nur "<hash>"). */
    fun parseChecksumFile(text: String): String? =
        text.trim().split(Regex("\\s+")).firstOrNull()?.takeIf { Regex("^[0-9a-fA-F]{64}$").matches(it) }?.lowercase()
}
