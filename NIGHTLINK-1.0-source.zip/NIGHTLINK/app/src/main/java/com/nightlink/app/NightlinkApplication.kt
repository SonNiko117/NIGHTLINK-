package com.nightlink.app

import android.app.Application
import com.nightlink.app.di.AppContainer

class NightlinkApplication : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
