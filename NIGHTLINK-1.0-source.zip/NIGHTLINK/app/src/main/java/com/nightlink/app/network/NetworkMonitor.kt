package com.nightlink.app.network

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import com.nightlink.app.core.WifiStatus
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.distinctUntilChanged

/**
 * Beobachtet nur, OB ein WLAN verbunden ist. Der Netzwerkname (SSID) wird bewusst
 * nicht gelesen – dafür wäre eine Standort-Berechtigung nötig.
 */
class NetworkMonitor(context: Context) {
    private val cm = context.getSystemService(ConnectivityManager::class.java)

    fun currentStatus(): WifiStatus {
        val caps = cm?.getNetworkCapabilities(cm.activeNetwork)
        return if (caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true) {
            WifiStatus.CONNECTED
        } else {
            WifiStatus.DISCONNECTED
        }
    }

    val wifiStatus: Flow<WifiStatus> = callbackFlow {
        val manager = cm
        if (manager == null) {
            trySend(WifiStatus.DISCONNECTED)
            awaitClose { }
            return@callbackFlow
        }
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { trySend(currentStatus()) }
            override fun onLost(network: Network) { trySend(currentStatus()) }
            override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
                trySend(currentStatus())
            }
        }
        val request = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .build()
        trySend(currentStatus())
        try {
            manager.registerNetworkCallback(request, callback)
        } catch (e: SecurityException) {
            trySend(WifiStatus.DISCONNECTED)
        }
        awaitClose { runCatching { manager.unregisterNetworkCallback(callback) } }
    }.distinctUntilChanged()
}
