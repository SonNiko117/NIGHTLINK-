package com.nightlink.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.PowerManager
import android.util.Log
import android.util.Size
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import com.nightlink.app.MainActivity
import com.nightlink.app.NightlinkApplication
import com.nightlink.app.R
import com.nightlink.app.core.CameraLens
import com.nightlink.app.core.NightlinkProtocol
import com.nightlink.app.core.WifiStatus
import com.nightlink.app.di.AppContainer
import com.nightlink.app.transport.CameraPublisher
import com.nightlink.app.transport.I420FrameConverter
import com.nightlink.app.transport.SignalingServer
import com.nightlink.app.util.hasCameraPermission
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.io.IOException
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Foreground Service (Typ camera): hält Kamera, Signaling-Server, mDNS-Ankündigung und WebRTC am Laufen,
 * auch wenn das Display aus ist oder die App im Hintergrund liegt.
 */
class CameraService : LifecycleService() {
    private lateinit var container: AppContainer
    private var publisher: CameraPublisher? = null
    private var server: SignalingServer? = null
    private var provider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var preview: Preview? = null
    private var analysis: ImageAnalysis? = null
    private var analysisExecutor: ExecutorService? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null
    @Volatile private var accessCode: String = ""
    private var started = false

    override fun onCreate() {
        super.onCreate()
        container = (application as NightlinkApplication).container
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (started) return START_NOT_STICKY
        started = true
        if (!hasCameraPermission()) {
            container.cameraRuntime.setError(getString(R.string.error_no_camera_permission))
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            ServiceCompat.startForeground(this, NOTIFICATION_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA)
        } catch (e: Exception) {
            Log.w(TAG, "startForeground failed: ${e.javaClass.simpleName}")
            container.cameraRuntime.setError(getString(R.string.error_service_start))
            stopSelf()
            return START_NOT_STICKY
        }
        startPipeline()
        return START_NOT_STICKY   // Kamera darf nie ohne ausdrückliche Aktivierung neu starten
    }

    private fun startPipeline() {
        val runtime = container.cameraRuntime
        runtime.setError(null)
        runtime.setRunning(true)
        acquireLocks()

        val pub = container.videoTransport.createPublisher { runtime.setClients(it) }
        publisher = pub
        val srv = SignalingServer(NightlinkProtocol.SIGNALING_PORT, { accessCode }, pub)
        try {
            srv.start()
            server = srv
        } catch (e: IOException) {
            runtime.setError(getString(R.string.error_port_in_use, NightlinkProtocol.SIGNALING_PORT))
            stopSelf()
            return
        }

        // Einstellungen (Code, Name, Linse) und WLAN beobachten.
        lifecycleScope.launch {
            container.settings.settings.collect { accessCode = it.accessCode }
        }
        lifecycleScope.launch {
            combine(container.settings.settings, container.networkMonitor.wifiStatus) { s, wifi ->
                Triple(wifi == WifiStatus.CONNECTED && s.deviceId.isNotEmpty(), s.deviceId, s.advertisedName)
            }.distinctUntilChanged().collect { (on, id, name) ->
                if (on) container.advertiser.start(id, name) else container.advertiser.stop()
            }
        }
        lifecycleScope.launch {
            container.settings.settings.map { it.lens }.distinctUntilChanged().collect { bindCamera(it) }
        }
        lifecycleScope.launch {
            combine(runtime.torchWanted, runtime.torchAvailable) { want, avail -> want && avail }
                .distinctUntilChanged().collect { camera?.cameraControl?.enableTorch(it) }
        }
        lifecycleScope.launch {
            runtime.previewProvider.collect { preview?.setSurfaceProvider(it) }
        }
    }

    private fun bindCamera(lens: CameraLens) {
        val runtime = container.cameraRuntime
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                if (!started) return@addListener
                val p = future.get()
                provider = p
                val selector = if (lens == CameraLens.FRONT) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
                val selection = ResolutionSelector.Builder()
                    .setResolutionStrategy(ResolutionStrategy(Size(1280, 720), ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER))
                    .build()
                val pv = Preview.Builder().setResolutionSelector(selection).build()
                    .also { it.setSurfaceProvider(runtime.previewProvider.value) }
                val executor = analysisExecutor ?: Executors.newSingleThreadExecutor().also { analysisExecutor = it }
                val an = ImageAnalysis.Builder()
                    .setResolutionSelector(selection)
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                an.setAnalyzer(executor) { image ->
                    try {
                        val frame = I420FrameConverter.convert(image)
                        publisher?.pushFrame(frame)
                        frame.release()
                    } finally {
                        image.close()
                    }
                }
                p.unbindAll()
                val cam = p.bindToLifecycle(this, selector, pv, an)
                camera = cam
                preview = pv
                analysis = an
                runtime.setTorchAvailable(cam.cameraInfo.hasFlashUnit())
                runtime.setError(null)
                if (runtime.torchWanted.value && cam.cameraInfo.hasFlashUnit()) cam.cameraControl.enableTorch(true)
            } catch (e: Exception) {
                Log.w(TAG, "bindCamera failed: ${e.javaClass.simpleName}")
                runtime.setError(getString(R.string.error_camera_start, e.message ?: e.javaClass.simpleName))
                stopSelf()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun acquireLocks() {
        val pm = getSystemService(PowerManager::class.java)
        wakeLock = pm?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "nightlink:camera")?.apply { setReferenceCounted(false); acquire() }
        val wm = applicationContext.getSystemService(WifiManager::class.java)
        wifiLock = wm?.createWifiLock(WifiManager.WIFI_MODE_FULL_LOW_LATENCY, "nightlink:stream")?.apply { setReferenceCounted(false); acquire() }
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, CameraService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_text))
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(0, getString(R.string.notif_stop), stop)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
    }

    override fun onDestroy() {
        started = false
        container.advertiser.stop()
        runCatching { analysis?.clearAnalyzer() }
        runCatching { provider?.unbindAll() }
        camera = null; preview = null; analysis = null
        analysisExecutor?.shutdownNow(); analysisExecutor = null
        server?.stop(); server = null
        publisher?.release(); publisher = null
        runCatching { wakeLock?.takeIf { it.isHeld }?.release() }
        runCatching { wifiLock?.takeIf { it.isHeld }?.release() }
        container.cameraRuntime.reset()
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.nightlink.app.action.STOP_CAMERA"
        private const val CHANNEL_ID = "nightlink_camera"
        private const val NOTIFICATION_ID = 4820
        private const val TAG = "NightlinkService"

        fun start(context: Context) =
            ContextCompat.startForegroundService(context, Intent(context, CameraService::class.java))

        fun stop(context: Context) {
            context.stopService(Intent(context, CameraService::class.java))
        }
    }
}
