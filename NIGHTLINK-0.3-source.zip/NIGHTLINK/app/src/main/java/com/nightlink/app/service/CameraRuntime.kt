package com.nightlink.app.service

import androidx.camera.core.Preview
import com.nightlink.app.transport.ConnectedClient
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Gemeinsamer Zustand zwischen UI und [CameraService] (UI ↔ Service ohne Binder). */
class CameraRuntime {
    private val _running = MutableStateFlow(false)
    val running: StateFlow<Boolean> = _running.asStateFlow()
    private val _clients = MutableStateFlow<List<ConnectedClient>>(emptyList())
    val clients: StateFlow<List<ConnectedClient>> = _clients.asStateFlow()
    private val _torchAvailable = MutableStateFlow(false)
    val torchAvailable: StateFlow<Boolean> = _torchAvailable.asStateFlow()
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    /** Wunsch der UI; der Service setzt ihn um. */
    private val _torchWanted = MutableStateFlow(false)
    val torchWanted: StateFlow<Boolean> = _torchWanted.asStateFlow()

    /** Von der UI bereitgestellte Vorschau-Fläche (null, wenn kein Screen sichtbar ist). */
    val previewProvider = MutableStateFlow<Preview.SurfaceProvider?>(null)

    fun setTorchWanted(on: Boolean) { _torchWanted.value = on }
    internal fun setRunning(v: Boolean) { _running.value = v }
    internal fun setClients(v: List<ConnectedClient>) { _clients.value = v }
    internal fun setTorchAvailable(v: Boolean) { _torchAvailable.value = v }
    internal fun setError(v: String?) { _error.value = v }
    internal fun reset() {
        _running.value = false; _clients.value = emptyList(); _torchAvailable.value = false; _torchWanted.value = false
    }
}
