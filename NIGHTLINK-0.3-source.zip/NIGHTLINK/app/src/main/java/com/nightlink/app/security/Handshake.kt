package com.nightlink.app.security

import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64
import javax.crypto.Cipher
import javax.crypto.Mac
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Gegenseitige Authentifizierung per Challenge-Response. Der Zugangscode selbst wird nie übertragen.
 *
 *   Client → Server: cn (Client-Nonce)
 *   Server → Client: sn (Server-Nonce), HMAC(key, "S"|cn|sn)   ← Server beweist Code-Kenntnis
 *   Client → Server: HMAC(key, "C"|cn|sn)                      ← Client beweist Code-Kenntnis
 *
 * key = PBKDF2-HMAC-SHA256(Zugangscode). Aus key + Nonces folgt ein Sitzungsschlüssel für AES-256-GCM.
 *
 * Grenzen (siehe README): Ein passiver Mithörer im WLAN kann den 6-stelligen Code per Offline-Raten
 * aus einem aufgezeichneten Handshake prüfen. Online-Raten wird durch [AuthGuard] gebremst.
 */
object Handshake {
    const val NONCE_BYTES = 16
    private const val PBKDF2_ITERATIONS = 20_000
    private val SALT = "nightlink-v1-auth".toByteArray(Charsets.UTF_8)
    private val random = SecureRandom()

    fun newNonce(): ByteArray = ByteArray(NONCE_BYTES).also { random.nextBytes(it) }

    fun deriveKey(accessCode: String): ByteArray {
        val spec = PBEKeySpec(accessCode.toCharArray(), SALT, PBKDF2_ITERATIONS, 256)
        try {
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        } finally {
            spec.clearPassword()
        }
    }

    fun serverProof(key: ByteArray, cn: ByteArray, sn: ByteArray) = hmac(key, "S", cn, sn)
    fun clientProof(key: ByteArray, cn: ByteArray, sn: ByteArray) = hmac(key, "C", cn, sn)
    fun sessionKey(key: ByteArray, cn: ByteArray, sn: ByteArray) = hmac(key, "K", cn, sn)

    /** Zeitkonstanter Vergleich. */
    fun verify(expected: ByteArray, actual: ByteArray?): Boolean =
        actual != null && MessageDigest.isEqual(expected, actual)

    private fun hmac(key: ByteArray, label: String, cn: ByteArray, sn: ByteArray): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(key, "HmacSHA256"))
        mac.update(label.toByteArray(Charsets.UTF_8))
        mac.update(cn)
        mac.update(sn)
        return mac.doFinal()
    }

    fun b64(bytes: ByteArray): String = Base64.getEncoder().encodeToString(bytes)
    fun unb64(text: String?): ByteArray? = try {
        if (text == null) null else Base64.getDecoder().decode(text)
    } catch (_: IllegalArgumentException) {
        null
    }
}

class SecureChannelException(message: String) : Exception(message)

/**
 * Verschlüsselt/entschlüsselt Signaling-Nachrichten (AES-256-GCM) mit dem Sitzungsschlüssel.
 * Die Nonce besteht aus Richtungsbyte + Zähler und wird nicht übertragen; Wiedereinspielen,
 * Auslassen oder Umsortieren führt daher zu einem Entschlüsselungsfehler.
 */
class SecureChannel(sessionKey: ByteArray, private val isServer: Boolean) {
    private val key = SecretKeySpec(sessionKey, "AES")
    private var sendCounter = 0L
    private var recvCounter = 0L

    @Synchronized
    fun encrypt(plain: ByteArray): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, nonce(if (isServer) 1 else 2, sendCounter)))
        sendCounter++
        return Handshake.b64(cipher.doFinal(plain))
    }

    @Synchronized
    fun decrypt(text: String): ByteArray {
        val data = Handshake.unb64(text) ?: throw SecureChannelException("encoding")
        try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, nonce(if (isServer) 2 else 1, recvCounter)))
            val out = cipher.doFinal(data)
            recvCounter++
            return out
        } catch (e: java.security.GeneralSecurityException) {
            throw SecureChannelException("authentication failed")
        }
    }

    private fun nonce(direction: Int, counter: Long): ByteArray {
        val n = ByteArray(12)
        n[0] = direction.toByte()
        for (i in 0 until 8) n[11 - i] = (counter ushr (8 * i)).toByte()
        return n
    }
}
