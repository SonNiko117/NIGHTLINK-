package com.nightlink.app.transport

import com.nightlink.app.core.NightlinkProtocol
import com.nightlink.app.security.AuthGuard
import com.nightlink.app.security.Handshake
import com.nightlink.app.security.LocalNetworkGuard
import com.nightlink.app.security.SecureChannel
import com.nightlink.app.security.SecureChannelException
import org.json.JSONObject
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.io.Writer
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketTimeoutException
import java.util.concurrent.Executors
import java.util.concurrent.ThreadFactory
import java.util.concurrent.atomic.AtomicInteger

/** Authentifizierte Verbindung zu einem Kontrollgerät (Sicht der Kamera). */
interface PeerLink {
    val id: String
    val remoteAddress: String
    fun send(message: SignalingMessage)
    fun close()
}

interface SignalingServerListener {
    fun onPeerConnected(link: PeerLink)
    fun onPeerMessage(link: PeerLink, message: SignalingMessage)
    fun onPeerDisconnected(link: PeerLink)
}

/**
 * TCP-Signaling-Server der Kamera (Port 48200). Akzeptiert nur lokale Adressen, verlangt eine
 * erfolgreiche Code-Authentifizierung ([Handshake]) und verschlüsselt danach alle Nachrichten.
 */
class SignalingServer(
    private val port: Int,
    private val accessCode: () -> String,
    private val listener: SignalingServerListener,
    private val authGuard: AuthGuard = AuthGuard(),
    private val allowLoopback: Boolean = false,
    private val maxClients: Int = 4,
) {
    private val pool = Executors.newCachedThreadPool(object : ThreadFactory {
        private val n = AtomicInteger()
        override fun newThread(r: Runnable) = Thread(r, "nl-signaling-${n.incrementAndGet()}").apply { isDaemon = true }
    })
    private val clients = java.util.Collections.synchronizedSet(HashSet<ServerLink>())
    @Volatile private var serverSocket: ServerSocket? = null
    @Volatile private var running = false

    /** Tatsächlich gebundener Port (bei port = 0 nützlich für Tests). */
    val boundPort: Int get() = serverSocket?.localPort ?: -1

    @Throws(IOException::class)
    fun start() {
        if (running) return
        val s = ServerSocket(port)
        s.reuseAddress = true
        serverSocket = s
        running = true
        pool.execute { acceptLoop(s) }
    }

    fun stop() {
        running = false
        runCatching { serverSocket?.close() }
        serverSocket = null
        synchronized(clients) { clients.toList() }.forEach { it.close() }
        pool.shutdownNow()
    }

    private fun acceptLoop(s: ServerSocket) {
        while (running) {
            val socket = try { s.accept() } catch (_: IOException) { break }
            try {
                pool.execute { handle(socket) }
            } catch (_: Exception) {
                runCatching { socket.close() }
            }
        }
    }

    private fun handle(socket: Socket) {
        var link: ServerLink? = null
        try {
            socket.tcpNoDelay = true
            socket.keepAlive = true
            val remote = socket.inetAddress
            if (!LocalNetworkGuard.isLocal(remote, allowLoopback)) return
            val ip = remote.hostAddress.orEmpty()
            val reader = BufferedReader(InputStreamReader(socket.getInputStream(), Charsets.UTF_8))
            val writer = OutputStreamWriter(socket.getOutputStream(), Charsets.UTF_8)

            if (authGuard.isBlocked(ip)) { sendPlain(writer, "deny", "locked"); return }
            if (clients.size >= maxClients) { sendPlain(writer, "deny", "busy"); return }

            socket.soTimeout = HANDSHAKE_TIMEOUT_MS
            val session = authenticate(reader, writer, ip) ?: return

            socket.soTimeout = IDLE_TIMEOUT_MS
            link = ServerLink(socket, writer, session.channel, session.clientId, ip)
            clients.add(link)
            listener.onPeerConnected(link)
            link.runReadLoop(reader)
        } catch (_: IOException) {
            // Verbindungsabbruch: wird unten sauber aufgeräumt.
        } catch (_: SecureChannelException) {
            // Manipulierte/ungültige Nachricht → Verbindung beenden.
        } finally {
            link?.let {
                clients.remove(it)
                it.close()
                listener.onPeerDisconnected(it)
            }
            runCatching { socket.close() }
        }
    }

    private class Session(val channel: SecureChannel, val clientId: String)

    private fun authenticate(reader: BufferedReader, writer: Writer, ip: String): Session? {
        val hello = try {
            reader.readBoundedLine(1024)?.let { JSONObject(it) }
        } catch (_: Exception) { null }
        val cn = Handshake.unb64(hello?.optString("cn"))
        if (hello == null || hello.optString("t") != "hello" || hello.optInt("v") != NightlinkProtocol.PROTOCOL_VERSION ||
            cn == null || cn.size != Handshake.NONCE_BYTES
        ) {
            authGuard.recordFailure(ip)
            sendPlain(writer, "deny", "protocol")
            return null
        }
        val key = Handshake.deriveKey(accessCode())
        val sn = Handshake.newNonce()
        sendPlain(writer, "challenge", null) { put("sn", Handshake.b64(sn)); put("sp", Handshake.b64(Handshake.serverProof(key, cn, sn))) }

        val auth = try {
            reader.readBoundedLine(1024)?.let { JSONObject(it) }
        } catch (_: SocketTimeoutException) { null } catch (_: Exception) { null }
        val proof = Handshake.unb64(auth?.optString("cp"))
        if (auth == null || auth.optString("t") != "auth" || !Handshake.verify(Handshake.clientProof(key, cn, sn), proof)) {
            // Auch ein Abbruch des Clients (z. B. weil er den Server-Beweis ablehnt) zählt als Fehlversuch.
            authGuard.recordFailure(ip)
            sendPlain(writer, "deny", "auth")
            return null
        }
        authGuard.recordSuccess(ip)
        sendPlain(writer, "ok", null)
        val clientId = hello.optString("id").filter { it.isLetterOrDigit() || it == '-' }.take(40).ifEmpty { "client" }
        return Session(SecureChannel(Handshake.sessionKey(key, cn, sn), isServer = true), clientId + "@" + ip)
    }

    private fun sendPlain(w: Writer, type: String, reason: String?, extra: (JSONObject.() -> Unit)? = null) {
        try {
            val o = JSONObject().put("t", type)
            if (reason != null) o.put("r", reason)
            extra?.invoke(o)
            synchronized(w) { w.write(o.toString() + "\n"); w.flush() }
        } catch (_: IOException) { }
    }

    private inner class ServerLink(
        private val socket: Socket,
        private val writer: Writer,
        private val channel: SecureChannel,
        override val id: String,
        override val remoteAddress: String,
    ) : PeerLink {
        @Volatile private var closed = false

        override fun send(message: SignalingMessage) {
            if (closed) return
            try {
                val line = channel.encrypt(SignalingCodec.encode(message).toByteArray(Charsets.UTF_8))
                synchronized(writer) { writer.write(line + "\n"); writer.flush() }
            } catch (_: IOException) {
                close()
            }
        }

        fun runReadLoop(reader: BufferedReader) {
            val pinger = pool.submit {
                while (!closed) {
                    try { Thread.sleep(PING_INTERVAL_MS) } catch (_: InterruptedException) { break }
                    send(SignalingMessage.Ping)
                }
            }
            try {
                while (!closed) {
                    val line = try { reader.readBoundedLine(NightlinkProtocol.MAX_LINE_CHARS) } catch (_: SocketTimeoutException) { null } ?: break
                    val msg = SignalingCodec.decode(String(channel.decrypt(line), Charsets.UTF_8)) ?: continue
                    if (msg is SignalingMessage.Bye) break
                    if (msg !is SignalingMessage.Ping) listener.onPeerMessage(this, msg)
                }
            } finally {
                pinger.cancel(true)
            }
        }

        override fun close() {
            if (closed) return
            closed = true
            runCatching { socket.close() }
        }
    }

    companion object {
        const val HANDSHAKE_TIMEOUT_MS = 5_000
        const val IDLE_TIMEOUT_MS = 20_000
        const val PING_INTERVAL_MS = 5_000L
    }
}
