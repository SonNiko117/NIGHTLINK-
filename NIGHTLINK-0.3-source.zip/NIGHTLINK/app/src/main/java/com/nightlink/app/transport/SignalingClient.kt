package com.nightlink.app.transport

import com.nightlink.app.core.NightlinkProtocol
import com.nightlink.app.security.Handshake
import com.nightlink.app.security.LocalNetworkGuard
import com.nightlink.app.security.SecureChannel
import com.nightlink.app.security.SecureChannelException
import org.json.JSONObject
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException

enum class ConnectError { WRONG_CODE, LOCKED, BUSY, UNREACHABLE, NOT_LOCAL, PROTOCOL }

class SignalingException(val error: ConnectError) : Exception(error.name)

interface SignalingClientListener {
    fun onMessage(message: SignalingMessage)
    fun onClosed()
}

/** Signaling-Client des Kontrollgeräts. [connect] blockiert und gehört auf einen Hintergrund-Thread. */
class SignalingClient(
    private val host: String,
    private val port: Int,
    private val accessCode: String,
    private val deviceId: String,
    private val allowLoopback: Boolean = false,
) {
    private var socket: Socket? = null
    private var writer: OutputStreamWriter? = null
    private var channel: SecureChannel? = null
    @Volatile private var closed = false

    @Throws(SignalingException::class)
    fun connect(listener: SignalingClientListener, timeoutMs: Int = 5_000) {
        val addr = try { InetAddress.getByName(host) } catch (_: Exception) { throw SignalingException(ConnectError.UNREACHABLE) }
        if (!LocalNetworkGuard.isLocal(addr, allowLoopback)) throw SignalingException(ConnectError.NOT_LOCAL)
        val s = Socket()
        try {
            s.tcpNoDelay = true
            s.keepAlive = true
            s.connect(InetSocketAddress(addr, port), timeoutMs)
            s.soTimeout = timeoutMs
            val reader = BufferedReader(InputStreamReader(s.getInputStream(), Charsets.UTF_8))
            val w = OutputStreamWriter(s.getOutputStream(), Charsets.UTF_8)

            val cn = Handshake.newNonce()
            writeLine(w, JSONObject().put("t", "hello").put("v", NightlinkProtocol.PROTOCOL_VERSION)
                .put("id", deviceId).put("cn", Handshake.b64(cn)).toString())

            val ch = reader.readBoundedLine(1024)?.let { JSONObject(it) } ?: throw SignalingException(ConnectError.PROTOCOL)
            when (ch.optString("t")) {
                "deny" -> throw SignalingException(denyReason(ch))
                "challenge" -> Unit
                else -> throw SignalingException(ConnectError.PROTOCOL)
            }
            val sn = Handshake.unb64(ch.optString("sn"))
            val sp = Handshake.unb64(ch.optString("sp"))
            if (sn == null || sn.size != Handshake.NONCE_BYTES) throw SignalingException(ConnectError.PROTOCOL)

            val key = Handshake.deriveKey(accessCode)
            // Erst den Server prüfen: Ein Gerät, das den Code nicht kennt, erhält keinen Client-Beweis.
            if (!Handshake.verify(Handshake.serverProof(key, cn, sn), sp)) throw SignalingException(ConnectError.WRONG_CODE)
            writeLine(w, JSONObject().put("t", "auth").put("cp", Handshake.b64(Handshake.clientProof(key, cn, sn))).toString())

            val ok = reader.readBoundedLine(1024)?.let { JSONObject(it) } ?: throw SignalingException(ConnectError.PROTOCOL)
            when (ok.optString("t")) {
                "ok" -> Unit
                "deny" -> throw SignalingException(denyReason(ok))
                else -> throw SignalingException(ConnectError.PROTOCOL)
            }

            socket = s
            writer = w
            channel = SecureChannel(Handshake.sessionKey(key, cn, sn), isServer = false)
            s.soTimeout = SignalingServer.IDLE_TIMEOUT_MS
            val t = Thread({ readLoop(reader, listener) }, "nl-signaling-client")
            t.isDaemon = true
            t.start()
            val p = Thread({ pingLoop() }, "nl-signaling-ping")
            p.isDaemon = true
            p.start()
        } catch (e: SignalingException) {
            runCatching { s.close() }
            throw e
        } catch (_: SocketTimeoutException) {
            runCatching { s.close() }
            throw SignalingException(ConnectError.UNREACHABLE)
        } catch (_: IOException) {
            runCatching { s.close() }
            throw SignalingException(ConnectError.UNREACHABLE)
        } catch (_: Exception) {
            runCatching { s.close() }
            throw SignalingException(ConnectError.PROTOCOL)
        }
    }

    private fun denyReason(o: JSONObject) = when (o.optString("r")) {
        "locked" -> ConnectError.LOCKED
        "busy" -> ConnectError.BUSY
        "auth" -> ConnectError.WRONG_CODE
        else -> ConnectError.PROTOCOL
    }

    private fun readLoop(reader: BufferedReader, listener: SignalingClientListener) {
        try {
            while (!closed) {
                val line = try { reader.readBoundedLine(NightlinkProtocol.MAX_LINE_CHARS) } catch (_: SocketTimeoutException) { null } ?: break
                val msg = SignalingCodec.decode(String(channel!!.decrypt(line), Charsets.UTF_8)) ?: continue
                if (msg is SignalingMessage.Bye) break
                if (msg !is SignalingMessage.Ping) listener.onMessage(msg)
            }
        } catch (_: IOException) {
        } catch (_: SecureChannelException) {
        } finally {
            val wasOpen = !closed
            close()
            if (wasOpen) listener.onClosed()
        }
    }

    private fun pingLoop() {
        while (!closed) {
            try { Thread.sleep(SignalingServer.PING_INTERVAL_MS) } catch (_: InterruptedException) { return }
            send(SignalingMessage.Ping)
        }
    }

    fun send(message: SignalingMessage) {
        val w = writer ?: return
        val ch = channel ?: return
        if (closed) return
        try {
            val line = ch.encrypt(SignalingCodec.encode(message).toByteArray(Charsets.UTF_8))
            writeLine(w, line)
        } catch (_: IOException) {
            close()
        }
    }

    fun close() {
        if (closed) return
        closed = true
        runCatching { socket?.close() }
    }

    private fun writeLine(w: OutputStreamWriter, line: String) {
        synchronized(w) { w.write(line + "\n"); w.flush() }
    }
}
