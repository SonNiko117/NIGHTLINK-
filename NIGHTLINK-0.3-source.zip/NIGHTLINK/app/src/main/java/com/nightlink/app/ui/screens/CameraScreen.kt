package com.nightlink.app.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.activity.compose.BackHandler
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nightlink.app.R
import com.nightlink.app.core.CameraLens
import com.nightlink.app.core.WifiStatus
import com.nightlink.app.discovery.AdvertiseState
import com.nightlink.app.ui.components.ButtonKind
import com.nightlink.app.ui.components.CameraPreview
import com.nightlink.app.ui.components.CameraSettingsFields
import com.nightlink.app.ui.components.NightButton
import com.nightlink.app.ui.components.NightTopBar
import com.nightlink.app.ui.components.PanelCard
import com.nightlink.app.ui.components.ScreenContainer
import com.nightlink.app.ui.components.SectionLabel
import com.nightlink.app.ui.components.StatusRow
import com.nightlink.app.ui.theme.NL
import com.nightlink.app.util.hasCameraPermission
import com.nightlink.app.util.hasNotificationPermission
import com.nightlink.app.util.openAppSettings
import com.nightlink.app.util.openWifiSettings
import com.nightlink.app.viewmodel.CameraViewModel

@Composable
fun CameraScreen(vm: CameraViewModel, onBack: () -> Unit, onSettings: () -> Unit) {
    val context = LocalContext.current
    val settings by vm.settings.collectAsStateWithLifecycle()
    val wifi by vm.wifi.collectAsStateWithLifecycle()
    val active by vm.active.collectAsStateWithLifecycle()
    val advertise by vm.advertiseState.collectAsStateWithLifecycle()
    val clients by vm.clients.collectAsStateWithLifecycle()
    val torchAvailable by vm.torchAvailable.collectAsStateWithLifecycle()
    val torchOn by vm.torchWanted.collectAsStateWithLifecycle()
    val cameraError by vm.error.collectAsStateWithLifecycle()

    var granted by remember { mutableStateOf(context.hasCameraPermission()) }
    var permissionDenied by remember { mutableStateOf(false) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        granted = result[android.Manifest.permission.CAMERA] == true || context.hasCameraPermission()
        permissionDenied = !granted
        if (granted) { vm.clearError(); vm.start() }
    }
    fun requestAndStart() {
        if (granted) { vm.clearError(); vm.start(); return }
        val perms = buildList {
            add(android.Manifest.permission.CAMERA)
            if (android.os.Build.VERSION.SDK_INT >= 33 && !context.hasNotificationPermission()) {
                add(android.Manifest.permission.POST_NOTIFICATIONS)
            }
        }
        launcher.launch(perms.toTypedArray())
    }

    // Die Kamera läuft im Foreground Service weiter (Display aus / App im Hintergrund).
    // Sie stoppt, wenn der Nutzer sie deaktiviert, den Modus verlässt oder die Benachrichtigung nutzt.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { granted = context.hasCameraPermission() }
    BackHandler { vm.stop(); onBack() }

    val view = LocalView.current
    DisposableEffect(active) {
        view.keepScreenOn = active
        onDispose { view.keepScreenOn = false }
    }

    ScreenContainer {
        NightTopBar(stringResource(R.string.camera_setup), onBack = { vm.stop(); onBack() }, onSettings = onSettings)

        SectionLabel(stringResource(R.string.preview))
        Box(
            Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(RoundedCornerShape(4.dp)).background(NL.SurfaceHigh),
            contentAlignment = Alignment.Center,
        ) {
            if (active && granted) {
                CameraPreview(vm.runtime, Modifier.fillMaxWidth().aspectRatio(16f / 9f))
                Box(Modifier.align(Alignment.TopStart).padding(10.dp)) {
                    StatusRow(NL.Red, stringResource(R.string.live), pulsing = true)
                }
            } else {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(16.dp)) {
                    Text(stringResource(R.string.preview_off), style = MaterialTheme.typography.titleMedium, color = NL.TextDim)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        stringResource(R.string.preview_off_desc), style = MaterialTheme.typography.bodySmall,
                        color = NL.TextDim, textAlign = TextAlign.Center,
                    )
                }
            }
        }
        cameraError?.let {
            Text(it, color = NL.Red, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 8.dp))
        }

        Spacer(Modifier.height(16.dp))
        if (active) {
            NightButton(stringResource(R.string.deactivate), { vm.stop() }, kind = ButtonKind.DANGER)
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                NightButton(
                    stringResource(if (settings.lens == CameraLens.FRONT) R.string.switch_to_back else R.string.switch_to_front),
                    { vm.setLens(if (settings.lens == CameraLens.FRONT) CameraLens.BACK else CameraLens.FRONT) },
                    modifier = Modifier.weight(1f), kind = ButtonKind.OUTLINE,
                )
                NightButton(
                    stringResource(if (torchOn) R.string.torch_off else R.string.torch_on),
                    { vm.setTorch(!torchOn) },
                    modifier = Modifier.weight(1f), kind = ButtonKind.OUTLINE, enabled = torchAvailable,
                )
            }
            if (!torchAvailable) {
                Text(stringResource(R.string.torch_unavailable), color = NL.TextDim, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp))
            }
        } else {
            if (!granted) {
                PanelCard {
                    Text(stringResource(R.string.perm_explain_title), style = MaterialTheme.typography.titleMedium, color = NL.Green)
                    Spacer(Modifier.height(6.dp))
                    Text(stringResource(R.string.perm_explain_text), style = MaterialTheme.typography.bodySmall, color = NL.TextDim)
                }
                Spacer(Modifier.height(12.dp))
            }
            NightButton(stringResource(R.string.activate), onClick = { requestAndStart() })
        }
        if (permissionDenied && !granted) {
            Text(
                stringResource(R.string.permission_denied_hint),
                color = NL.Amber, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 8.dp),
            )
            Spacer(Modifier.height(8.dp))
            NightButton(stringResource(R.string.permission_system_settings), { context.openAppSettings() }, kind = ButtonKind.OUTLINE)
        }

        SectionLabel(stringResource(R.string.connection_status))
        PanelCard {
            val connected = wifi == WifiStatus.CONNECTED
            StatusRow(
                color = if (connected) NL.Green else NL.Red,
                text = stringResource(if (connected) R.string.wifi_connected else R.string.wifi_disconnected),
                pulsing = connected,
            )
            Spacer(Modifier.height(10.dp))
            val (color, text) = when {
                !active -> NL.TextDim to stringResource(R.string.status_idle)
                !connected -> NL.Amber to stringResource(R.string.status_no_wifi)
                advertise is AdvertiseState.Active -> NL.Green to stringResource(R.string.status_live)
                advertise is AdvertiseState.Failed -> NL.Red to stringResource(R.string.status_error, (advertise as AdvertiseState.Failed).code)
                else -> NL.Amber to stringResource(R.string.status_starting)
            }
            StatusRow(color, text, pulsing = active && advertise is AdvertiseState.Active)
            if (!connected) {
                Spacer(Modifier.height(12.dp))
                NightButton(stringResource(R.string.wifi_connect), { context.openWifiSettings() }, kind = ButtonKind.OUTLINE)
            }
        }

        SectionLabel(stringResource(R.string.connected_devices, clients.size))
        PanelCard {
            if (clients.isEmpty()) {
                Text(stringResource(R.string.no_clients), style = MaterialTheme.typography.bodySmall, color = NL.TextDim)
            } else {
                clients.forEachIndexed { i, cl ->
                    if (i > 0) Spacer(Modifier.height(8.dp))
                    StatusRow(
                        if (cl.streaming) NL.Green else NL.Amber,
                        "${cl.address}  ·  " + stringResource(if (cl.streaming) R.string.client_streaming else R.string.client_connecting),
                        pulsing = cl.streaming,
                    )
                }
            }
        }

        CameraSettingsFields(
            savedName = settings.cameraName,
            lens = settings.lens,
            onNameChange = vm::setCameraName,
            onLensChange = vm::setLens,
        )

        SectionLabel(stringResource(R.string.access_code))
        PanelCard {
            Text(
                settings.accessCode.chunked(3).joinToString(" "),
                style = MaterialTheme.typography.headlineLarge, color = NL.Green,
            )
            Spacer(Modifier.height(6.dp))
            Text(stringResource(R.string.access_code_desc), style = MaterialTheme.typography.bodySmall, color = NL.TextDim)
        }
        Spacer(Modifier.height(24.dp))
    }
}
