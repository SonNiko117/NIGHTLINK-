# NIGHTLINK 0.1

Lokales Kamera-/Kontrollsystem im WLAN (Kotlin, Jetpack Compose, Material 3, minSdk 29).

## Öffnen & bauen
1. Ordner in Android Studio (aktuelle Version) öffnen, Gradle-Sync abwarten (Gradle 8.9, JDK 17).
2. Auf **zwei echte Geräte** im selben WLAN installieren: eins CAMERA MODE (Kamera aktivieren), eins CONTROL MODE.
   (Emulatoren hängen meist in getrennten Netzen, mDNS funktioniert dort nicht zuverlässig.)

## Struktur (com.nightlink.app)
- `core/` Modelle + Protokollkonstanten (mDNS-Typ `_nightlink._tcp.`, TXT-Felder)
- `data/` Einstellungen (DataStore): Modus, Kameraname, Linse, Geräte-ID, Zugangscode
- `network/` WLAN-Status · `security/` Local-Network-Guard, Zugangscode
- `discovery/` mDNS-Ankündigung (Kamera) und -Suche (Kontrollgerät) über NsdManager
- `transport/` Interfaces für Signaling + WebRTC (v0.2), aktuell `UnavailableVideoTransportFactory`
- `di/` AppContainer · `viewmodel/` ViewModels · `ui/` Theme, Komponenten, Screens, Navigation

## Nicht in 0.1
WebRTC-Video, Signaling-Server auf Port 48200, Zugangscode-Prüfung beim Verbinden, Foreground-Service für Hintergrundbetrieb.
