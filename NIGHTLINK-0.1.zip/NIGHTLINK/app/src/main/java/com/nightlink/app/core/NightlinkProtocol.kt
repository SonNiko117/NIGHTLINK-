package com.nightlink.app.core

/**
 * Gemeinsame Protokollkonstanten. Eine spätere PC-Version muss dieselben
 * mDNS-Service-Typen und TXT-Felder verwenden.
 */
object NightlinkProtocol {
    /** mDNS/DNS-SD-Dienst (nur lokales Netzwerk). */
    const val SERVICE_TYPE = "_nightlink._tcp."
    const val SERVICE_NAME_PREFIX = "NIGHTLINK-"

    /** TXT-Felder des Dienstes. Der Zugangscode wird bewusst NIE angekündigt. */
    const val TXT_DEVICE_ID = "id"
    const val TXT_CAMERA_NAME = "name"
    const val TXT_PROTOCOL = "v"

    const val PROTOCOL_VERSION = 1

    /** Reservierter Port für den späteren Signaling-Kanal (WebRTC, ab v0.2). */
    const val SIGNALING_PORT = 48200
}
