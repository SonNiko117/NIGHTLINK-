package com.nightlink.app.transport

import com.nightlink.app.core.RemoteCamera
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/*
 * Architektur-Vorbereitung für WebRTC (ab v0.2). Die UI kennt nur diese Interfaces;
 * eine WebRTC-Implementierung ersetzt später UnavailableVideoTransport, ohne dass
 * Screens oder ViewModels geändert werden müssen. Eine PC-Version kann dieselben
 * Signaling-Nachrichten verwenden.
 */

/** Nachrichten des lokalen Signaling-Kanals (Austausch von SDP/ICE im LAN). */
sealed interface SignalingMessage {
    data class Hello(val deviceId: String, val accessCodeProof: String) : SignalingMessage
    data class Offer(val sdp: String) : SignalingMessage
    data class Answer(val sdp: String) : SignalingMessage
    data class IceCandidate(val sdpMid: String?, val sdpMLineIndex: Int, val candidate: String) : SignalingMessage
}

interface SignalingChannel {
    val incoming: Flow<SignalingMessage>
    suspend fun connect(camera: RemoteCamera, accessCode: String): Result<Unit>
    suspend fun send(message: SignalingMessage)
    fun close()
}

enum class VideoSessionState { IDLE, CONNECTING, STREAMING, FAILED, NOT_AVAILABLE }

interface VideoSession {
    val state: StateFlow<VideoSessionState>
    suspend fun start()
    fun stop()
}

interface VideoTransportFactory {
    /** Kontrollgerät: empfängt den Stream einer Kamera. */
    fun createViewerSession(camera: RemoteCamera): VideoSession

    /** Kameragerät: sendet den Stream an verbundene Kontrollgeräte (mehrere gleichzeitig). */
    fun createPublisherSession(): VideoSession
}

/** Version 0.1: Videoübertragung ist noch nicht implementiert. */
class UnavailableVideoTransportFactory : VideoTransportFactory {
    private class UnavailableSession : VideoSession {
        override val state: StateFlow<VideoSessionState> = MutableStateFlow(VideoSessionState.NOT_AVAILABLE)
        override suspend fun start() = Unit
        override fun stop() = Unit
    }

    override fun createViewerSession(camera: RemoteCamera): VideoSession = UnavailableSession()
    override fun createPublisherSession(): VideoSession = UnavailableSession()
}
