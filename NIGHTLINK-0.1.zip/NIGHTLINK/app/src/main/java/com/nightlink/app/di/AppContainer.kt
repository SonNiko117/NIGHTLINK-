package com.nightlink.app.di

import android.content.Context
import com.nightlink.app.data.SettingsRepository
import com.nightlink.app.discovery.CameraAdvertiser
import com.nightlink.app.discovery.CameraBrowser
import com.nightlink.app.discovery.NsdCameraAdvertiser
import com.nightlink.app.discovery.NsdCameraBrowser
import com.nightlink.app.network.NetworkMonitor
import com.nightlink.app.transport.UnavailableVideoTransportFactory
import com.nightlink.app.transport.VideoTransportFactory
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/** Einfacher manueller Dependency-Container (ersetzt bei Bedarf später Hilt). */
class AppContainer(context: Context) {
    private val appContext = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val settings = SettingsRepository(appContext)
    val networkMonitor = NetworkMonitor(appContext)
    val advertiser: CameraAdvertiser = NsdCameraAdvertiser(appContext)
    val browser: CameraBrowser = NsdCameraBrowser(appContext)
    val videoTransport: VideoTransportFactory = UnavailableVideoTransportFactory()

    init {
        scope.launch { settings.ensureIdentity() }
        scope.launch { settings.settings.collect { browser.ownDeviceId = it.deviceId } }
    }
}
