package com.nightlink.app.data

import android.content.Context
import android.os.Build
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.nightlink.app.core.AppMode
import com.nightlink.app.core.AppSettings
import com.nightlink.app.core.CameraLens
import com.nightlink.app.security.AccessCode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.util.UUID

private val Context.dataStore by preferencesDataStore(name = "nightlink_settings")

class SettingsRepository(private val context: Context) {

    private object Keys {
        val DEVICE_ID = stringPreferencesKey("device_id")
        val CAMERA_NAME = stringPreferencesKey("camera_name")
        val LENS = stringPreferencesKey("lens")
        val MODE = stringPreferencesKey("mode")
        val ACCESS_CODE = stringPreferencesKey("access_code")
    }

    val settings: Flow<AppSettings> = context.dataStore.data
        .catch { emit(androidx.datastore.preferences.core.emptyPreferences()) }
        .map { it.toSettings() }

    /** Legt beim ersten Start Geräte-ID und Zugangscode an. */
    suspend fun ensureIdentity() {
        context.dataStore.edit { p ->
            if (p[Keys.DEVICE_ID].isNullOrBlank()) p[Keys.DEVICE_ID] = UUID.randomUUID().toString()
            if (p[Keys.ACCESS_CODE].isNullOrBlank()) p[Keys.ACCESS_CODE] = AccessCode.generate()
        }
    }

    suspend fun setCameraName(name: String) {
        val clean = name.filter { !it.isISOControl() }.take(AppSettings.MAX_NAME_LENGTH)
        context.dataStore.edit { it[Keys.CAMERA_NAME] = clean }
    }

    suspend fun setLens(lens: CameraLens) {
        context.dataStore.edit { it[Keys.LENS] = lens.name }
    }

    suspend fun setMode(mode: AppMode?) {
        context.dataStore.edit {
            if (mode == null) it.remove(Keys.MODE) else it[Keys.MODE] = mode.name
        }
    }

    suspend fun regenerateAccessCode() {
        context.dataStore.edit { it[Keys.ACCESS_CODE] = AccessCode.generate() }
    }

    private fun Preferences.toSettings() = AppSettings(
        deviceId = this[Keys.DEVICE_ID].orEmpty(),
        cameraName = this[Keys.CAMERA_NAME] ?: Build.MODEL.orEmpty().take(AppSettings.MAX_NAME_LENGTH),
        lens = runCatching { CameraLens.valueOf(this[Keys.LENS] ?: "") }.getOrDefault(CameraLens.BACK),
        mode = runCatching { AppMode.valueOf(this[Keys.MODE] ?: "") }.getOrNull(),
        accessCode = this[Keys.ACCESS_CODE].orEmpty(),
    )
}
