package com.nightlink.app.security

import java.net.InetAddress
import java.security.SecureRandom

/** Verhindert, dass Adressen außerhalb des lokalen Netzwerks akzeptiert werden. */
object LocalNetworkGuard {
    fun isLocal(address: InetAddress?): Boolean =
        address != null && (address.isSiteLocalAddress || address.isLinkLocalAddress)
}

object AccessCode {
    private val random = SecureRandom()

    /** 6-stelliger zufälliger Code. */
    fun generate(): String = "%06d".format(random.nextInt(1_000_000))
}
