package com.nightlink.app.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import com.nightlink.app.R
import com.nightlink.app.ui.theme.NL

private val PanelShape = CutCornerShape(topEnd = 14.dp, bottomStart = 14.dp)

@Composable
fun NightBackground(content: @Composable () -> Unit) {
    Box(Modifier.fillMaxSize().background(NL.Black)) {
        Canvas(Modifier.fillMaxSize()) {
            // Dezente Scanlines + Vignette
            val step = 5.dp.toPx()
            var y = 0f
            while (y < size.height) {
                drawLine(NL.Green.copy(alpha = 0.035f), Offset(0f, y), Offset(size.width, y), 1f)
                y += step
            }
            drawRect(
                Brush.radialGradient(
                    listOf(Color.Transparent, Color.Black.copy(alpha = 0.65f)),
                    center = center, radius = size.maxDimension * 0.75f,
                )
            )
        }
        content()
    }
}

/** Zentrierter, scrollbarer Inhalt mit Maximalbreite – passt auf Phones und Tablets. */
@Composable
fun ScreenContainer(content: @Composable ColumnScope.() -> Unit) {
    NightBackground {
        Box(Modifier.fillMaxSize().safeDrawingPadding(), contentAlignment = Alignment.TopCenter) {
            Column(
                modifier = Modifier
                    .widthIn(max = 600.dp)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                content = content,
            )
        }
    }
}

@Composable
fun NightTopBar(title: String, onBack: (() -> Unit)? = null, onSettings: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().height(56.dp), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back), tint = NL.Green)
            }
        }
        Text(
            title, style = MaterialTheme.typography.titleLarge, color = NL.Green,
            modifier = Modifier.weight(1f).padding(start = if (onBack == null) 4.dp else 0.dp),
        )
        if (onSettings != null) {
            IconButton(onClick = onSettings) {
                Icon(Icons.Filled.Settings, stringResource(R.string.open_settings), tint = NL.TextDim)
            }
        }
    }
}

@Composable
fun PanelCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val base = modifier
        .fillMaxWidth()
        .clip(PanelShape)
        .background(NL.Surface)
        .border(BorderStroke(1.dp, NL.Border), PanelShape)
    val clickable = if (onClick != null) base.clickable(role = Role.Button, onClick = onClick) else base
    Column(clickable.padding(16.dp), content = content)
}

@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Text(
        text, style = MaterialTheme.typography.labelMedium, color = NL.GreenDim,
        modifier = modifier.padding(top = 20.dp, bottom = 8.dp),
    )
}

enum class ButtonKind { PRIMARY, OUTLINE, DANGER }

@Composable
fun NightButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    kind: ButtonKind = ButtonKind.PRIMARY,
    enabled: Boolean = true,
) {
    val shape = CutCornerShape(topEnd = 10.dp, bottomStart = 10.dp)
    val sized = modifier.fillMaxWidth().height(52.dp)
    when (kind) {
        ButtonKind.OUTLINE -> OutlinedButton(
            onClick, sized, enabled, shape = shape,
            border = BorderStroke(1.dp, if (enabled) NL.GreenDim else NL.Border),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = NL.Green),
        ) { Text(text, style = MaterialTheme.typography.labelLarge) }

        else -> Button(
            onClick, sized, enabled, shape = shape,
            colors = ButtonDefaults.buttonColors(
                containerColor = if (kind == ButtonKind.DANGER) NL.Red else NL.Green,
                contentColor = NL.Black,
                disabledContainerColor = NL.SurfaceHigh,
                disabledContentColor = NL.TextDim,
            ),
        ) { Text(text, style = MaterialTheme.typography.labelLarge) }
    }
}

@Composable
fun StatusDot(color: Color, pulsing: Boolean = false, size: Int = 10) {
    val alpha = if (pulsing) {
        val t = rememberInfiniteTransition(label = "dot")
        val a by t.animateFloat(
            0.35f, 1f,
            infiniteRepeatable(tween(900, easing = LinearEasing), RepeatMode.Reverse), label = "dotAlpha",
        )
        a
    } else 1f
    Box(Modifier.size(size.dp).alpha(alpha).background(color, CircleShape))
}

@Composable
fun StatusRow(color: Color, text: String, pulsing: Boolean = false, modifier: Modifier = Modifier) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        StatusDot(color, pulsing)
        Spacer(Modifier.size(10.dp))
        Text(text, style = MaterialTheme.typography.labelMedium, color = color)
    }
}

@Composable
fun NightlinkLogo(modifier: Modifier = Modifier.size(120.dp)) {
    val t = rememberInfiniteTransition(label = "logo")
    val pulse by t.animateFloat(
        0.55f, 1f, infiniteRepeatable(tween(1800, easing = LinearEasing), RepeatMode.Reverse), label = "pulse",
    )
    Canvas(modifier) {
        val c = center
        val r = size.minDimension / 2
        drawCircle(NL.Green.copy(alpha = 0.10f * pulse), radius = r)
        drawCircle(NL.Green.copy(alpha = pulse), radius = r * 0.62f, style = Stroke(width = r * 0.06f))
        drawCircle(NL.Green, radius = r * 0.24f)
        drawCircle(NL.Black, radius = r * 0.09f, center = c + Offset(r * 0.07f, -r * 0.07f))
        val tick = r * 0.2f
        val w = r * 0.05f
        drawLine(NL.GreenDim, Offset(c.x, c.y - r), Offset(c.x, c.y - r + tick), w)
        drawLine(NL.GreenDim, Offset(c.x, c.y + r), Offset(c.x, c.y + r - tick), w)
        drawLine(NL.GreenDim, Offset(c.x - r, c.y), Offset(c.x - r + tick, c.y), w)
        drawLine(NL.GreenDim, Offset(c.x + r, c.y), Offset(c.x + r - tick, c.y), w)
    }
}

enum class ModeIcon { CAMERA, CONTROL }

@Composable
fun ModeCard(title: String, description: String, icon: ModeIcon, onClick: () -> Unit) {
    PanelCard(onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Canvas(Modifier.size(44.dp)) {
                val s = Stroke(width = 2.5.dp.toPx())
                when (icon) {
                    ModeIcon.CAMERA -> {
                        drawRect(NL.Green, Offset(2f, size.height * 0.25f), Size(size.width - 4f, size.height * 0.5f), style = s)
                        drawCircle(NL.Green, size.minDimension * 0.14f, center, style = s)
                    }
                    ModeIcon.CONTROL -> {
                        val g = size.width * 0.42f
                        val gap = size.width * 0.16f
                        for (i in 0..1) for (j in 0..1) {
                            drawRect(NL.Green, Offset(i * (g + gap), j * (g + gap)), Size(g, g), style = s)
                        }
                    }
                }
            }
            Spacer(Modifier.size(16.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium, color = NL.Text)
                Spacer(Modifier.height(4.dp))
                Text(description, style = MaterialTheme.typography.bodyMedium, color = NL.TextDim)
            }
        }
    }
}
