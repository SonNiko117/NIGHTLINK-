package com.nightlink.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.nightlink.app.core.AppMode
import com.nightlink.app.core.AppSettings
import com.nightlink.app.core.CameraLens
import com.nightlink.app.core.RemoteCamera
import com.nightlink.app.core.WifiStatus
import com.nightlink.app.di.AppContainer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

private const val STOP_TIMEOUT_MS = 5_000L

/** Geteilt von Startbildschirm und Einstellungen. */
class AppViewModel(private val c: AppContainer) : ViewModel() {
    val settings: StateFlow<AppSettings> = c.settings.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), AppSettings.EMPTY)
    val wifi: StateFlow<WifiStatus> = c.networkMonitor.wifiStatus
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), c.networkMonitor.currentStatus())

    fun setMode(mode: AppMode?) { viewModelScope.launch { c.settings.setMode(mode) } }
    fun setCameraName(name: String) { viewModelScope.launch { c.settings.setCameraName(name) } }
    fun setLens(lens: CameraLens) { viewModelScope.launch { c.settings.setLens(lens) } }
    fun regenerateAccessCode() { viewModelScope.launch { c.settings.regenerateAccessCode() } }
}

class CameraViewModel(private val c: AppContainer) : ViewModel() {
    val settings: StateFlow<AppSettings> = c.settings.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), AppSettings.EMPTY)
    val wifi: StateFlow<WifiStatus> = c.networkMonitor.wifiStatus
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), c.networkMonitor.currentStatus())
    val advertiseState = c.advertiser.state

    /** Nie persistiert: Die Kamera muss bei jedem Start ausdrücklich aktiviert werden. */
    private val _active = MutableStateFlow(false)
    val active: StateFlow<Boolean> = _active.asStateFlow()

    init {
        // Ankündigung im Netzwerk folgt Aktivierung + WLAN + Kameraname (Name wird automatisch aktualisiert).
        viewModelScope.launch {
            combine(_active, wifi, settings) { active, wifi, s ->
                Announce(active && wifi == WifiStatus.CONNECTED && s.deviceId.isNotEmpty(), s.deviceId, s.advertisedName)
            }.distinctUntilChanged().collect {
                if (it.on) c.advertiser.start(it.id, it.name) else c.advertiser.stop()
            }
        }
    }

    private data class Announce(val on: Boolean, val id: String, val name: String)

    fun setActive(active: Boolean) { _active.value = active }
    fun setCameraName(name: String) { viewModelScope.launch { c.settings.setCameraName(name) } }
    fun setLens(lens: CameraLens) { viewModelScope.launch { c.settings.setLens(lens) } }

    override fun onCleared() {
        _active.value = false
        c.advertiser.stop()
    }
}

class ControlViewModel(private val c: AppContainer) : ViewModel() {
    val wifi: StateFlow<WifiStatus> = c.networkMonitor.wifiStatus
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), c.networkMonitor.currentStatus())
    val cameras = c.browser.cameras
    val isScanning = c.browser.isScanning
    val errorCode = c.browser.errorCode

    private val selectedId = MutableStateFlow<String?>(null)
    val selectedCamera: StateFlow<RemoteCamera?> = combine(cameras, selectedId) { list, id ->
        list.firstOrNull { it.id == id }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), null)

    init {
        viewModelScope.launch {
            wifi.collect { if (it == WifiStatus.CONNECTED) c.browser.start() else c.browser.stop() }
        }
    }

    fun select(camera: RemoteCamera) { selectedId.value = camera.id }

    fun rescan() {
        c.browser.stop()
        if (wifi.value == WifiStatus.CONNECTED) c.browser.start()
    }

    override fun onCleared() { c.browser.stop() }
}

class NightlinkViewModelFactory(private val container: AppContainer) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = when {
        modelClass.isAssignableFrom(AppViewModel::class.java) -> AppViewModel(container)
        modelClass.isAssignableFrom(CameraViewModel::class.java) -> CameraViewModel(container)
        modelClass.isAssignableFrom(ControlViewModel::class.java) -> ControlViewModel(container)
        else -> throw IllegalArgumentException("Unknown ViewModel: ${modelClass.name}")
    } as T
}
