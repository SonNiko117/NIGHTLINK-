package com.nightlink.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nightlink.app.R
import com.nightlink.app.core.DeviceStatus
import com.nightlink.app.core.RemoteCamera
import com.nightlink.app.core.WifiStatus
import com.nightlink.app.ui.components.ButtonKind
import com.nightlink.app.ui.components.NightButton
import com.nightlink.app.ui.components.NightTopBar
import com.nightlink.app.ui.components.PanelCard
import com.nightlink.app.ui.components.ScreenContainer
import com.nightlink.app.ui.components.SectionLabel
import com.nightlink.app.ui.components.StatusDot
import com.nightlink.app.ui.components.StatusRow
import com.nightlink.app.ui.theme.NL
import com.nightlink.app.viewmodel.ControlViewModel

@Composable
fun ControlScreen(vm: ControlViewModel, onBack: () -> Unit, onSettings: () -> Unit) {
    val wifi by vm.wifi.collectAsStateWithLifecycle()
    val cameras by vm.cameras.collectAsStateWithLifecycle()
    val scanning by vm.isScanning.collectAsStateWithLifecycle()
    val error by vm.errorCode.collectAsStateWithLifecycle()
    val selected by vm.selectedCamera.collectAsStateWithLifecycle()
    val connected = wifi == WifiStatus.CONNECTED

    ScreenContainer {
        NightTopBar(stringResource(R.string.control_title), onBack = onBack, onSettings = onSettings)

        // Status der Suche
        Row(verticalAlignment = Alignment.CenterVertically) {
            when {
                !connected -> StatusRow(NL.Red, stringResource(R.string.wifi_disconnected))
                error != null -> StatusRow(NL.Red, stringResource(R.string.scan_error, error ?: 0))
                scanning -> StatusRow(NL.Green, stringResource(R.string.scanning), pulsing = true)
                else -> StatusRow(NL.Amber, stringResource(R.string.scan_idle))
            }
        }

        SectionLabel(stringResource(R.string.monitor))
        MonitorPanel(selected)

        SectionLabel(stringResource(R.string.cameras_found, cameras.size))
        when {
            !connected -> Text(stringResource(R.string.no_wifi_control), style = MaterialTheme.typography.bodyMedium, color = NL.TextDim)
            cameras.isEmpty() -> Text(stringResource(R.string.no_cameras), style = MaterialTheme.typography.bodyMedium, color = NL.TextDim)
            else -> Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                cameras.forEach { cam ->
                    CameraRow(cam, isSelected = cam.id == selected?.id, onClick = { vm.select(cam) })
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        NightButton(stringResource(R.string.rescan), vm::rescan, kind = ButtonKind.OUTLINE, enabled = connected)
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun CameraRow(cam: RemoteCamera, isSelected: Boolean, onClick: () -> Unit) {
    val online = cam.status == DeviceStatus.ONLINE
    val statusColor = if (online) NL.Green else NL.Red
    PanelCard(
        onClick = onClick,
        modifier = if (isSelected) Modifier.border(1.5.dp, NL.Green, RoundedCornerShape(2.dp)) else Modifier,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            StatusDot(statusColor, pulsing = online, size = 12)
            Spacer(Modifier.size(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    cam.name, style = MaterialTheme.typography.titleMedium, color = NL.Text,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
                Text(cam.host, style = MaterialTheme.typography.bodySmall, color = NL.TextDim)
            }
            Text(
                stringResource(if (online) R.string.online else R.string.offline),
                style = MaterialTheme.typography.labelMedium, color = statusColor,
            )
        }
    }
}

/** Vorbereitete Kameraansicht. Hier wird ab v0.2 der WebRTC-Videostream eingehängt. */
@Composable
private fun MonitorPanel(camera: RemoteCamera?) {
    Box(
        Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(RoundedCornerShape(4.dp))
            .background(NL.SurfaceHigh).border(1.dp, NL.Border, RoundedCornerShape(4.dp)),
        contentAlignment = Alignment.Center,
    ) {
        if (camera == null) {
            Text(
                stringResource(R.string.select_camera), style = MaterialTheme.typography.bodyMedium,
                color = NL.TextDim, textAlign = TextAlign.Center, modifier = Modifier.padding(16.dp),
            )
        } else {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(16.dp)) {
                Text(camera.name, style = MaterialTheme.typography.labelLarge, color = NL.Green, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(8.dp))
                Text(stringResource(R.string.no_signal), style = MaterialTheme.typography.titleLarge, color = NL.TextDim)
                Text(
                    stringResource(R.string.no_signal_desc), style = MaterialTheme.typography.bodySmall,
                    color = NL.TextDim, textAlign = TextAlign.Center,
                )
            }
        }
    }
}
