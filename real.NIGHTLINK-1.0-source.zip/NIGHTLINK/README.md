# NIGHTLINK Android 1.0

> **Status (Audit 1.0):** Die Android-App wurde in der Entwicklungsumgebung **weiterhin nicht gebaut und nicht auf einem Gerät
> ausgeführt** (kein Android-SDK, kein Maven-Zugriff). Geprüft wurde: vollständige Quellcode-Durchsicht, Kompilierung und
> Ausführung der reinen JVM-Teile (Update-Logik, Security, Signaling) samt 45 Unit-Tests mit Kotlin 2.0.21, XML-/Ressourcen-Prüfung.
> **Nicht** geprüft: Android-/Compose-/CameraX-/WebRTC-Code, `assembleDebug`, Installation, Kamera und Video auf echter Hardware.
> Den Build übernimmt GitHub Actions (siehe „Build“); Releases dürfen erst nach erfolgreichem Gerätetest veröffentlicht werden.

## Neu in 1.0
- **Querformat** für Kamera und Kontrollmodus: zwei Spalten (Video links, Bedienung rechts, jeweils scrollbar); Hochformat unverändert.
  Die Activity wird beim Drehen nicht neu erstellt; Verbindungen (Service/ViewModel) bleiben bestehen. Der Kamera-Service
  übernimmt die Display-Drehung (`targetRotation`), das Bild bleibt auch bei umgekehrtem Querformat aufrecht.
- **„Nach Updates suchen“** ganz unten auf der Einstellungs-Hauptseite, direkt unter DATENSCHUTZ (nicht darin).
  Ablauf: GitHub-Release abfragen → Versionsvergleich → Release-Infos → Download mit Fortschritt → Prüfung → Android-Installer.
- **Debug-Variante** `com.nightlink.app.debug` („NIGHTLINK DEBUG“), läuft neben der Release-App.
- Version **1.0.0**, `versionCode` 10000 (= major·10000 + minor·100 + patch, berechnet in `app/build.gradle.kts`). Auch die Debug-App zeigt „1.0.0“
  (erkennbar an App-ID `.debug` und dem Namen „NIGHTLINK DEBUG“).

## Update-System – Details
- Quelle: `https://api.github.com/repos/<owner>/<repo>/releases/latest` (Release-App) bzw. `/releases` inkl. Pre-Releases (Debug-App).
  **Repository:** `nightlink.updateRepo=SonNiko117/NIGHTLINK-` in `gradle.properties` (ohne Eintrag meldet die App „Update-Quelle nicht eingerichtet“).
  Solange es kein GitHub-Release gibt, meldet „Nach Updates suchen“: „Es wurde noch kein Release veröffentlicht.“
- Sicherheit: nur HTTPS, nur `api.github.com`/`github.com`/`*.githubusercontent.com` (auch bei Weiterleitungen), Download-URL muss
  zum konfigurierten Repo gehören, keine Tokens. Zwingend: SHA-256 (GitHub-`digest` oder Datei `<apk>.sha256` im Release),
  dann Prüfung per PackageManager: gleiche Paketkennung, höherer `versionCode`, **gleiche Signatur** wie die installierte App.
  Ohne Prüfsumme wird nicht installiert.
- Asset-Namen: Release-APK ohne „debug“ im Namen (z. B. `NIGHTLINK-1.0.0-release.apk`), Debug-APK mit „debug“
  (`NIGHTLINK-1.0.1-debug.apk`). Release-Apps bekommen nie Debug-APKs und keine Pre-Releases.
- Installation: offizieller Android-Paketinstaller; der Nutzer bestätigt. Ggf. einmalig „Unbekannte Apps installieren“ erlauben.

## Build
- **GitHub Actions** (`.github/workflows/android.yml`): baut bei jedem Push (außer reinen `*.md`-Änderungen) und per „Run workflow“ die
  **Debug-APK** mit Java 17, Android SDK 35 und Gradle 8.9 (Wrapper). Danach wird die APK geprüft (App-ID `com.nightlink.app.debug`,
  Version/`versionCode`, minSdk 29/targetSdk 35, debuggable, kein `RECORD_AUDIO`, `apksigner verify`) und als Artifact
  **`NIGHTLINK-debug-APK`** bereitgestellt: `NIGHTLINK-1.0.0-debug.apk` + `.sha256`. Anschließend laufen die Unit-Tests.
  Download: GitHub → Actions → Lauf auswählen → Artifacts → `NIGHTLINK-debug-APK`.
  Projektquelle: `settings.gradle(.kts)` im Repo-Root, sonst die (einzige) `*.zip` im Root.
- Lokal: `./gradlew assembleDebug` → `app/build/outputs/apk/debug/app-debug.apk` (signiert mit `app/debug.keystore`, nur für Tests).
- Release: `keystore.properties` aus `keystore.properties.example` anlegen (oder Env `NIGHTLINK_KEYSTORE`, `…_PASSWORD`, `NIGHTLINK_KEY_ALIAS`, `NIGHTLINK_KEY_PASSWORD`),
  dann `./gradlew assembleRelease`. Ohne Schlüssel oder ohne `nightlink.updateRepo` bricht der Release-Build ab. **Den Release-Schlüssel nie verlieren oder wechseln**,
  sonst akzeptiert Android keine Updates. Der Workflow baut **keine** Release-APK.
- Tests: `./gradlew testDebugUnitTest`.
- Es gibt keine automatische Veröffentlichung.

## Testanleitung 1.0 (Debug)
1. Debug-APK (Artifact `NIGHTLINK-debug-APK`) auf zwei Geräte installieren, gleiches WLAN. Falls vorhanden, läuft die Release-App `com.nightlink.app` daneben unverändert weiter.
2. Kamera (Gerät A) aktivieren; Gerät A drehen (Hoch → Quer → umgekehrt Quer → Hoch): Vorschau aufrecht, keine Abstürze, Buttons erreichbar.
3. Kontrollmodus (Gerät B) verbinden, dann drehen: Verbindung bleibt, Bild aufrecht, Code-/Adressfelder behalten ihre Eingabe, Kameraleiste sichtbar. Bild auf B in Quer prüfen, während A hoch/quer gehalten wird.
4. Zahnrad → ganz nach unten scrollen: Button „Nach Updates suchen“ steht unter DATENSCHUTZ.
5. Update-Test (`nightlink.updateRepo` ist gesetzt): Auf GitHub ein **Pre-Release** `v1.0.1` mit `NIGHTLINK-1.0.1-debug.apk` anlegen
   (versionCode höher setzen, gleicher Debug-Schlüssel). Button tippen → „Update verfügbar“ mit Release-Infos → Herunterladen (Fortschritt) →
   Installieren → Android-Dialog. Ohne neueres Release: „Kein Update verfügbar“. Flugmodus: Netzwerkfehler. Falsche Prüfsumme: Ablehnung.

---
# Frühere Doku (0.3)

Lokales Kamera-/Fernsteuerungssystem im WLAN: Ein Android-Gerät sendet seine Kamera per WebRTC
an ein zweites Android-Gerät. Kein Cloud-Server, kein STUN/TURN.

> **Status:** Der Code in diesem Stand wurde **nicht kompiliert und nicht ausgeführt** – die
> Entwicklungsumgebung hatte weder Android-SDK noch Gradle noch Internetzugang. Es existiert daher
> **keine geprüfte APK**. Erwarte beim ersten Build einzelne Compilerfehler und plane Tests auf zwei
> echten Geräten ein. Siehe „Nicht verifiziert“.

## Neu in 0.3 – Mehrere Kameras (FNAF-Stil)
- **Erste Kamera** wie in 0.2 verbinden. Danach erscheint oben rechts ein kleines Zahnrad mit dem Menü
  „Mehrere Kameras verbinden“, „Kamera umbenennen“ und „Einstellungen“.
- **Weitere Kameras** über „Mehrere Kameras verbinden“ (Liste/Code/manuelle Adresse). Bereits verbundene
  Kameras bleiben verbunden; doppelte Einträge (gleiche ID oder Adresse) werden verhindert. Max. 8 Kameras.
- **Untere Leiste** (ab 2 Kameras): ein Eintrag pro Kamera („CAM 01“ + Gerätename), horizontal scrollbar,
  gewählte Kamera grün hervorgehoben, Punkt zeigt Zustand (grün/gelb/rot). Es wird immer nur EIN Bild angezeigt.
- **Namen:** echter Gerätename der Kamera; eigener Name über das Menü (leer = Gerätename).
- **Verbindungsabbruch:** Kamera bleibt in der Leiste, Punkt wird gelb/rot, Hinweis unter dem Monitor; automatische Neuverbindung.
- **Ressourcen:** nicht angezeigte Kameras behalten ihre Verbindung, liefern aber keine Frames an die UI und
  keine Statistik-Abfragen. Der Videostrom selbst läuft weiter (die Kamera weiß nicht, welche gerade betrachtet wird).
- **Neustart der App:** gemerkt werden zuletzt gewählte Kamera sowie Name/Adresse bekannter Kameras – **nicht** die
  Zugangscodes (Sicherheitsentscheidung aus 0.2). Nach dem Start muss der Code erneut eingegeben werden; die zuletzt
  gewählte Kamera wird dann wieder angezeigt.
- Nicht kompiliert/getestet, siehe „Nicht verifiziert“ (weiterhin gültig, auch für 0.3).

## Bauen
1. Ordner in Android Studio (aktuell, JDK 17) öffnen, Gradle-Sync abwarten (Gradle 8.9, AGP 8.7.3).
2. Debug-APK: `./gradlew assembleDebug` (benötigt einmalig Internet für Abhängigkeiten).
   Unit-Tests: `./gradlew testDebugUnitTest`.
3. Der Gradle-Wrapper (`gradlew`, `gradlew.bat`, `gradle-wrapper.jar`) liegt seit dem 1.0-Audit bei.

## Zwei Handys testen
1. Beide Geräte im **selben WLAN** (Gast-Netze mit „Client-Isolation“ blockieren mDNS und Verbindungen).
2. Gerät A: **CAMERA MODE** → „KAMERA AKTIVIEREN“ → Kamera-/Benachrichtigungsrecht erlauben.
   Der 6-stellige Zugangscode steht auf dem Bildschirm.
3. Gerät B: **CONTROL MODE** → Kamera erscheint in der Liste (sonst „NEU SUCHEN“ oder manuell per IP).
   Kamera antippen → Code eingeben → „VERBINDEN“.
4. Prüfen: Livebild, Qualitätsanzeige, Front/Rück-Wechsel und Blitz auf Gerät A, „TRENNEN“/„ERNEUT VERBINDEN“.
5. Display von Gerät A ausschalten: Bild muss weiterlaufen (Benachrichtigung sichtbar).
6. WLAN kurz aus/an (Gerät B): Ansicht zeigt „VERBINDUNG UNTERBROCHEN“ und verbindet automatisch neu.
7. Falschen Code eingeben: muss abgelehnt werden; nach 5 Fehlversuchen 30 s Sperre.

## Architektur (com.nightlink.app)
- `core/` Modelle, Protokollkonstanten · `data/` Einstellungen (DataStore) · `network/` WLAN-Status
- `discovery/` mDNS `_nightlink._tcp.` (NsdManager); TXT enthält nur id, name, v – **nie den Code**
- `security/` `Handshake` (Challenge-Response + AES-GCM-Kanal), `AuthGuard` (Sperre), `LocalNetworkGuard`
- `transport/` `SignalingServer`/`SignalingClient` (TCP :48200), `CameraPublisher`, `WebRtcViewerSession`
- `service/` `CameraService` (Foreground Service, Typ camera) + `CameraRuntime` (UI↔Service-Zustand)
- `ui/`, `viewmodel/`, `di/` wie in 0.1; Control-Screen mit Video, Code-Eingabe, manueller Verbindung

## Entscheidungen
- **Signaling ohne TLS-Zertifikate:** Self-signed-Zertifikate lassen sich auf Android ohne Zusatzbibliothek
  nicht erzeugen. Stattdessen: gegenseitige Challenge-Response mit PBKDF2(Code) und AES-256-GCM für alle
  Signaling-Nachrichten (SDP/ICE) danach. Medien sind zusätzlich durch WebRTC (DTLS-SRTP) verschlüsselt.
- **Kamera:** CameraX liefert Frames (ImageAnalysis, 1280×720) an WebRTC; so bleiben Vorschau, Blitz und Linsenwechsel CameraX.
- **INTERNET-Berechtigung** ist für Sockets nötig, auch im LAN; Verbindungen gehen nur zu privaten/Link-Local-Adressen.
  Keine Standort-, keine Mikrofonberechtigung. WAKE_LOCK hält CPU/WLAN im Hintergrund wach.
- Zugangscodes anderer Geräte werden nicht gespeichert; es wird nichts davon geloggt.

## Bekannte Grenzen
- 6-stelliger Code: Ein passiver Mithörer im WLAN könnte ihn aus einem mitgeschnittenen Handshake offline
  durchprobieren. Online-Raten wird gebremst, Offline-Raten nicht. Für höhere Sicherheit: längerer Code oder PAKE (SPAKE2).
- Ein neu erzeugter Code gilt nur für neue Verbindungen; bestehende bleiben bis zum Trennen offen.
- Kein Audio, keine Aufnahme, kein Internet-/Remote-Zugriff, max. 4 gleichzeitige Kontrollgeräte.
- Release-APK: nicht gebaut; es fehlt ein Signing-Key (`isMinifyEnabled=false`, ProGuard-Regeln für WebRTC liegen bei).

## Nicht verifiziert (nur theoretisch geprüft)
Kompilierung, alle Unit-Tests, Existenz/Kompatibilität von `io.getstream:stream-webrtc-android:1.3.8`,
mDNS-Erkennung, WebRTC-Aufbau über reine Host-Kandidaten (mDNS-ICE-Obfuskation könnte je nach Build
Kandidaten verschleiern), Hintergrundbetrieb bei ausgeschaltetem Display auf Herstellern mit aggressivem
Energiesparen (ggf. Akku-Optimierung für NIGHTLINK ausschalten).
