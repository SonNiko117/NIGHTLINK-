import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

// ---- Version (Quelle der Wahrheit: versionName; versionCode wird daraus berechnet: major*10000 + minor*100 + patch)
val appVersionName = "1.0.0"
val appVersionCode = appVersionName.split(".").map { it.toInt() }.let { (ma, mi, pa) -> ma * 10000 + mi * 100 + pa }

// ---- GitHub-Repository der Releases ("owner/repo"), z. B. in gradle.properties oder per -Pnightlink.updateRepo=owner/repo
val updateRepo: String = (project.findProperty("nightlink.updateRepo") as String?)?.trim().orEmpty()

// ---- Release-Signatur: keystore.properties (nicht einchecken!) oder Umgebungsvariablen. Ohne Angaben: unsignierte Release-APK.
val keystoreProps = Properties().apply {
    val f = rootProject.file("keystore.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}
fun signingValue(key: String, env: String): String? = keystoreProps.getProperty(key) ?: System.getenv(env)

android {
    namespace = "com.nightlink.app"
    compileSdk = 35
    // Feste Build-Tools: der Build soll nichts "on demand" nachladen müssen (CI installiert genau diese Version).
    buildToolsVersion = "35.0.0"

    defaultConfig {
        applicationId = "com.nightlink.app"
        minSdk = 29
        targetSdk = 35
        versionCode = appVersionCode
        versionName = appVersionName
        buildConfigField("String", "UPDATE_REPO", "\"$updateRepo\"")
        buildConfigField("String", "BASE_VERSION_NAME", "\"$appVersionName\"")
    }

    signingConfigs {
        // Gemeinsamer Debug-Schlüssel (nur Debug!): Debug-APKs verschiedener Rechner bleiben untereinander updatefähig.
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
        val storePath = signingValue("storeFile", "NIGHTLINK_KEYSTORE")
        if (storePath != null) {
            create("release") {
                storeFile = rootProject.file(storePath)
                storePassword = signingValue("storePassword", "NIGHTLINK_KEYSTORE_PASSWORD")
                keyAlias = signingValue("keyAlias", "NIGHTLINK_KEY_ALIAS")
                keyPassword = signingValue("keyPassword", "NIGHTLINK_KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        debug {
            // Eigene App-ID: läuft neben der Release-App, kann nie versehentlich ein Release "überschreiben".
            // versionName/versionCode bleiben bewusst identisch zum Release (1.0.0 / 10000): erkennbar ist die Debug-App
            // an der App-ID (.debug) und am Namen "NIGHTLINK DEBUG" (src/debug/res/values/strings.xml).
            applicationIdSuffix = ".debug"
            isDebuggable = true
            signingConfig = signingConfigs.getByName("debug")
        }
        release {
            signingConfig = signingConfigs.findByName("release")
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    packaging { resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" } }
    testOptions { unitTests.isReturnDefaultValues = true }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.navigation:navigation-compose:2.8.5")
    implementation("androidx.datastore:datastore-preferences:1.1.1")

    val composeBom = platform("androidx.compose:compose-bom:2024.12.01")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    debugImplementation("androidx.compose.ui:ui-tooling")

    val camerax = "1.4.1"
    implementation("androidx.camera:camera-core:$camerax")
    implementation("androidx.camera:camera-camera2:$camerax")
    implementation("androidx.camera:camera-lifecycle:$camerax")
    implementation("androidx.camera:camera-view:$camerax")

    implementation("androidx.lifecycle:lifecycle-service:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")

    // WebRTC: Community-Build des libwebrtc-Android-SDK (Stream), Paket "org.webrtc".
    // Hinweis: Version konnte in der Entwicklungsumgebung nicht gegen Maven Central geprüft werden.
    implementation("io.getstream:stream-webrtc-android:1.3.8")

    testImplementation("junit:junit:4.13.2")
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.9.0")
    testImplementation("org.json:json:20240303")
}

// Sicherheitsnetz: Ein Release-Build ohne Update-Quelle oder ohne Signatur ist nicht für die Veröffentlichung geeignet.
// (Debug-Builds sind davon nie betroffen.) Mit -Pnightlink.allowUnsignedRelease=true lässt sich der Check bewusst umgehen.
tasks.matching { it.name == "assembleRelease" || it.name == "bundleRelease" }.configureEach {
    doFirst {
        if (project.findProperty("nightlink.allowUnsignedRelease") != "true") {
            check(signingValue("storeFile", "NIGHTLINK_KEYSTORE") != null) {
                "Release-Build ohne Signatur: keystore.properties anlegen (siehe README) – Updates müssen mit demselben Schlüssel signiert sein."
            }
            check(updateRepo.isNotEmpty()) { "nightlink.updateRepo ist nicht gesetzt (gradle.properties)." }
        }
    }
}
