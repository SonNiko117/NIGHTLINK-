package com.nightlink.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.nightlink.app.core.AppMode
import com.nightlink.app.core.AppSettings
import com.nightlink.app.core.CameraLens
import com.nightlink.app.core.RemoteCamera
import com.nightlink.app.core.WifiStatus
import com.nightlink.app.di.AppContainer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import com.nightlink.app.core.DeviceStatus
import com.nightlink.app.core.NightlinkProtocol
import com.nightlink.app.security.AccessCode
import com.nightlink.app.transport.ConnectError
import com.nightlink.app.transport.StreamStats
import com.nightlink.app.transport.ViewerSession
import com.nightlink.app.transport.ViewerState
import org.webrtc.VideoTrack

private const val STOP_TIMEOUT_MS = 5_000L

/** Geteilt von Startbildschirm und Einstellungen. */
class AppViewModel(private val c: AppContainer) : ViewModel() {
    val settings: StateFlow<AppSettings> = c.settings.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), AppSettings.EMPTY)
    val wifi: StateFlow<WifiStatus> = c.networkMonitor.wifiStatus
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), c.networkMonitor.currentStatus())

    fun setMode(mode: AppMode?) { viewModelScope.launch { c.settings.setMode(mode) } }
    fun setCameraName(name: String) { viewModelScope.launch { c.settings.setCameraName(name) } }
    fun setLens(lens: CameraLens) { viewModelScope.launch { c.settings.setLens(lens) } }
    fun regenerateAccessCode() { viewModelScope.launch { c.settings.regenerateAccessCode() } }
}

class CameraViewModel(private val c: AppContainer) : ViewModel() {
    val settings: StateFlow<AppSettings> = c.settings.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), AppSettings.EMPTY)
    val wifi: StateFlow<WifiStatus> = c.networkMonitor.wifiStatus
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), c.networkMonitor.currentStatus())
    val advertiseState = c.advertiser.state
    val runtime = c.cameraRuntime

    /** Läuft der Foreground Service? Wird nie persistiert: Aktivierung ist immer ausdrücklich. */
    val active: StateFlow<Boolean> = runtime.running
    val clients = runtime.clients
    val torchAvailable = runtime.torchAvailable
    val torchWanted = runtime.torchWanted
    val error = runtime.error

    fun start() = c.startCameraService()
    fun stop() = c.stopCameraService()
    fun setTorch(on: Boolean) = runtime.setTorchWanted(on)
    fun setCameraName(name: String) { viewModelScope.launch { c.settings.setCameraName(name) } }
    fun setLens(lens: CameraLens) { viewModelScope.launch { c.settings.setLens(lens) } }
    fun clearError() = runtime.setError(null)
}

/** Zusammengefasster Zustand der Videoverbindung für die UI. */
data class ViewerUi(
    val state: ViewerState = ViewerState.IDLE,
    val error: ConnectError? = null,
    val stats: StreamStats? = null,
    val video: VideoTrack? = null,
    val cameraName: String = "",
)

@OptIn(ExperimentalCoroutinesApi::class)
class ControlViewModel(private val c: AppContainer) : ViewModel() {
    val wifi: StateFlow<WifiStatus> = c.networkMonitor.wifiStatus
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), c.networkMonitor.currentStatus())
    val cameras = c.browser.cameras
    val isScanning = c.browser.isScanning
    val errorCode = c.browser.errorCode
    val eglBase get() = c.videoTransport.eglBase

    private val selectedId = MutableStateFlow<String?>(null)
    val selectedCamera: StateFlow<RemoteCamera?> = combine(cameras, selectedId) { list, id ->
        list.firstOrNull { it.id == id }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), null)

    private val session = MutableStateFlow<ViewerSession?>(null)
    private var target: Pair<RemoteCamera, String>? = null   // nur im Speicher, nie persistiert
    private val _manualError = MutableStateFlow<Boolean>(false)
    val manualError: StateFlow<Boolean> = _manualError.asStateFlow()

    val viewer: StateFlow<ViewerUi> = session.flatMapLatest { s ->
        if (s == null) flowOf(ViewerUi()) else combine(s.state, s.error, s.stats, s.remoteVideo) { st, e, stats, v ->
            ViewerUi(st, e, stats, v, target?.first?.name.orEmpty())
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), ViewerUi())

    init {
        viewModelScope.launch {
            wifi.collect { if (it == WifiStatus.CONNECTED) c.browser.start() else c.browser.stop() }
        }
    }

    fun select(camera: RemoteCamera) { selectedId.value = camera.id }

    fun rescan() {
        c.browser.stop()
        if (wifi.value == WifiStatus.CONNECTED) c.browser.start()
    }

    /** Verbindet mit einer gefundenen Kamera. Gibt false zurück, wenn der Code formal ungültig ist. */
    fun connect(camera: RemoteCamera, rawCode: String): Boolean {
        val code = AccessCode.normalize(rawCode)
        if (!AccessCode.isWellFormed(code)) return false
        startSession(camera, code)
        return true
    }

    /** Manuelle Verbindung per IP/Hostname. */
    fun connectManual(host: String, rawCode: String): Boolean {
        val code = AccessCode.normalize(rawCode)
        val clean = host.trim()
        val valid = clean.isNotEmpty() && clean.length <= 253 && clean.all { it.isLetterOrDigit() || it in ".-:" }
        _manualError.value = !valid || !AccessCode.isWellFormed(code)
        if (_manualError.value) return false
        val cam = RemoteCamera("manual:$clean", clean, clean, NightlinkProtocol.SIGNALING_PORT, DeviceStatus.ONLINE, System.currentTimeMillis())
        startSession(cam, code)
        return true
    }

    fun reconnect() { target?.let { startSession(it.first, it.second) } }

    fun disconnect() {
        session.value?.stop()
        session.value = null
        target = null
    }

    private fun startSession(camera: RemoteCamera, code: String) {
        session.value?.stop()
        // Bei gefundenen Kameras immer die aktuellste mDNS-Adresse verwenden.
        val fresh = c.browser.cameras.value.firstOrNull { it.id == camera.id && it.status == DeviceStatus.ONLINE } ?: camera
        target = fresh to code
        val s = c.videoTransport.createViewerSession(fresh, code, c.browser.ownDeviceId)
        session.value = s
        s.start()
    }

    override fun onCleared() {
        disconnect()
        c.browser.stop()
    }
}

class NightlinkViewModelFactory(private val container: AppContainer) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = when {
        modelClass.isAssignableFrom(AppViewModel::class.java) -> AppViewModel(container)
        modelClass.isAssignableFrom(CameraViewModel::class.java) -> CameraViewModel(container)
        modelClass.isAssignableFrom(ControlViewModel::class.java) -> ControlViewModel(container)
        else -> throw IllegalArgumentException("Unknown ViewModel: ${modelClass.name}")
    } as T
}
