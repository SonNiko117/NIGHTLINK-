package com.nightlink.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nightlink.app.R
import com.nightlink.app.core.DeviceStatus
import com.nightlink.app.core.RemoteCamera
import com.nightlink.app.core.WifiStatus
import com.nightlink.app.transport.ConnectError
import com.nightlink.app.transport.StreamQuality
import com.nightlink.app.transport.StreamStats
import com.nightlink.app.transport.ViewerState
import com.nightlink.app.ui.components.ButtonKind
import com.nightlink.app.ui.components.NightButton
import com.nightlink.app.ui.components.NightTopBar
import com.nightlink.app.ui.components.PanelCard
import com.nightlink.app.ui.components.RemoteVideoView
import com.nightlink.app.ui.components.ScreenContainer
import com.nightlink.app.ui.components.SectionLabel
import com.nightlink.app.ui.components.StatusDot
import com.nightlink.app.ui.components.StatusRow
import com.nightlink.app.ui.theme.NL
import com.nightlink.app.viewmodel.ControlViewModel
import com.nightlink.app.viewmodel.ViewerUi

@Composable
fun ControlScreen(vm: ControlViewModel, onBack: () -> Unit, onSettings: () -> Unit) {
    val wifi by vm.wifi.collectAsStateWithLifecycle()
    val cameras by vm.cameras.collectAsStateWithLifecycle()
    val scanning by vm.isScanning.collectAsStateWithLifecycle()
    val error by vm.errorCode.collectAsStateWithLifecycle()
    val selected by vm.selectedCamera.collectAsStateWithLifecycle()
    val viewer by vm.viewer.collectAsStateWithLifecycle()
    val manualError by vm.manualError.collectAsStateWithLifecycle()
    val connected = wifi == WifiStatus.CONNECTED
    val sessionActive = viewer.state != ViewerState.IDLE

    // Eingaben nur im Speicher (nie persistiert, nie geloggt).
    var code by remember { mutableStateOf("") }
    var codeInvalid by remember { mutableStateOf(false) }
    var manualHost by remember { mutableStateOf("") }

    ScreenContainer {
        NightTopBar(stringResource(R.string.control_title), onBack = onBack, onSettings = onSettings)

        Row(verticalAlignment = Alignment.CenterVertically) {
            when {
                !connected -> StatusRow(NL.Red, stringResource(R.string.wifi_disconnected))
                error != null -> StatusRow(NL.Red, stringResource(R.string.scan_error, error ?: 0))
                scanning -> StatusRow(NL.Green, stringResource(R.string.scanning), pulsing = true)
                else -> StatusRow(NL.Amber, stringResource(R.string.scan_idle))
            }
        }

        SectionLabel(stringResource(R.string.monitor))
        MonitorPanel(viewer, vm, selected)
        if (viewer.state == ViewerState.STREAMING) viewer.stats?.let { StatsLine(it) }

        if (sessionActive) {
            Spacer(Modifier.height(12.dp))
            if (viewer.state == ViewerState.FAILED) {
                NightButton(stringResource(R.string.reconnect), vm::reconnect)
                Spacer(Modifier.height(10.dp))
            }
            NightButton(stringResource(R.string.disconnect), vm::disconnect, kind = ButtonKind.DANGER)
        }

        SectionLabel(stringResource(R.string.cameras_found, cameras.size))
        when {
            !connected -> Text(stringResource(R.string.no_wifi_control), style = MaterialTheme.typography.bodyMedium, color = NL.TextDim)
            cameras.isEmpty() -> Text(stringResource(R.string.no_cameras), style = MaterialTheme.typography.bodyMedium, color = NL.TextDim)
            else -> Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                cameras.forEach { cam ->
                    CameraRow(cam, isSelected = cam.id == selected?.id, onClick = { vm.select(cam) })
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        NightButton(stringResource(R.string.rescan), vm::rescan, kind = ButtonKind.OUTLINE, enabled = connected)

        SectionLabel(stringResource(R.string.access_code))
        CodeField(code, { code = it.filter { c -> c.isDigit() }.take(6); codeInvalid = false }, codeInvalid)
        Spacer(Modifier.height(12.dp))
        NightButton(
            stringResource(R.string.connect),
            onClick = { selected?.let { codeInvalid = !vm.connect(it, code) } },
            enabled = connected && selected != null && selected?.status == DeviceStatus.ONLINE,
        )

        SectionLabel(stringResource(R.string.manual_connect))
        OutlinedTextField(
            value = manualHost,
            onValueChange = { manualHost = it.take(64) },
            singleLine = true,
            label = { Text(stringResource(R.string.manual_host)) },
            isError = manualError,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
            modifier = Modifier.fillMaxWidth(),
            colors = fieldColors(),
        )
        Spacer(Modifier.height(12.dp))
        NightButton(
            stringResource(R.string.connect_manual),
            onClick = { vm.connectManual(manualHost, code) },
            kind = ButtonKind.OUTLINE, enabled = connected,
        )
        if (manualError) {
            Text(stringResource(R.string.manual_invalid), color = NL.Red, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp))
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = NL.Green, unfocusedBorderColor = NL.Border, cursorColor = NL.Green,
    focusedTextColor = NL.Text, unfocusedTextColor = NL.Text,
    focusedLabelColor = NL.Green, unfocusedLabelColor = NL.TextDim,
    errorBorderColor = NL.Red, errorTextColor = NL.Text,
)

@Composable
private fun CodeField(code: String, onChange: (String) -> Unit, invalid: Boolean) {
    OutlinedTextField(
        value = code, onValueChange = onChange, singleLine = true, isError = invalid,
        label = { Text(stringResource(R.string.code_input_label)) },
        supportingText = { Text(stringResource(if (invalid) R.string.code_invalid else R.string.code_input_hint)) },
        visualTransformation = PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
        modifier = Modifier.fillMaxWidth(), colors = fieldColors(),
    )
}

@Composable
private fun StatsLine(s: StreamStats) {
    val (color, label) = when (s.quality) {
        StreamQuality.GOOD -> NL.Green to R.string.quality_good
        StreamQuality.MEDIUM -> NL.Amber to R.string.quality_medium
        StreamQuality.POOR -> NL.Red to R.string.quality_poor
    }
    Column(Modifier.padding(top = 8.dp)) {
        StatusRow(color, stringResource(label))
        Text(
            buildString {
                if (s.width > 0) append("${s.width}×${s.height} · ")
                append("${s.fps} FPS · ${"%.1f".format(s.bitrateKbps / 1000.0)} MBIT/S")
                s.rttMs?.let { append(" · $it MS") }
                if (s.lossPercent >= 0.5) append(" · ${"%.1f".format(s.lossPercent)} % VERLUST")
            },
            style = MaterialTheme.typography.labelMedium, color = NL.TextDim, modifier = Modifier.padding(top = 4.dp),
        )
    }
}

@Composable
private fun CameraRow(cam: RemoteCamera, isSelected: Boolean, onClick: () -> Unit) {
    val online = cam.status == DeviceStatus.ONLINE
    val statusColor = if (online) NL.Green else NL.Red
    PanelCard(
        onClick = onClick,
        modifier = if (isSelected) Modifier.border(1.5.dp, NL.Green, RoundedCornerShape(2.dp)) else Modifier,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            StatusDot(statusColor, pulsing = online, size = 12)
            Spacer(Modifier.size(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    cam.name, style = MaterialTheme.typography.titleMedium, color = NL.Text,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
                Text(cam.host, style = MaterialTheme.typography.bodySmall, color = NL.TextDim)
            }
            Text(
                stringResource(if (online) R.string.online else R.string.offline),
                style = MaterialTheme.typography.labelMedium, color = statusColor,
            )
        }
    }
}

@Composable
private fun MonitorPanel(ui: ViewerUi, vm: ControlViewModel, camera: RemoteCamera?) {
    Box(
        Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(RoundedCornerShape(4.dp))
            .background(NL.SurfaceHigh).border(1.dp, NL.Border, RoundedCornerShape(4.dp)),
        contentAlignment = Alignment.Center,
    ) {
        val track = ui.video
        if (track != null && ui.state == ViewerState.STREAMING) {
            RemoteVideoView(track, vm.eglBase, Modifier.fillMaxWidth().aspectRatio(16f / 9f))
            Box(Modifier.align(Alignment.TopStart).padding(10.dp)) { StatusRow(NL.Red, stringResource(R.string.live), pulsing = true) }
        } else {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(16.dp)) {
                val name = ui.cameraName.ifEmpty { camera?.name.orEmpty() }
                if (name.isNotEmpty()) {
                    Text(name, style = MaterialTheme.typography.labelLarge, color = NL.Green, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(8.dp))
                }
                val (title, desc) = when (ui.state) {
                    ViewerState.CONNECTING -> R.string.state_connecting to R.string.state_connecting_desc
                    ViewerState.RECONNECTING -> R.string.state_reconnecting to R.string.state_reconnecting_desc
                    ViewerState.STREAMING -> R.string.state_connecting to R.string.state_connecting_desc
                    ViewerState.FAILED -> R.string.state_failed to errorText(ui.error)
                    ViewerState.IDLE -> if (camera == null) null to R.string.select_camera else R.string.no_signal to R.string.no_signal_desc
                }
                if (title != null) Text(
                    stringResource(title), style = MaterialTheme.typography.titleLarge,
                    color = if (ui.state == ViewerState.FAILED) NL.Red else NL.TextDim,
                )
                Text(stringResource(desc), style = MaterialTheme.typography.bodySmall, color = NL.TextDim, textAlign = TextAlign.Center)
            }
        }
    }
}

private fun errorText(e: ConnectError?): Int = when (e) {
    ConnectError.WRONG_CODE -> R.string.err_wrong_code
    ConnectError.LOCKED -> R.string.err_locked
    ConnectError.BUSY -> R.string.err_busy
    ConnectError.NOT_LOCAL -> R.string.err_not_local
    ConnectError.PROTOCOL -> R.string.err_protocol
    ConnectError.UNREACHABLE, null -> R.string.err_unreachable
}
