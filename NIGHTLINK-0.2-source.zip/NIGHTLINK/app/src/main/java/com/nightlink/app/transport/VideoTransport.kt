package com.nightlink.app.transport

import com.nightlink.app.core.RemoteCamera
import kotlinx.coroutines.flow.StateFlow
import org.webrtc.EglBase
import org.webrtc.VideoTrack

/*
 * Die UI kennt nur diese Schnittstellen. Implementierung: WebRtcTransportFactory (WebRTC über
 * lokales Signaling). Eine PC-Version kann dieselben Signaling-Nachrichten verwenden.
 */

enum class ViewerState { IDLE, CONNECTING, STREAMING, RECONNECTING, FAILED }

enum class StreamQuality { GOOD, MEDIUM, POOR }

data class StreamStats(
    val width: Int = 0,
    val height: Int = 0,
    val fps: Int = 0,
    val bitrateKbps: Int = 0,
    val rttMs: Int? = null,
    val lossPercent: Double = 0.0,
) {
    val quality: StreamQuality
        get() = when {
            fps >= 20 && lossPercent < 2.0 -> StreamQuality.GOOD
            fps >= 10 && lossPercent < 8.0 -> StreamQuality.MEDIUM
            else -> StreamQuality.POOR
        }
}

/** Ein Kontrollgerät, das mit einer Kamera verbunden ist (Sicht der Kamera). */
data class ConnectedClient(val id: String, val address: String, val streaming: Boolean)

interface ViewerSession {
    val state: StateFlow<ViewerState>
    val error: StateFlow<ConnectError?>
    val stats: StateFlow<StreamStats?>
    val remoteVideo: StateFlow<VideoTrack?>
    fun start()
    fun stop()
}

interface VideoTransportFactory {
    val eglBase: EglBase
    fun createViewerSession(camera: RemoteCamera, accessCode: String, ownDeviceId: String): ViewerSession
    fun createPublisher(onClients: (List<ConnectedClient>) -> Unit): CameraPublisher
}
