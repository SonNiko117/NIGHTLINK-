package com.nightlink.app.ui.components

import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import org.webrtc.EglBase
import org.webrtc.RendererCommon
import org.webrtc.SurfaceViewRenderer
import org.webrtc.VideoTrack

/** Zeigt den empfangenen WebRTC-Videostream. Gibt Renderer und Sink beim Verlassen frei. */
@Composable
fun RemoteVideoView(track: VideoTrack, eglBase: EglBase, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val renderer = remember {
        SurfaceViewRenderer(context).apply {
            init(eglBase.eglBaseContext, null)
            setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FIT)
            setEnableHardwareScaler(true)
        }
    }
    DisposableEffect(track, renderer) {
        runCatching { track.addSink(renderer) }
        onDispose { runCatching { track.removeSink(renderer) } }
    }
    DisposableEffect(renderer) {
        onDispose { runCatching { renderer.release() } }
    }
    AndroidView(factory = { renderer }, modifier = modifier)
}
