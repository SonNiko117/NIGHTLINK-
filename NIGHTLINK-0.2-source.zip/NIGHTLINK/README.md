# NIGHTLINK 0.2

Lokales Kamera-/Fernsteuerungssystem im WLAN: Ein Android-Gerät sendet seine Kamera per WebRTC
an ein zweites Android-Gerät. Kein Cloud-Server, kein STUN/TURN.

> **Status:** Der Code in diesem Stand wurde **nicht kompiliert und nicht ausgeführt** – die
> Entwicklungsumgebung hatte weder Android-SDK noch Gradle noch Internetzugang. Es existiert daher
> **keine geprüfte APK**. Erwarte beim ersten Build einzelne Compilerfehler und plane Tests auf zwei
> echten Geräten ein. Siehe „Nicht verifiziert“.

## Bauen
1. Ordner in Android Studio (aktuell, JDK 17) öffnen, Gradle-Sync abwarten (Gradle 8.9, AGP 8.7.3).
2. Debug-APK: `./gradlew assembleDebug` (benötigt einmalig Internet für Abhängigkeiten).
   Unit-Tests: `./gradlew testDebugUnitTest`.
3. Den Gradle-Wrapper (`gradlew`, `gradle-wrapper.jar`) fügt Android Studio beim Sync hinzu bzw.
   `gradle wrapper --gradle-version 8.9`; im ZIP waren nur die Properties enthalten.

## Zwei Handys testen
1. Beide Geräte im **selben WLAN** (Gast-Netze mit „Client-Isolation“ blockieren mDNS und Verbindungen).
2. Gerät A: **CAMERA MODE** → „KAMERA AKTIVIEREN“ → Kamera-/Benachrichtigungsrecht erlauben.
   Der 6-stellige Zugangscode steht auf dem Bildschirm.
3. Gerät B: **CONTROL MODE** → Kamera erscheint in der Liste (sonst „NEU SUCHEN“ oder manuell per IP).
   Kamera antippen → Code eingeben → „VERBINDEN“.
4. Prüfen: Livebild, Qualitätsanzeige, Front/Rück-Wechsel und Blitz auf Gerät A, „TRENNEN“/„ERNEUT VERBINDEN“.
5. Display von Gerät A ausschalten: Bild muss weiterlaufen (Benachrichtigung sichtbar).
6. WLAN kurz aus/an (Gerät B): Ansicht zeigt „VERBINDUNG UNTERBROCHEN“ und verbindet automatisch neu.
7. Falschen Code eingeben: muss abgelehnt werden; nach 5 Fehlversuchen 30 s Sperre.

## Architektur (com.nightlink.app)
- `core/` Modelle, Protokollkonstanten · `data/` Einstellungen (DataStore) · `network/` WLAN-Status
- `discovery/` mDNS `_nightlink._tcp.` (NsdManager); TXT enthält nur id, name, v – **nie den Code**
- `security/` `Handshake` (Challenge-Response + AES-GCM-Kanal), `AuthGuard` (Sperre), `LocalNetworkGuard`
- `transport/` `SignalingServer`/`SignalingClient` (TCP :48200), `CameraPublisher`, `WebRtcViewerSession`
- `service/` `CameraService` (Foreground Service, Typ camera) + `CameraRuntime` (UI↔Service-Zustand)
- `ui/`, `viewmodel/`, `di/` wie in 0.1; Control-Screen mit Video, Code-Eingabe, manueller Verbindung

## Entscheidungen
- **Signaling ohne TLS-Zertifikate:** Self-signed-Zertifikate lassen sich auf Android ohne Zusatzbibliothek
  nicht erzeugen. Stattdessen: gegenseitige Challenge-Response mit PBKDF2(Code) und AES-256-GCM für alle
  Signaling-Nachrichten (SDP/ICE) danach. Medien sind zusätzlich durch WebRTC (DTLS-SRTP) verschlüsselt.
- **Kamera:** CameraX liefert Frames (ImageAnalysis, 1280×720) an WebRTC; so bleiben Vorschau, Blitz und Linsenwechsel CameraX.
- **INTERNET-Berechtigung** ist für Sockets nötig, auch im LAN; Verbindungen gehen nur zu privaten/Link-Local-Adressen.
  Keine Standort-, keine Mikrofonberechtigung. WAKE_LOCK hält CPU/WLAN im Hintergrund wach.
- Zugangscodes anderer Geräte werden nicht gespeichert; es wird nichts davon geloggt.

## Bekannte Grenzen
- 6-stelliger Code: Ein passiver Mithörer im WLAN könnte ihn aus einem mitgeschnittenen Handshake offline
  durchprobieren. Online-Raten wird gebremst, Offline-Raten nicht. Für höhere Sicherheit: längerer Code oder PAKE (SPAKE2).
- Ein neu erzeugter Code gilt nur für neue Verbindungen; bestehende bleiben bis zum Trennen offen.
- Kein Audio, keine Aufnahme, kein Internet-/Remote-Zugriff, max. 4 gleichzeitige Kontrollgeräte.
- Release-APK: nicht gebaut; es fehlt ein Signing-Key (`isMinifyEnabled=false`, ProGuard-Regeln für WebRTC liegen bei).

## Nicht verifiziert (nur theoretisch geprüft)
Kompilierung, alle Unit-Tests, Existenz/Kompatibilität von `io.getstream:stream-webrtc-android:1.3.8`,
mDNS-Erkennung, WebRTC-Aufbau über reine Host-Kandidaten (mDNS-ICE-Obfuskation könnte je nach Build
Kandidaten verschleiern), Hintergrundbetrieb bei ausgeschaltetem Display auf Herstellern mit aggressivem
Energiesparen (ggf. Akku-Optimierung für NIGHTLINK ausschalten).
